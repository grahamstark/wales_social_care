--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: _final_1st_decile(numeric[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _final_1st_decile(numeric[]) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    AS $_$
   SELECT AVG(val)
   FROM (
     SELECT val
     FROM unnest($1) val
     ORDER BY 1
     LIMIT  2 - MOD(array_upper($1, 1), 2)
     OFFSET CEIL(array_upper($1, 1) / 10.0) - 1
   ) sub;
$_$;


ALTER FUNCTION public._final_1st_decile(numeric[]) OWNER TO postgres;

--
-- Name: _final_last_decile(numeric[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _final_last_decile(numeric[]) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    AS $_$
   SELECT AVG(val)
   FROM (
     SELECT val
     FROM unnest($1) val
     ORDER BY 1 desc
     LIMIT  2 - MOD(array_upper($1, 1), 2)
     OFFSET CEIL(array_upper($1, 1) / 10.0) - 1
   ) sub;
$_$;


ALTER FUNCTION public._final_last_decile(numeric[]) OWNER TO postgres;

--
-- Name: _final_median(numeric[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _final_median(numeric[]) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    AS $_$
   SELECT AVG(val)
   FROM (
     SELECT val
     FROM unnest($1) val
     ORDER BY 1
     LIMIT  2 - MOD(array_upper($1, 1), 2)
     OFFSET CEIL(array_upper($1, 1) / 2.0) - 1
   ) sub;
$_$;


ALTER FUNCTION public._final_median(numeric[]) OWNER TO postgres;

--
-- Name: _final_nth(anyarray, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _final_nth(anyarray, integer) RETURNS anyelement
    LANGUAGE sql IMMUTABLE
    AS $_$                                                                      
    SELECT a
    FROM unnest( $1 ) a                                                            
    ORDER BY a                                           
    offset $2
    LIMIT 1;
$_$;


ALTER FUNCTION public._final_nth(anyarray, integer) OWNER TO postgres;

--
-- Name: _final_range(numeric[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION _final_range(numeric[]) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    AS $_$
   SELECT MAX(val) - MIN(val)
   FROM unnest($1) val;
$_$;


ALTER FUNCTION public._final_range(numeric[]) OWNER TO postgres;

--
-- Name: year_from_wave(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION year_from_wave(text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
        select 1990+(ascii(substr( lpad( $1, 2, '@' ), 1, 1 ))-64)*26 + ascii( substr( lpad( $1, 2, '@' ), 2, 1 ))-64
        $_$;


ALTER FUNCTION public.year_from_wave(text) OWNER TO postgres;

--
-- Name: first_decile(numeric); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE first_decile(numeric) (
    SFUNC = array_append,
    STYPE = numeric[],
    INITCOND = '{}',
    FINALFUNC = _final_1st_decile
);


ALTER AGGREGATE public.first_decile(numeric) OWNER TO postgres;

--
-- Name: last_decile(numeric); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE last_decile(numeric) (
    SFUNC = array_append,
    STYPE = numeric[],
    INITCOND = '{}',
    FINALFUNC = _final_last_decile
);


ALTER AGGREGATE public.last_decile(numeric) OWNER TO postgres;

--
-- Name: median(numeric); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE median(numeric) (
    SFUNC = array_append,
    STYPE = numeric[],
    INITCOND = '{}',
    FINALFUNC = _final_median
);


ALTER AGGREGATE public.median(numeric) OWNER TO postgres;

--
-- Name: range(numeric); Type: AGGREGATE; Schema: public; Owner: postgres
--

CREATE AGGREGATE range(numeric) (
    SFUNC = array_append,
    STYPE = numeric[],
    INITCOND = '{}',
    FINALFUNC = _final_range
);


ALTER AGGREGATE public.range(numeric) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dataset; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE dataset (
    name character varying(32) NOT NULL,
    creator character varying(32),
    title character varying(60),
    run_id integer
);


ALTER TABLE public.dataset OWNER TO postgres;

--
-- Name: disaggregated_data_table; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE disaggregated_data_table (
    run_id integer NOT NULL,
    username character varying(32) NOT NULL,
    model_table_name character varying(40) NOT NULL,
    iteration integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.disaggregated_data_table OWNER TO postgres;

--
-- Name: disaggregated_data_table_cell; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE disaggregated_data_table_cell (
    run_id integer NOT NULL,
    username character varying(32) NOT NULL,
    model_table_name character varying(40) NOT NULL,
    row_num integer NOT NULL,
    col_num integer NOT NULL,
    wave character varying(2) NOT NULL,
    iteration integer NOT NULL,
    system_number integer DEFAULT 1 NOT NULL,
    value1 double precision DEFAULT 0.0,
    value2 double precision DEFAULT 0.0,
    value3 double precision DEFAULT 0.0,
    value4 double precision DEFAULT 0.0,
    value5 double precision DEFAULT 0.0,
    value6 double precision DEFAULT 0.0,
    i bigint DEFAULT 0,
    p1 integer DEFAULT 0,
    p2 integer DEFAULT 0,
    p3 integer DEFAULT 0
);


ALTER TABLE public.disaggregated_data_table_cell OWNER TO postgres;

--
-- Name: disaggregated_data_table_cell_description; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE disaggregated_data_table_cell_description (
    model_table_name character varying(40) NOT NULL,
    cell_pos integer NOT NULL,
    cell_label character varying(80),
    cell_type character varying(20),
    file_pos integer
);


ALTER TABLE public.disaggregated_data_table_cell_description OWNER TO postgres;

--
-- Name: disaggregated_data_table_description; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE disaggregated_data_table_description (
    model_table_name character varying(40) NOT NULL,
    filename character varying(80),
    has_totals integer,
    table_type character varying(60),
    table_subtype character varying(60)
);


ALTER TABLE public.disaggregated_data_table_description OWNER TO postgres;

--
-- Name: key_value_parameter; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE key_value_parameter (
    username character varying(32) NOT NULL,
    run_id integer NOT NULL,
    key character varying(250) NOT NULL,
    val character varying(250)
);


ALTER TABLE public.key_value_parameter OWNER TO postgres;

--
-- Name: maxima_and_totals; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE maxima_and_totals (
    lifetime_la_contributions double precision DEFAULT 0.0,
    lifetime_client_contributions double precision DEFAULT 0.0,
    lifetime_gross_payments double precision DEFAULT 0.0,
    lifetime_capital_contributions double precision DEFAULT 0.0,
    highest_la_contribution double precision DEFAULT 0.0
);


ALTER TABLE public.maxima_and_totals OWNER TO postgres;

--
-- Name: personal_income; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE personal_income (
    username character varying(32) NOT NULL,
    run_id integer NOT NULL,
    pid bigint NOT NULL,
    sysno integer NOT NULL,
    iteration integer NOT NULL,
    wave character varying(2) NOT NULL,
    income_type integer NOT NULL,
    hid bigint,
    buno integer DEFAULT 0 NOT NULL,
    adno integer DEFAULT 0 NOT NULL,
    value double precision DEFAULT 0.0
);


ALTER TABLE public.personal_income OWNER TO postgres;

--
-- Name: personal_income_post; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW personal_income_post AS
    SELECT personal_income.username, personal_income.run_id, personal_income.pid, personal_income.sysno, personal_income.iteration, personal_income.wave, personal_income.income_type, personal_income.hid, personal_income.buno, personal_income.adno, personal_income.value FROM personal_income WHERE (personal_income.sysno = 2);


ALTER TABLE public.personal_income_post OWNER TO postgres;

--
-- Name: personal_income_pre; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW personal_income_pre AS
    SELECT personal_income.username, personal_income.run_id, personal_income.pid, personal_income.sysno, personal_income.iteration, personal_income.wave, personal_income.income_type, personal_income.hid, personal_income.buno, personal_income.adno, personal_income.value FROM personal_income WHERE (personal_income.sysno = 1);


ALTER TABLE public.personal_income_pre OWNER TO postgres;

--
-- Name: personal_results; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE personal_results (
    username character varying(32) NOT NULL,
    run_id integer NOT NULL,
    sysno integer NOT NULL,
    iteration integer NOT NULL,
    pid bigint NOT NULL,
    wave character varying(2) NOT NULL,
    hid bigint,
    buno integer DEFAULT 0 NOT NULL,
    adno integer DEFAULT 0 NOT NULL,
    passes_non_residential_capital_test integer,
    passes_non_residential_income_test integer,
    passes_residential_capital_test integer,
    passes_residential_income_test integer,
    passes_residential_means_test integer,
    passes_non_residential_means_test integer,
    la_contributions double precision DEFAULT 0.0,
    client_contributions double precision DEFAULT 0.0,
    gross_care_costs double precision DEFAULT 0.0,
    total_payments_to_date double precision DEFAULT 0.0,
    disposable_income double precision DEFAULT 0.0,
    net_income double precision DEFAULT 0.0,
    marginal_rate double precision DEFAULT 0.0,
    capital_contribution double precision DEFAULT 0.0,
    minimum_income_guarantee double precision DEFAULT 0.0,
    hours_of_care_la double precision DEFAULT 0.0,
    hours_of_care_private double precision DEFAULT 0.0,
    uap integer,
    remaining_capital_stock real DEFAULT 0.0
);


ALTER TABLE public.personal_results OWNER TO postgres;

--
-- Name: personal_results_post; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW personal_results_post AS
    SELECT personal_results.username, personal_results.run_id, personal_results.sysno, personal_results.iteration, personal_results.pid, personal_results.wave, personal_results.hid, personal_results.buno, personal_results.adno, personal_results.passes_non_residential_capital_test, personal_results.passes_non_residential_income_test, personal_results.passes_residential_capital_test, personal_results.passes_residential_income_test, personal_results.passes_residential_means_test, personal_results.passes_non_residential_means_test, personal_results.la_contributions, personal_results.client_contributions, personal_results.gross_care_costs, personal_results.total_payments_to_date, personal_results.disposable_income, personal_results.net_income, personal_results.marginal_rate, personal_results.capital_contribution, personal_results.minimum_income_guarantee, personal_results.hours_of_care_la, personal_results.hours_of_care_private, personal_results.uap FROM personal_results WHERE (personal_results.sysno = 2);


ALTER TABLE public.personal_results_post OWNER TO postgres;

--
-- Name: personal_results_pre; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW personal_results_pre AS
    SELECT personal_results.username, personal_results.run_id, personal_results.sysno, personal_results.iteration, personal_results.pid, personal_results.wave, personal_results.hid, personal_results.buno, personal_results.adno, personal_results.passes_non_residential_capital_test, personal_results.passes_non_residential_income_test, personal_results.passes_residential_capital_test, personal_results.passes_residential_income_test, personal_results.passes_residential_means_test, personal_results.passes_non_residential_means_test, personal_results.la_contributions, personal_results.client_contributions, personal_results.gross_care_costs, personal_results.total_payments_to_date, personal_results.disposable_income, personal_results.net_income, personal_results.marginal_rate, personal_results.capital_contribution, personal_results.minimum_income_guarantee, personal_results.hours_of_care_la, personal_results.hours_of_care_private, personal_results.uap FROM personal_results WHERE (personal_results.sysno = 1);


ALTER TABLE public.personal_results_pre OWNER TO postgres;

--
-- Name: probit_threshold; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE probit_threshold (
    username character varying(32) NOT NULL,
    run_id integer NOT NULL,
    element integer NOT NULL,
    threshold double precision DEFAULT 0.0
);


ALTER TABLE public.probit_threshold OWNER TO postgres;

--
-- Name: run; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE run (
    run_id integer NOT NULL,
    username character varying(32) NOT NULL,
    comparison_username character varying(60),
    comparison_run_id integer,
    title character varying(60),
    use_random_threshold integer,
    num_iterations integer DEFAULT 1,
    interest_rate_pct double precision,
    real_terms integer,
    is_null_settings integer DEFAULT 0,
    working_root character varying(120),
    users_directory character varying(120),
    output_directory character varying(120),
    dir_separator character varying(1),
    session_id character varying(60),
    default_run_dir_id integer,
    start_year integer,
    end_year integer,
    weighting_function integer,
    weighting_lower_bound double precision,
    weighting_upper_bound double precision,
    status integer DEFAULT 2,
    dataset_name character varying(32) DEFAULT 'default'::character varying,
    type_of_run integer DEFAULT 0
);


ALTER TABLE public.run OWNER TO postgres;

--
-- Name: state; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE state (
    username character varying(32) NOT NULL,
    run_id integer NOT NULL,
    household integer DEFAULT 0,
    other_counter integer DEFAULT 0,
    year integer DEFAULT 0,
    phase integer,
    health integer,
    error_code integer DEFAULT 0,
    read_error integer DEFAULT 0,
    session_id character varying(120),
    other_counter2 integer DEFAULT 0,
    other_counter3 integer DEFAULT 0,
    other_counter4 integer DEFAULT 0
);


ALTER TABLE public.state OWNER TO postgres;

--
-- Name: table_stats; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW table_stats AS
    SELECT disaggregated_data_table_cell.run_id, disaggregated_data_table_cell.username, disaggregated_data_table_cell.model_table_name, disaggregated_data_table_cell.row_num, disaggregated_data_table_cell.col_num, disaggregated_data_table_cell.wave, disaggregated_data_table_cell.system_number, count(1) AS nvalues, avg(disaggregated_data_table_cell.value1) AS rmean_1, min(disaggregated_data_table_cell.value1) AS rmin_1, max(disaggregated_data_table_cell.value1) AS rmax_1, median((disaggregated_data_table_cell.value1)::numeric) AS rmed_1, range((disaggregated_data_table_cell.value1)::numeric) AS rranage_1, stddev((disaggregated_data_table_cell.value1)::numeric) AS sddev_1, first_decile((disaggregated_data_table_cell.value1)::numeric) AS dec1_1, last_decile((disaggregated_data_table_cell.value1)::numeric) AS dec10_1, avg(disaggregated_data_table_cell.value2) AS rmean_2, min(disaggregated_data_table_cell.value2) AS rmin_2, max(disaggregated_data_table_cell.value2) AS rmax_2, median((disaggregated_data_table_cell.value2)::numeric) AS rmed_2, range((disaggregated_data_table_cell.value2)::numeric) AS rranage_2, stddev((disaggregated_data_table_cell.value2)::numeric) AS sddev_2, first_decile((disaggregated_data_table_cell.value2)::numeric) AS dec1_2, last_decile((disaggregated_data_table_cell.value2)::numeric) AS dec10_2, avg(disaggregated_data_table_cell.value3) AS rmean_3, min(disaggregated_data_table_cell.value3) AS rmin_3, max(disaggregated_data_table_cell.value3) AS rmax_3, median((disaggregated_data_table_cell.value3)::numeric) AS rmed_3, range((disaggregated_data_table_cell.value3)::numeric) AS rranage_3, stddev((disaggregated_data_table_cell.value3)::numeric) AS sddev_3, first_decile((disaggregated_data_table_cell.value3)::numeric) AS dec1_3, last_decile((disaggregated_data_table_cell.value3)::numeric) AS dec10_3, avg(disaggregated_data_table_cell.value4) AS rmean_4, min(disaggregated_data_table_cell.value4) AS rmin_4, max(disaggregated_data_table_cell.value4) AS rmax_4, median((disaggregated_data_table_cell.value4)::numeric) AS rmed_4, range((disaggregated_data_table_cell.value4)::numeric) AS rranage_4, stddev((disaggregated_data_table_cell.value4)::numeric) AS sddev_4, first_decile((disaggregated_data_table_cell.value4)::numeric) AS dec1_4, last_decile((disaggregated_data_table_cell.value4)::numeric) AS dec10_4, avg(disaggregated_data_table_cell.value5) AS rmean_5, min(disaggregated_data_table_cell.value5) AS rmin_5, max(disaggregated_data_table_cell.value5) AS rmax_5, median((disaggregated_data_table_cell.value5)::numeric) AS rmed_5, range((disaggregated_data_table_cell.value5)::numeric) AS rranage_5, stddev((disaggregated_data_table_cell.value5)::numeric) AS sddev_5, first_decile((disaggregated_data_table_cell.value5)::numeric) AS dec1_5, last_decile((disaggregated_data_table_cell.value5)::numeric) AS dec10_5, avg(disaggregated_data_table_cell.value6) AS rmean_6, min(disaggregated_data_table_cell.value6) AS rmin_6, max(disaggregated_data_table_cell.value6) AS rmax_6, median((disaggregated_data_table_cell.value6)::numeric) AS rmed_6, range((disaggregated_data_table_cell.value6)::numeric) AS rranage_6, stddev((disaggregated_data_table_cell.value6)::numeric) AS sddev_6, first_decile((disaggregated_data_table_cell.value6)::numeric) AS dec1_6, last_decile((disaggregated_data_table_cell.value6)::numeric) AS dec10_6 FROM disaggregated_data_table_cell GROUP BY disaggregated_data_table_cell.username, disaggregated_data_table_cell.run_id, disaggregated_data_table_cell.model_table_name, disaggregated_data_table_cell.wave, disaggregated_data_table_cell.row_num, disaggregated_data_table_cell.col_num, disaggregated_data_table_cell.system_number ORDER BY disaggregated_data_table_cell.username, disaggregated_data_table_cell.run_id, disaggregated_data_table_cell.model_table_name, length((disaggregated_data_table_cell.wave)::text), disaggregated_data_table_cell.wave, disaggregated_data_table_cell.system_number, disaggregated_data_table_cell.row_num, disaggregated_data_table_cell.col_num;


ALTER TABLE public.table_stats OWNER TO postgres;

--
-- Name: uap_threshold; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE uap_threshold (
    run_id integer NOT NULL,
    username character varying(32) NOT NULL,
    sysno integer NOT NULL,
    iteration integer NOT NULL,
    wave character varying(2) NOT NULL,
    uap_level integer NOT NULL,
    threshold double precision DEFAULT 0.0
);


ALTER TABLE public.uap_threshold OWNER TO postgres;

--
-- Name: uprate_assumption; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE uprate_assumption (
    username character varying(32) NOT NULL,
    run_id integer NOT NULL,
    percent_change double precision DEFAULT 0.0,
    use_obr integer DEFAULT 0,
    target integer NOT NULL,
    element integer
);


ALTER TABLE public.uprate_assumption OWNER TO postgres;

--
-- Name: user_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_type (
    username character varying(32) NOT NULL,
    password character varying(60),
    title character varying(60),
    description character varying(60),
    email character varying(60),
    work_dir character varying(60),
    utype integer,
    lang integer,
    preferences character varying(60),
    last_used timestamp without time zone
);


ALTER TABLE public.user_type OWNER TO postgres;

--
-- Data for Name: dataset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dataset (name, creator, title, run_id) FROM stdin;
default	default	The Default Dataset	1
\.


--
-- Data for Name: disaggregated_data_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY disaggregated_data_table (run_id, username, model_table_name, iteration) FROM stdin;
\.


--
-- Data for Name: disaggregated_data_table_cell; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY disaggregated_data_table_cell (run_id, username, model_table_name, row_num, col_num, wave, iteration, system_number, value1, value2, value3, value4, value5, value6, i, p1, p2, p3) FROM stdin;
\.


--
-- Data for Name: disaggregated_data_table_cell_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY disaggregated_data_table_cell_description (model_table_name, cell_pos, cell_label, cell_type, file_pos) FROM stdin;
\.


--
-- Data for Name: disaggregated_data_table_description; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY disaggregated_data_table_description (model_table_name, filename, has_totals, table_type, table_subtype) FROM stdin;
summary_items		0	summary	
costs_by_decile		1	budget	
costs_by_tenure		1	budget	
costs_by_age_band		1	budget	
gain_lose_by_tenure		1	gain_lose	numbers
gain_lose_by_decile		1	gain_lose	numbers
gain_lose_by_age_band		1	gain_lose	numbers
\.


--
-- Data for Name: key_value_parameter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY key_value_parameter (username, run_id, key, val) FROM stdin;
default	1	y[2012].av_costs.hour_of_care	14.60
default	1	y[2012].av_costs.residential_per_week	497.0
default	1	y[2012].benefits.attendance_allowance.high_age	150
default	1	y[2012].benefits.attendance_allowance.high_rate	77.45
default	1	y[2012].benefits.attendance_allowance.low_age	65
default	1	y[2012].benefits.attendance_allowance.low_rate	51.85
default	1	y[2012].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2012].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2012].benefits.dla.care.high_age	64
default	1	y[2012].benefits.dla.care.high_rate	77.45
default	1	y[2012].benefits.dla.care.low_age	3
default	1	y[2012].benefits.dla.care.low_rate	20.55
default	1	y[2012].benefits.dla.care.middle_rate	51.85
default	1	y[2012].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2012].benefits.dla.care.test_generosity	1.0
default	1	y[2012].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2012].benefits.dla.mobility.high_age	64
default	1	y[2012].benefits.dla.mobility.high_rate	54.05
default	1	y[2012].benefits.dla.mobility.low_age	0
default	1	y[2012].benefits.dla.mobility.low_rate	20.55
default	1	y[2012].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2012].benefits.dla.mobility.test_generosity	1.0
default	1	y[2012].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2012].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2012].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2012].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2012].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2012].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2012].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2012].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2012].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2012].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2012].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2012].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2012].benefits.state_pension.age_men	65
default	1	y[2012].benefits.state_pension.age_women	60
default	1	y[2012].benefits.state_pension.citizens_pension	False
default	1	y[2012].benefits.state_pension.class_a	102.15
default	1	y[2012].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2012].social_care.insurance.actuarially_fair	False
default	1	y[2012].social_care.insurance.contribution	none
default	1	y[2012].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2012].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2012].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2012].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2012].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2012].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2012].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2012].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2012].social_care.means_test.non_residential.income.abolish	False
default	1	y[2012].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2012].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2012].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2012].social_care.means_test.residential.assets.abolish	False
default	1	y[2012].social_care.means_test.residential.assets.include_property	True
default	1	y[2012].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2012].social_care.means_test.residential.assets.taper	0.0
default	1	y[2012].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2012].social_care.means_test.residential.income.abolish	False
default	1	y[2012].social_care.means_test.residential.income.floor	35.0
default	1	y[2012].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2012].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2012].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2012].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2012].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2012].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2012].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2012].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2012].social_care.options.abolish	False
default	1	y[2012].social_care.options.preserve_for_existing_claimants	False
default	1	y[2013].av_costs.hour_of_care	14.60
default	1	y[2013].av_costs.residential_per_week	497.0
default	1	y[2013].benefits.attendance_allowance.high_age	150
default	1	y[2013].benefits.attendance_allowance.high_rate	77.45
default	1	y[2013].benefits.attendance_allowance.low_age	65
default	1	y[2013].benefits.attendance_allowance.low_rate	51.85
default	1	y[2013].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2013].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2013].benefits.dla.care.high_age	64
default	1	y[2013].benefits.dla.care.high_rate	77.45
default	1	y[2013].benefits.dla.care.low_age	3
default	1	y[2013].benefits.dla.care.low_rate	20.55
default	1	y[2013].benefits.dla.care.middle_rate	51.85
default	1	y[2013].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2013].benefits.dla.care.test_generosity	1.0
default	1	y[2013].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2013].benefits.dla.mobility.high_age	64
default	1	y[2013].benefits.dla.mobility.high_rate	54.05
default	1	y[2013].benefits.dla.mobility.low_age	0
default	1	y[2013].benefits.dla.mobility.low_rate	20.55
default	1	y[2013].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2013].benefits.dla.mobility.test_generosity	1.0
default	1	y[2013].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2013].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2013].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2013].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2013].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2013].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2013].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2013].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2013].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2013].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2013].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2013].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2013].benefits.state_pension.age_men	65
default	1	y[2013].benefits.state_pension.age_women	60
default	1	y[2013].benefits.state_pension.citizens_pension	False
default	1	y[2013].benefits.state_pension.class_a	102.15
default	1	y[2013].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2013].social_care.insurance.actuarially_fair	False
default	1	y[2013].social_care.insurance.contribution	none
default	1	y[2013].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2013].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2013].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2013].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2013].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2013].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2013].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2013].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2013].social_care.means_test.non_residential.income.abolish	False
default	1	y[2013].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2013].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2013].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2013].social_care.means_test.residential.assets.abolish	False
default	1	y[2013].social_care.means_test.residential.assets.include_property	True
default	1	y[2013].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2013].social_care.means_test.residential.assets.taper	0.0
default	1	y[2013].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2013].social_care.means_test.residential.income.abolish	False
default	1	y[2013].social_care.means_test.residential.income.floor	35.0
default	1	y[2013].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2013].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2013].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2013].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2013].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2013].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2013].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2013].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2013].social_care.options.abolish	False
default	1	y[2013].social_care.options.preserve_for_existing_claimants	False
default	1	y[2014].av_costs.hour_of_care	14.60
default	1	y[2014].av_costs.residential_per_week	497.0
default	1	y[2014].benefits.attendance_allowance.high_age	150
default	1	y[2014].benefits.attendance_allowance.high_rate	77.45
default	1	y[2014].benefits.attendance_allowance.low_age	65
default	1	y[2014].benefits.attendance_allowance.low_rate	51.85
default	1	y[2014].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2014].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2014].benefits.dla.care.high_age	64
default	1	y[2014].benefits.dla.care.high_rate	77.45
default	1	y[2014].benefits.dla.care.low_age	3
default	1	y[2014].benefits.dla.care.low_rate	20.55
default	1	y[2014].benefits.dla.care.middle_rate	51.85
default	1	y[2014].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2014].benefits.dla.care.test_generosity	1.0
default	1	y[2014].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2014].benefits.dla.mobility.high_age	64
default	1	y[2014].benefits.dla.mobility.high_rate	54.05
default	1	y[2014].benefits.dla.mobility.low_age	0
default	1	y[2014].benefits.dla.mobility.low_rate	20.55
default	1	y[2014].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2014].benefits.dla.mobility.test_generosity	1.0
default	1	y[2014].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2014].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2014].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2014].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2014].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2014].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2014].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2014].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2014].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2014].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2014].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2014].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2014].benefits.state_pension.age_men	65
default	1	y[2014].benefits.state_pension.age_women	60
default	1	y[2014].benefits.state_pension.citizens_pension	False
default	1	y[2014].benefits.state_pension.class_a	102.15
default	1	y[2014].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2014].social_care.insurance.actuarially_fair	False
default	1	y[2014].social_care.insurance.contribution	none
default	1	y[2014].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2014].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2014].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2014].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2014].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2014].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2014].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2014].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2014].social_care.means_test.non_residential.income.abolish	False
default	1	y[2014].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2014].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2014].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2014].social_care.means_test.residential.assets.abolish	False
default	1	y[2014].social_care.means_test.residential.assets.include_property	True
default	1	y[2014].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2014].social_care.means_test.residential.assets.taper	0.0
default	1	y[2014].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2014].social_care.means_test.residential.income.abolish	False
default	1	y[2014].social_care.means_test.residential.income.floor	35.0
default	1	y[2014].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2014].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2014].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2014].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2014].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2014].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2014].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2014].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2014].social_care.options.abolish	False
default	1	y[2014].social_care.options.preserve_for_existing_claimants	False
default	1	y[2015].av_costs.hour_of_care	14.60
default	1	y[2015].av_costs.residential_per_week	497.0
default	1	y[2015].benefits.attendance_allowance.high_age	150
default	1	y[2015].benefits.attendance_allowance.high_rate	77.45
default	1	y[2015].benefits.attendance_allowance.low_age	65
default	1	y[2015].benefits.attendance_allowance.low_rate	51.85
default	1	y[2015].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2015].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2015].benefits.dla.care.high_age	64
default	1	y[2015].benefits.dla.care.high_rate	77.45
default	1	y[2015].benefits.dla.care.low_age	3
default	1	y[2015].benefits.dla.care.low_rate	20.55
default	1	y[2015].benefits.dla.care.middle_rate	51.85
default	1	y[2015].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2015].benefits.dla.care.test_generosity	1.0
default	1	y[2015].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2015].benefits.dla.mobility.high_age	64
default	1	y[2015].benefits.dla.mobility.high_rate	54.05
default	1	y[2015].benefits.dla.mobility.low_age	0
default	1	y[2015].benefits.dla.mobility.low_rate	20.55
default	1	y[2015].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2015].benefits.dla.mobility.test_generosity	1.0
default	1	y[2015].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2015].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2015].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2015].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2015].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2015].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2015].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2015].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2015].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2015].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2015].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2015].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2015].benefits.state_pension.age_men	65
default	1	y[2015].benefits.state_pension.age_women	60
default	1	y[2015].benefits.state_pension.citizens_pension	False
default	1	y[2015].benefits.state_pension.class_a	102.15
default	1	y[2015].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2015].social_care.insurance.actuarially_fair	False
default	1	y[2015].social_care.insurance.contribution	none
default	1	y[2015].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2015].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2015].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2015].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2015].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2015].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2015].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2015].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2015].social_care.means_test.non_residential.income.abolish	False
default	1	y[2015].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2015].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2015].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2015].social_care.means_test.residential.assets.abolish	False
default	1	y[2015].social_care.means_test.residential.assets.include_property	True
default	1	y[2015].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2015].social_care.means_test.residential.assets.taper	0.0
default	1	y[2015].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2015].social_care.means_test.residential.income.abolish	False
default	1	y[2015].social_care.means_test.residential.income.floor	35.0
default	1	y[2015].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2015].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2015].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2015].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2015].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2015].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2015].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2015].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2015].social_care.options.abolish	False
default	1	y[2015].social_care.options.preserve_for_existing_claimants	False
default	1	y[2016].av_costs.hour_of_care	14.60
default	1	y[2016].av_costs.residential_per_week	497.0
default	1	y[2016].benefits.attendance_allowance.high_age	150
default	1	y[2016].benefits.attendance_allowance.high_rate	77.45
default	1	y[2016].benefits.attendance_allowance.low_age	65
default	1	y[2016].benefits.attendance_allowance.low_rate	51.85
default	1	y[2016].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2016].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2016].benefits.dla.care.high_age	64
default	1	y[2016].benefits.dla.care.high_rate	77.45
default	1	y[2016].benefits.dla.care.low_age	3
default	1	y[2016].benefits.dla.care.low_rate	20.55
default	1	y[2016].benefits.dla.care.middle_rate	51.85
default	1	y[2016].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2016].benefits.dla.care.test_generosity	1.0
default	1	y[2016].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2016].benefits.dla.mobility.high_age	64
default	1	y[2016].benefits.dla.mobility.high_rate	54.05
default	1	y[2016].benefits.dla.mobility.low_age	0
default	1	y[2016].benefits.dla.mobility.low_rate	20.55
default	1	y[2016].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2016].benefits.dla.mobility.test_generosity	1.0
default	1	y[2016].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2016].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2016].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2016].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2016].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2016].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2016].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2016].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2016].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2016].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2016].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2016].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2016].benefits.state_pension.age_men	65
default	1	y[2016].benefits.state_pension.age_women	61
default	1	y[2016].benefits.state_pension.citizens_pension	False
default	1	y[2016].benefits.state_pension.class_a	102.15
default	1	y[2016].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2016].social_care.insurance.actuarially_fair	False
default	1	y[2016].social_care.insurance.contribution	none
default	1	y[2016].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2016].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2016].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2016].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2016].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2016].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2016].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2016].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2016].social_care.means_test.non_residential.income.abolish	False
default	1	y[2016].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2016].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2016].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2016].social_care.means_test.residential.assets.abolish	False
default	1	y[2016].social_care.means_test.residential.assets.include_property	True
default	1	y[2016].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2016].social_care.means_test.residential.assets.taper	0.0
default	1	y[2016].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2016].social_care.means_test.residential.income.abolish	False
default	1	y[2016].social_care.means_test.residential.income.floor	35.0
default	1	y[2016].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2016].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2016].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2016].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2016].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2016].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2016].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2016].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2016].social_care.options.abolish	False
default	1	y[2016].social_care.options.preserve_for_existing_claimants	False
default	1	y[2017].av_costs.hour_of_care	14.60
default	1	y[2017].av_costs.residential_per_week	497.0
default	1	y[2017].benefits.attendance_allowance.high_age	150
default	1	y[2017].benefits.attendance_allowance.high_rate	77.45
default	1	y[2017].benefits.attendance_allowance.low_age	65
default	1	y[2017].benefits.attendance_allowance.low_rate	51.85
default	1	y[2017].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2017].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2017].benefits.dla.care.high_age	64
default	1	y[2017].benefits.dla.care.high_rate	77.45
default	1	y[2017].benefits.dla.care.low_age	3
default	1	y[2017].benefits.dla.care.low_rate	20.55
default	1	y[2017].benefits.dla.care.middle_rate	51.85
default	1	y[2017].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2017].benefits.dla.care.test_generosity	1.0
default	1	y[2017].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2017].benefits.dla.mobility.high_age	64
default	1	y[2017].benefits.dla.mobility.high_rate	54.05
default	1	y[2017].benefits.dla.mobility.low_age	0
default	1	y[2017].benefits.dla.mobility.low_rate	20.55
default	1	y[2017].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2017].benefits.dla.mobility.test_generosity	1.0
default	1	y[2017].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2017].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2017].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2017].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2017].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2017].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2017].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2017].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2017].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2017].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2017].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2017].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2017].benefits.state_pension.age_men	65
default	1	y[2017].benefits.state_pension.age_women	63
default	1	y[2017].benefits.state_pension.citizens_pension	False
default	1	y[2017].benefits.state_pension.class_a	102.15
default	1	y[2017].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2017].social_care.insurance.actuarially_fair	False
default	1	y[2017].social_care.insurance.contribution	none
default	1	y[2017].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2017].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2017].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2017].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2017].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2017].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2017].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2017].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2017].social_care.means_test.non_residential.income.abolish	False
default	1	y[2017].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2017].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2017].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2017].social_care.means_test.residential.assets.abolish	False
default	1	y[2017].social_care.means_test.residential.assets.include_property	True
default	1	y[2017].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2017].social_care.means_test.residential.assets.taper	0.0
default	1	y[2017].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2017].social_care.means_test.residential.income.abolish	False
default	1	y[2017].social_care.means_test.residential.income.floor	35.0
default	1	y[2017].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2017].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2017].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2017].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2017].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2017].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2017].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2017].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2017].social_care.options.abolish	False
default	1	y[2017].social_care.options.preserve_for_existing_claimants	False
default	1	y[2018].av_costs.hour_of_care	14.60
default	1	y[2018].av_costs.residential_per_week	497.0
default	1	y[2018].benefits.attendance_allowance.high_age	150
default	1	y[2018].benefits.attendance_allowance.high_rate	77.45
default	1	y[2018].benefits.attendance_allowance.low_age	65
default	1	y[2018].benefits.attendance_allowance.low_rate	51.85
default	1	y[2018].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2018].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2018].benefits.dla.care.high_age	64
default	1	y[2018].benefits.dla.care.high_rate	77.45
default	1	y[2018].benefits.dla.care.low_age	3
default	1	y[2018].benefits.dla.care.low_rate	20.55
default	1	y[2018].benefits.dla.care.middle_rate	51.85
default	1	y[2018].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2018].benefits.dla.care.test_generosity	1.0
default	1	y[2018].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2018].benefits.dla.mobility.high_age	64
default	1	y[2018].benefits.dla.mobility.high_rate	54.05
default	1	y[2018].benefits.dla.mobility.low_age	0
default	1	y[2018].benefits.dla.mobility.low_rate	20.55
default	1	y[2018].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2018].benefits.dla.mobility.test_generosity	1.0
default	1	y[2018].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2018].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2018].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2018].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2018].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2018].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2018].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2018].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2018].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2018].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2018].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2018].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2018].benefits.state_pension.age_men	65
default	1	y[2018].benefits.state_pension.age_women	65
default	1	y[2018].benefits.state_pension.citizens_pension	False
default	1	y[2018].benefits.state_pension.class_a	102.15
default	1	y[2018].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2018].social_care.insurance.actuarially_fair	False
default	1	y[2018].social_care.insurance.contribution	none
default	1	y[2018].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2018].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2018].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2018].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2018].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2018].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2018].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2018].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2018].social_care.means_test.non_residential.income.abolish	False
default	1	y[2018].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2018].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2018].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2018].social_care.means_test.residential.assets.abolish	False
default	1	y[2018].social_care.means_test.residential.assets.include_property	True
default	1	y[2018].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2018].social_care.means_test.residential.assets.taper	0.0
default	1	y[2018].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2018].social_care.means_test.residential.income.abolish	False
default	1	y[2018].social_care.means_test.residential.income.floor	35.0
default	1	y[2018].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2018].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2018].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2018].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2018].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2018].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2018].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2018].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2018].social_care.options.abolish	False
default	1	y[2018].social_care.options.preserve_for_existing_claimants	False
default	1	y[2019].av_costs.hour_of_care	14.60
default	1	y[2019].av_costs.residential_per_week	497.0
default	1	y[2019].benefits.attendance_allowance.high_age	150
default	1	y[2019].benefits.attendance_allowance.high_rate	77.45
default	1	y[2019].benefits.attendance_allowance.low_age	65
default	1	y[2019].benefits.attendance_allowance.low_rate	51.85
default	1	y[2019].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2019].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2019].benefits.dla.care.high_age	64
default	1	y[2019].benefits.dla.care.high_rate	77.45
default	1	y[2019].benefits.dla.care.low_age	3
default	1	y[2019].benefits.dla.care.low_rate	20.55
default	1	y[2019].benefits.dla.care.middle_rate	51.85
default	1	y[2019].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2019].benefits.dla.care.test_generosity	1.0
default	1	y[2019].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2019].benefits.dla.mobility.high_age	64
default	1	y[2019].benefits.dla.mobility.high_rate	54.05
default	1	y[2019].benefits.dla.mobility.low_age	0
default	1	y[2019].benefits.dla.mobility.low_rate	20.55
default	1	y[2019].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2019].benefits.dla.mobility.test_generosity	1.0
default	1	y[2019].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2019].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2019].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2019].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2019].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2019].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2019].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2019].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2019].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2019].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2019].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2019].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2019].benefits.state_pension.age_men	65
default	1	y[2019].benefits.state_pension.age_women	65
default	1	y[2019].benefits.state_pension.citizens_pension	False
default	1	y[2019].benefits.state_pension.class_a	102.15
default	1	y[2019].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2019].social_care.insurance.actuarially_fair	False
default	1	y[2019].social_care.insurance.contribution	none
default	1	y[2019].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2019].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2019].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2019].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2019].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2019].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2019].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2019].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2019].social_care.means_test.non_residential.income.abolish	False
default	1	y[2019].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2019].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2019].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2019].social_care.means_test.residential.assets.abolish	False
default	1	y[2019].social_care.means_test.residential.assets.include_property	True
default	1	y[2019].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2019].social_care.means_test.residential.assets.taper	0.0
default	1	y[2019].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2019].social_care.means_test.residential.income.abolish	False
default	1	y[2019].social_care.means_test.residential.income.floor	35.0
default	1	y[2019].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2019].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2019].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2019].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2019].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2019].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2019].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2019].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2019].social_care.options.abolish	False
default	1	y[2019].social_care.options.preserve_for_existing_claimants	False
default	1	y[2020].av_costs.hour_of_care	14.60
default	1	y[2020].av_costs.residential_per_week	497.0
default	1	y[2020].benefits.attendance_allowance.high_age	150
default	1	y[2020].benefits.attendance_allowance.high_rate	77.45
default	1	y[2020].benefits.attendance_allowance.low_age	65
default	1	y[2020].benefits.attendance_allowance.low_rate	51.85
default	1	y[2020].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2020].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2020].benefits.dla.care.high_age	64
default	1	y[2020].benefits.dla.care.high_rate	77.45
default	1	y[2020].benefits.dla.care.low_age	3
default	1	y[2020].benefits.dla.care.low_rate	20.55
default	1	y[2020].benefits.dla.care.middle_rate	51.85
default	1	y[2020].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2020].benefits.dla.care.test_generosity	1.0
default	1	y[2020].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2020].benefits.dla.mobility.high_age	64
default	1	y[2020].benefits.dla.mobility.high_rate	54.05
default	1	y[2020].benefits.dla.mobility.low_age	0
default	1	y[2020].benefits.dla.mobility.low_rate	20.55
default	1	y[2020].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2020].benefits.dla.mobility.test_generosity	1.0
default	1	y[2020].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2020].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2020].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2020].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2020].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2020].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2020].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2020].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2020].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2020].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2020].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2020].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2020].benefits.state_pension.age_men	66
default	1	y[2020].benefits.state_pension.age_women	66
default	1	y[2020].benefits.state_pension.citizens_pension	False
default	1	y[2020].benefits.state_pension.class_a	102.15
default	1	y[2020].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2020].social_care.insurance.actuarially_fair	False
default	1	y[2020].social_care.insurance.contribution	none
default	1	y[2020].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2020].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2020].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2020].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2020].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2020].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2020].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2020].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2020].social_care.means_test.non_residential.income.abolish	False
default	1	y[2020].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2020].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2020].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2020].social_care.means_test.residential.assets.abolish	False
default	1	y[2020].social_care.means_test.residential.assets.include_property	True
default	1	y[2020].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2020].social_care.means_test.residential.assets.taper	0.0
default	1	y[2020].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2020].social_care.means_test.residential.income.abolish	False
default	1	y[2020].social_care.means_test.residential.income.floor	35.0
default	1	y[2020].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2020].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2020].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2020].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2020].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2020].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2020].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2020].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2020].social_care.options.abolish	False
default	1	y[2020].social_care.options.preserve_for_existing_claimants	False
default	1	y[2021].av_costs.hour_of_care	14.60
default	1	y[2021].av_costs.residential_per_week	497.0
default	1	y[2021].benefits.attendance_allowance.high_age	150
default	1	y[2021].benefits.attendance_allowance.high_rate	77.45
default	1	y[2021].benefits.attendance_allowance.low_age	65
default	1	y[2021].benefits.attendance_allowance.low_rate	51.85
default	1	y[2021].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2021].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2021].benefits.dla.care.high_age	64
default	1	y[2021].benefits.dla.care.high_rate	77.45
default	1	y[2021].benefits.dla.care.low_age	3
default	1	y[2021].benefits.dla.care.low_rate	20.55
default	1	y[2021].benefits.dla.care.middle_rate	51.85
default	1	y[2021].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2021].benefits.dla.care.test_generosity	1.0
default	1	y[2021].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2021].benefits.dla.mobility.high_age	64
default	1	y[2021].benefits.dla.mobility.high_rate	54.05
default	1	y[2021].benefits.dla.mobility.low_age	0
default	1	y[2021].benefits.dla.mobility.low_rate	20.55
default	1	y[2021].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2021].benefits.dla.mobility.test_generosity	1.0
default	1	y[2021].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2021].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2021].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2021].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2021].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2021].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2021].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2021].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2021].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2021].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2021].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2021].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2021].benefits.state_pension.age_men	66
default	1	y[2021].benefits.state_pension.age_women	66
default	1	y[2021].benefits.state_pension.citizens_pension	False
default	1	y[2021].benefits.state_pension.class_a	102.15
default	1	y[2021].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2021].social_care.insurance.actuarially_fair	False
default	1	y[2021].social_care.insurance.contribution	none
default	1	y[2021].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2021].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2021].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2021].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2021].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2021].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2021].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2021].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2021].social_care.means_test.non_residential.income.abolish	False
default	1	y[2021].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2021].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2021].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2021].social_care.means_test.residential.assets.abolish	False
default	1	y[2021].social_care.means_test.residential.assets.include_property	True
default	1	y[2021].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2021].social_care.means_test.residential.assets.taper	0.0
default	1	y[2021].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2021].social_care.means_test.residential.income.abolish	False
default	1	y[2021].social_care.means_test.residential.income.floor	35.0
default	1	y[2021].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2021].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2021].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2021].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2021].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2021].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2021].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2021].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2021].social_care.options.abolish	False
default	1	y[2021].social_care.options.preserve_for_existing_claimants	False
default	1	y[2022].av_costs.hour_of_care	14.60
default	1	y[2022].av_costs.residential_per_week	497.0
default	1	y[2022].benefits.attendance_allowance.high_age	150
default	1	y[2022].benefits.attendance_allowance.high_rate	77.45
default	1	y[2022].benefits.attendance_allowance.low_age	65
default	1	y[2022].benefits.attendance_allowance.low_rate	51.85
default	1	y[2022].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2022].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2022].benefits.dla.care.high_age	64
default	1	y[2022].benefits.dla.care.high_rate	77.45
default	1	y[2022].benefits.dla.care.low_age	3
default	1	y[2022].benefits.dla.care.low_rate	20.55
default	1	y[2022].benefits.dla.care.middle_rate	51.85
default	1	y[2022].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2022].benefits.dla.care.test_generosity	1.0
default	1	y[2022].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2022].benefits.dla.mobility.high_age	64
default	1	y[2022].benefits.dla.mobility.high_rate	54.05
default	1	y[2022].benefits.dla.mobility.low_age	0
default	1	y[2022].benefits.dla.mobility.low_rate	20.55
default	1	y[2022].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2022].benefits.dla.mobility.test_generosity	1.0
default	1	y[2022].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2022].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2022].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2022].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2022].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2022].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2022].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2022].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2022].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2022].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2022].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2022].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2022].benefits.state_pension.age_men	66
default	1	y[2022].benefits.state_pension.age_women	66
default	1	y[2022].benefits.state_pension.citizens_pension	False
default	1	y[2022].benefits.state_pension.class_a	102.15
default	1	y[2022].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2022].social_care.insurance.actuarially_fair	False
default	1	y[2022].social_care.insurance.contribution	none
default	1	y[2022].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2022].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2022].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2022].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2022].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2022].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2022].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2022].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2022].social_care.means_test.non_residential.income.abolish	False
default	1	y[2022].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2022].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2022].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2022].social_care.means_test.residential.assets.abolish	False
default	1	y[2022].social_care.means_test.residential.assets.include_property	True
default	1	y[2022].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2022].social_care.means_test.residential.assets.taper	0.0
default	1	y[2022].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2022].social_care.means_test.residential.income.abolish	False
default	1	y[2022].social_care.means_test.residential.income.floor	35.0
default	1	y[2022].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2022].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2022].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2022].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2022].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2022].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2022].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2022].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2022].social_care.options.abolish	False
default	1	y[2022].social_care.options.preserve_for_existing_claimants	False
default	1	y[2023].av_costs.hour_of_care	14.60
default	1	y[2023].av_costs.residential_per_week	497.0
default	1	y[2023].benefits.attendance_allowance.high_age	150
default	1	y[2023].benefits.attendance_allowance.high_rate	77.45
default	1	y[2023].benefits.attendance_allowance.low_age	65
default	1	y[2023].benefits.attendance_allowance.low_rate	51.85
default	1	y[2023].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2023].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2023].benefits.dla.care.high_age	64
default	1	y[2023].benefits.dla.care.high_rate	77.45
default	1	y[2023].benefits.dla.care.low_age	3
default	1	y[2023].benefits.dla.care.low_rate	20.55
default	1	y[2023].benefits.dla.care.middle_rate	51.85
default	1	y[2023].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2023].benefits.dla.care.test_generosity	1.0
default	1	y[2023].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2023].benefits.dla.mobility.high_age	64
default	1	y[2023].benefits.dla.mobility.high_rate	54.05
default	1	y[2023].benefits.dla.mobility.low_age	0
default	1	y[2023].benefits.dla.mobility.low_rate	20.55
default	1	y[2023].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2023].benefits.dla.mobility.test_generosity	1.0
default	1	y[2023].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2023].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2023].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2023].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2023].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2023].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2023].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2023].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2023].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2023].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2023].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2023].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2023].benefits.state_pension.age_men	66
default	1	y[2023].benefits.state_pension.age_women	66
default	1	y[2023].benefits.state_pension.citizens_pension	False
default	1	y[2023].benefits.state_pension.class_a	102.15
default	1	y[2023].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2023].social_care.insurance.actuarially_fair	False
default	1	y[2023].social_care.insurance.contribution	none
default	1	y[2023].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2023].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2023].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2023].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2023].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2023].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2023].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2023].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2023].social_care.means_test.non_residential.income.abolish	False
default	1	y[2023].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2023].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2023].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2023].social_care.means_test.residential.assets.abolish	False
default	1	y[2023].social_care.means_test.residential.assets.include_property	True
default	1	y[2023].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2023].social_care.means_test.residential.assets.taper	0.0
default	1	y[2023].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2023].social_care.means_test.residential.income.abolish	False
default	1	y[2023].social_care.means_test.residential.income.floor	35.0
default	1	y[2023].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2023].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2023].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2023].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2023].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2023].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2023].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2023].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2023].social_care.options.abolish	False
default	1	y[2023].social_care.options.preserve_for_existing_claimants	False
default	1	y[2024].av_costs.hour_of_care	14.60
default	1	y[2024].av_costs.residential_per_week	497.0
default	1	y[2024].benefits.attendance_allowance.high_age	150
default	1	y[2024].benefits.attendance_allowance.high_rate	77.45
default	1	y[2024].benefits.attendance_allowance.low_age	65
default	1	y[2024].benefits.attendance_allowance.low_rate	51.85
default	1	y[2024].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2024].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2024].benefits.dla.care.high_age	64
default	1	y[2024].benefits.dla.care.high_rate	77.45
default	1	y[2024].benefits.dla.care.low_age	3
default	1	y[2024].benefits.dla.care.low_rate	20.55
default	1	y[2024].benefits.dla.care.middle_rate	51.85
default	1	y[2024].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2024].benefits.dla.care.test_generosity	1.0
default	1	y[2024].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2024].benefits.dla.mobility.high_age	64
default	1	y[2024].benefits.dla.mobility.high_rate	54.05
default	1	y[2024].benefits.dla.mobility.low_age	0
default	1	y[2024].benefits.dla.mobility.low_rate	20.55
default	1	y[2024].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2024].benefits.dla.mobility.test_generosity	1.0
default	1	y[2024].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2024].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2024].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2024].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2024].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2024].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2024].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2024].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2024].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2024].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2024].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2024].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2024].benefits.state_pension.age_men	66
default	1	y[2024].benefits.state_pension.age_women	66
default	1	y[2024].benefits.state_pension.citizens_pension	False
default	1	y[2024].benefits.state_pension.class_a	102.15
default	1	y[2024].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2024].social_care.insurance.actuarially_fair	False
default	1	y[2024].social_care.insurance.contribution	none
default	1	y[2024].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2024].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2024].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2024].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2024].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2024].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2024].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2024].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2024].social_care.means_test.non_residential.income.abolish	False
default	1	y[2024].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2024].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2024].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2024].social_care.means_test.residential.assets.abolish	False
default	1	y[2024].social_care.means_test.residential.assets.include_property	True
default	1	y[2024].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2024].social_care.means_test.residential.assets.taper	0.0
default	1	y[2024].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2024].social_care.means_test.residential.income.abolish	False
default	1	y[2024].social_care.means_test.residential.income.floor	35.0
default	1	y[2024].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2024].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2024].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2024].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2024].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2024].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2024].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2024].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2024].social_care.options.abolish	False
default	1	y[2024].social_care.options.preserve_for_existing_claimants	False
default	1	y[2025].av_costs.hour_of_care	14.60
default	1	y[2025].av_costs.residential_per_week	497.0
default	1	y[2025].benefits.attendance_allowance.high_age	150
default	1	y[2025].benefits.attendance_allowance.high_rate	77.45
default	1	y[2025].benefits.attendance_allowance.low_age	65
default	1	y[2025].benefits.attendance_allowance.low_rate	51.85
default	1	y[2025].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2025].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2025].benefits.dla.care.high_age	64
default	1	y[2025].benefits.dla.care.high_rate	77.45
default	1	y[2025].benefits.dla.care.low_age	3
default	1	y[2025].benefits.dla.care.low_rate	20.55
default	1	y[2025].benefits.dla.care.middle_rate	51.85
default	1	y[2025].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2025].benefits.dla.care.test_generosity	1.0
default	1	y[2025].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2025].benefits.dla.mobility.high_age	64
default	1	y[2025].benefits.dla.mobility.high_rate	54.05
default	1	y[2025].benefits.dla.mobility.low_age	0
default	1	y[2025].benefits.dla.mobility.low_rate	20.55
default	1	y[2025].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2025].benefits.dla.mobility.test_generosity	1.0
default	1	y[2025].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2025].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2025].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2025].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2025].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2025].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2025].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2025].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2025].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2025].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2025].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2025].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2025].benefits.state_pension.age_men	66
default	1	y[2025].benefits.state_pension.age_women	66
default	1	y[2025].benefits.state_pension.citizens_pension	False
default	1	y[2025].benefits.state_pension.class_a	102.15
default	1	y[2025].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2025].social_care.insurance.actuarially_fair	False
default	1	y[2025].social_care.insurance.contribution	none
default	1	y[2025].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2025].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2025].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2025].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2025].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2025].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2025].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2025].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2025].social_care.means_test.non_residential.income.abolish	False
default	1	y[2025].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2025].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2025].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2025].social_care.means_test.residential.assets.abolish	False
default	1	y[2025].social_care.means_test.residential.assets.include_property	True
default	1	y[2025].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2025].social_care.means_test.residential.assets.taper	0.0
default	1	y[2025].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2025].social_care.means_test.residential.income.abolish	False
default	1	y[2025].social_care.means_test.residential.income.floor	35.0
default	1	y[2025].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2025].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2025].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2025].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2025].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2025].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2025].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2025].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2025].social_care.options.abolish	False
default	1	y[2025].social_care.options.preserve_for_existing_claimants	False
default	1	y[2026].av_costs.hour_of_care	14.60
default	1	y[2026].av_costs.residential_per_week	497.0
default	1	y[2026].benefits.attendance_allowance.high_age	150
default	1	y[2026].benefits.attendance_allowance.high_rate	77.45
default	1	y[2026].benefits.attendance_allowance.low_age	65
default	1	y[2026].benefits.attendance_allowance.low_rate	51.85
default	1	y[2026].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2026].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2026].benefits.dla.care.high_age	64
default	1	y[2026].benefits.dla.care.high_rate	77.45
default	1	y[2026].benefits.dla.care.low_age	3
default	1	y[2026].benefits.dla.care.low_rate	20.55
default	1	y[2026].benefits.dla.care.middle_rate	51.85
default	1	y[2026].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2026].benefits.dla.care.test_generosity	1.0
default	1	y[2026].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2026].benefits.dla.mobility.high_age	64
default	1	y[2026].benefits.dla.mobility.high_rate	54.05
default	1	y[2026].benefits.dla.mobility.low_age	0
default	1	y[2026].benefits.dla.mobility.low_rate	20.55
default	1	y[2026].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2026].benefits.dla.mobility.test_generosity	1.0
default	1	y[2026].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2026].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2026].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2026].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2026].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2026].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2026].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2026].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2026].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2026].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2026].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2026].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2026].benefits.state_pension.age_men	66
default	1	y[2026].benefits.state_pension.age_women	66
default	1	y[2026].benefits.state_pension.citizens_pension	False
default	1	y[2026].benefits.state_pension.class_a	102.15
default	1	y[2026].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2026].social_care.insurance.actuarially_fair	False
default	1	y[2026].social_care.insurance.contribution	none
default	1	y[2026].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2026].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2026].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2026].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2026].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2026].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2026].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2026].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2026].social_care.means_test.non_residential.income.abolish	False
default	1	y[2026].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2026].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2026].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2026].social_care.means_test.residential.assets.abolish	False
default	1	y[2026].social_care.means_test.residential.assets.include_property	True
default	1	y[2026].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2026].social_care.means_test.residential.assets.taper	0.0
default	1	y[2026].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2026].social_care.means_test.residential.income.abolish	False
default	1	y[2026].social_care.means_test.residential.income.floor	35.0
default	1	y[2026].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2026].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2026].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2026].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2026].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2026].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2026].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2026].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2026].social_care.options.abolish	False
default	1	y[2026].social_care.options.preserve_for_existing_claimants	False
default	1	y[2027].av_costs.hour_of_care	14.60
default	1	y[2027].av_costs.residential_per_week	497.0
default	1	y[2027].benefits.attendance_allowance.high_age	150
default	1	y[2027].benefits.attendance_allowance.high_rate	77.45
default	1	y[2027].benefits.attendance_allowance.low_age	65
default	1	y[2027].benefits.attendance_allowance.low_rate	51.85
default	1	y[2027].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2027].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2027].benefits.dla.care.high_age	64
default	1	y[2027].benefits.dla.care.high_rate	77.45
default	1	y[2027].benefits.dla.care.low_age	3
default	1	y[2027].benefits.dla.care.low_rate	20.55
default	1	y[2027].benefits.dla.care.middle_rate	51.85
default	1	y[2027].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2027].benefits.dla.care.test_generosity	1.0
default	1	y[2027].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2027].benefits.dla.mobility.high_age	64
default	1	y[2027].benefits.dla.mobility.high_rate	54.05
default	1	y[2027].benefits.dla.mobility.low_age	0
default	1	y[2027].benefits.dla.mobility.low_rate	20.55
default	1	y[2027].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2027].benefits.dla.mobility.test_generosity	1.0
default	1	y[2027].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2027].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2027].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2027].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2027].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2027].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2027].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2027].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2027].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2027].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2027].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2027].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2027].benefits.state_pension.age_men	67
default	1	y[2027].benefits.state_pension.age_women	67
default	1	y[2027].benefits.state_pension.citizens_pension	False
default	1	y[2027].benefits.state_pension.class_a	102.15
default	1	y[2027].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2027].social_care.insurance.actuarially_fair	False
default	1	y[2027].social_care.insurance.contribution	none
default	1	y[2027].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2027].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2027].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2027].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2027].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2027].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2027].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2027].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2027].social_care.means_test.non_residential.income.abolish	False
default	1	y[2027].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2027].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2027].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2027].social_care.means_test.residential.assets.abolish	False
default	1	y[2027].social_care.means_test.residential.assets.include_property	True
default	1	y[2027].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2027].social_care.means_test.residential.assets.taper	0.0
default	1	y[2027].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2027].social_care.means_test.residential.income.abolish	False
default	1	y[2027].social_care.means_test.residential.income.floor	35.0
default	1	y[2027].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2027].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2027].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2027].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2027].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2027].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2027].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2027].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2027].social_care.options.abolish	False
default	1	y[2027].social_care.options.preserve_for_existing_claimants	False
default	1	y[2028].av_costs.hour_of_care	14.60
default	1	y[2028].av_costs.residential_per_week	497.0
default	1	y[2028].benefits.attendance_allowance.high_age	150
default	1	y[2028].benefits.attendance_allowance.high_rate	77.45
default	1	y[2028].benefits.attendance_allowance.low_age	65
default	1	y[2028].benefits.attendance_allowance.low_rate	51.85
default	1	y[2028].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2028].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2028].benefits.dla.care.high_age	64
default	1	y[2028].benefits.dla.care.high_rate	77.45
default	1	y[2028].benefits.dla.care.low_age	3
default	1	y[2028].benefits.dla.care.low_rate	20.55
default	1	y[2028].benefits.dla.care.middle_rate	51.85
default	1	y[2028].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2028].benefits.dla.care.test_generosity	1.0
default	1	y[2028].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2028].benefits.dla.mobility.high_age	64
default	1	y[2028].benefits.dla.mobility.high_rate	54.05
default	1	y[2028].benefits.dla.mobility.low_age	0
default	1	y[2028].benefits.dla.mobility.low_rate	20.55
default	1	y[2028].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2028].benefits.dla.mobility.test_generosity	1.0
default	1	y[2028].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2028].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2028].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2028].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2028].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2028].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2028].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2028].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2028].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2028].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2028].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2028].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2028].benefits.state_pension.age_men	67
default	1	y[2028].benefits.state_pension.age_women	67
default	1	y[2028].benefits.state_pension.citizens_pension	False
default	1	y[2028].benefits.state_pension.class_a	102.15
default	1	y[2028].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2028].social_care.insurance.actuarially_fair	False
default	1	y[2028].social_care.insurance.contribution	none
default	1	y[2028].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2028].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2028].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2028].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2028].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2028].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2028].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2028].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2028].social_care.means_test.non_residential.income.abolish	False
default	1	y[2028].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2028].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2028].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2028].social_care.means_test.residential.assets.abolish	False
default	1	y[2028].social_care.means_test.residential.assets.include_property	True
default	1	y[2028].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2028].social_care.means_test.residential.assets.taper	0.0
default	1	y[2028].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2028].social_care.means_test.residential.income.abolish	False
default	1	y[2028].social_care.means_test.residential.income.floor	35.0
default	1	y[2028].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2028].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2028].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2028].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2028].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2028].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2028].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2028].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2028].social_care.options.abolish	False
default	1	y[2028].social_care.options.preserve_for_existing_claimants	False
default	1	y[2029].av_costs.hour_of_care	14.60
default	1	y[2029].av_costs.residential_per_week	497.0
default	1	y[2029].benefits.attendance_allowance.high_age	150
default	1	y[2029].benefits.attendance_allowance.high_rate	77.45
default	1	y[2029].benefits.attendance_allowance.low_age	65
default	1	y[2029].benefits.attendance_allowance.low_rate	51.85
default	1	y[2029].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2029].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2029].benefits.dla.care.high_age	64
default	1	y[2029].benefits.dla.care.high_rate	77.45
default	1	y[2029].benefits.dla.care.low_age	3
default	1	y[2029].benefits.dla.care.low_rate	20.55
default	1	y[2029].benefits.dla.care.middle_rate	51.85
default	1	y[2029].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2029].benefits.dla.care.test_generosity	1.0
default	1	y[2029].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2029].benefits.dla.mobility.high_age	64
default	1	y[2029].benefits.dla.mobility.high_rate	54.05
default	1	y[2029].benefits.dla.mobility.low_age	0
default	1	y[2029].benefits.dla.mobility.low_rate	20.55
default	1	y[2029].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2029].benefits.dla.mobility.test_generosity	1.0
default	1	y[2029].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2029].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2029].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2029].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2029].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2029].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2029].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2029].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2029].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2029].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2029].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2029].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2029].benefits.state_pension.age_men	67
default	1	y[2029].benefits.state_pension.age_women	67
default	1	y[2029].benefits.state_pension.citizens_pension	False
default	1	y[2029].benefits.state_pension.class_a	102.15
default	1	y[2029].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2029].social_care.insurance.actuarially_fair	False
default	1	y[2029].social_care.insurance.contribution	none
default	1	y[2029].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2029].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2029].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2029].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2029].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2029].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2029].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2029].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2029].social_care.means_test.non_residential.income.abolish	False
default	1	y[2029].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2029].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2029].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2029].social_care.means_test.residential.assets.abolish	False
default	1	y[2029].social_care.means_test.residential.assets.include_property	True
default	1	y[2029].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2029].social_care.means_test.residential.assets.taper	0.0
default	1	y[2029].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2029].social_care.means_test.residential.income.abolish	False
default	1	y[2029].social_care.means_test.residential.income.floor	35.0
default	1	y[2029].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2029].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2029].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2029].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2029].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2029].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2029].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2029].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2029].social_care.options.abolish	False
default	1	y[2029].social_care.options.preserve_for_existing_claimants	False
default	1	y[2030].av_costs.hour_of_care	14.60
default	1	y[2030].av_costs.residential_per_week	497.0
default	1	y[2030].benefits.attendance_allowance.high_age	150
default	1	y[2030].benefits.attendance_allowance.high_rate	77.45
default	1	y[2030].benefits.attendance_allowance.low_age	65
default	1	y[2030].benefits.attendance_allowance.low_rate	51.85
default	1	y[2030].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	1	y[2030].benefits.attendance_allowance.test_generosity	1.0
default	1	y[2030].benefits.dla.care.high_age	64
default	1	y[2030].benefits.dla.care.high_rate	77.45
default	1	y[2030].benefits.dla.care.low_age	3
default	1	y[2030].benefits.dla.care.low_rate	20.55
default	1	y[2030].benefits.dla.care.middle_rate	51.85
default	1	y[2030].benefits.dla.care.preserve_for_existing_claimants	False
default	1	y[2030].benefits.dla.care.test_generosity	1.0
default	1	y[2030].benefits.dla.dont_pay_for_residential_claimants	False
default	1	y[2030].benefits.dla.mobility.high_age	64
default	1	y[2030].benefits.dla.mobility.high_rate	54.05
default	1	y[2030].benefits.dla.mobility.low_age	0
default	1	y[2030].benefits.dla.mobility.low_rate	20.55
default	1	y[2030].benefits.dla.mobility.preserve_for_existing_claimants	False
default	1	y[2030].benefits.dla.mobility.test_generosity	1.0
default	1	y[2030].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	1	y[2030].benefits.pension_credit.guaranteed_credit.couple	217.90
default	1	y[2030].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	1	y[2030].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	1	y[2030].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	1	y[2030].benefits.pension_credit.guaranteed_credit.single	142.70
default	1	y[2030].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	1	y[2030].benefits.pension_credit.savings_credit.maximum_single	18.54
default	1	y[2030].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	1	y[2030].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	1	y[2030].benefits.pension_credit.savings_credit.threshold_single	111.80
default	1	y[2030].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	1	y[2030].benefits.state_pension.age_men	67
default	1	y[2030].benefits.state_pension.age_women	67
default	1	y[2030].benefits.state_pension.citizens_pension	False
default	1	y[2030].benefits.state_pension.class_a	102.15
default	1	y[2030].benefits.state_pension.preserve_for_existing_claimants	False
default	1	y[2030].social_care.insurance.actuarially_fair	False
default	1	y[2030].social_care.insurance.contribution	none
default	1	y[2030].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	1	y[2030].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	1	y[2030].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	1	y[2030].social_care.means_test.non_residential.assets.abolish	False
default	1	y[2030].social_care.means_test.non_residential.assets.include_property	False
default	1	y[2030].social_care.means_test.non_residential.assets.lower_limit	22500
default	1	y[2030].social_care.means_test.non_residential.assets.taper	0.0
default	1	y[2030].social_care.means_test.non_residential.assets.upper_limit	22500
default	1	y[2030].social_care.means_test.non_residential.income.abolish	False
default	1	y[2030].social_care.means_test.non_residential.income.floor	35.0
default	1	y[2030].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	1	y[2030].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	1	y[2030].social_care.means_test.residential.assets.abolish	False
default	1	y[2030].social_care.means_test.residential.assets.include_property	True
default	1	y[2030].social_care.means_test.residential.assets.lower_limit	22500
default	1	y[2030].social_care.means_test.residential.assets.taper	0.0
default	1	y[2030].social_care.means_test.residential.assets.upper_limit	22500.0
default	1	y[2030].social_care.means_test.residential.income.abolish	False
default	1	y[2030].social_care.means_test.residential.income.floor	35.0
default	1	y[2030].social_care.means_test.residential.income.minimum_support_level	0.0
default	1	y[2030].social_care.means_test.residential.income.percent_costs_met	0.0
default	1	y[2030].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	1	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	1	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	1	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	1	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	1	y[2030].social_care.needs_assessment_rules.uap_category_critical	5.5
default	1	y[2030].social_care.needs_assessment_rules.uap_category_low	10.0
default	1	y[2030].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	1	y[2030].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	1	y[2030].social_care.needs_assessment_rules.use_carer_blind_system	False
default	1	y[2030].social_care.options.abolish	False
default	1	y[2030].social_care.options.preserve_for_existing_claimants	False
default	2	y[2027].benefits.pension_credit.guaranteed_credit.single	 1.92055411878853E+02
default	2	y[2027].benefits.pension_credit.savings_credit.maximum_single	 2.49523989925294E+01
default	2	y[2027].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.83295372904644E+01
default	2	y[2027].benefits.pension_credit.savings_credit.maximum_couple	 3.19374556684316E+01
default	2	y[2027].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.56659074580929E+02
default	2	y[2027].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2027].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2027].benefits.state_pension.age_men	67
default	2	y[2027].benefits.state_pension.age_women	67
default	2	y[2027].benefits.state_pension.citizens_pension	False
default	2	y[2027].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2027].social_care.insurance.actuarially_fair	False
default	2	y[2027].social_care.insurance.contribution	none
default	2	y[2027].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2027].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2027].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2027].social_care.means_test.non_residential.income.abolish	False
default	2	y[2027].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2027].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2027].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2027].social_care.means_test.residential.assets.abolish	False
default	2	y[2027].social_care.means_test.residential.assets.include_property	True
default	2	y[2027].social_care.means_test.residential.assets.taper	0.0
default	2	y[2027].social_care.means_test.residential.income.abolish	False
default	2	y[2027].social_care.means_test.residential.income.floor	35.0
default	2	y[2027].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2027].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2027].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2027].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2027].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2027].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2027].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2027].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2027].social_care.options.abolish	False
default	2	y[2027].social_care.options.preserve_for_existing_claimants	False
default	2	y[2028].benefits.attendance_allowance.high_age	150
default	2	y[2028].benefits.attendance_allowance.low_age	65
default	2	y[2028].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2028].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2028].benefits.dla.care.high_age	64
default	2	y[2028].benefits.dla.care.low_age	3
default	2	y[2028].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2028].benefits.dla.care.test_generosity	1.0
default	2	y[2028].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2028].benefits.dla.mobility.high_age	64
default	2	y[2028].benefits.dla.mobility.low_age	0
default	2	y[2028].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2028].benefits.dla.mobility.test_generosity	1.0
default	2	y[2028].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2028].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.59792256072547E+02
default	2	y[2028].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2028].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2028].benefits.state_pension.age_men	67
default	2	y[2028].benefits.state_pension.age_women	67
default	2	y[2028].benefits.state_pension.citizens_pension	False
default	2	y[2028].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2028].social_care.insurance.actuarially_fair	False
default	2	y[2028].social_care.insurance.contribution	none
default	2	y[2028].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2028].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2028].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2028].social_care.means_test.non_residential.income.abolish	False
default	2	y[2028].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2028].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2028].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2028].social_care.means_test.residential.assets.abolish	False
default	2	y[2028].social_care.means_test.residential.assets.include_property	True
default	2	y[2028].social_care.means_test.residential.assets.taper	0.0
default	2	y[2028].social_care.means_test.residential.income.abolish	False
default	2	y[2028].social_care.means_test.residential.income.floor	35.0
default	2	y[2028].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2028].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2028].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2028].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2028].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2028].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2028].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2028].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2028].social_care.options.abolish	False
default	2	y[2028].social_care.options.preserve_for_existing_claimants	False
default	2	y[2029].benefits.attendance_allowance.high_age	150
default	2	y[2029].benefits.attendance_allowance.low_age	65
default	2	y[2029].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2029].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2029].benefits.dla.care.high_age	64
default	2	y[2029].benefits.dla.care.low_age	3
default	2	y[2029].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2029].benefits.dla.care.test_generosity	1.0
default	2	y[2029].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2029].benefits.dla.mobility.high_age	64
default	2	y[2029].benefits.dla.mobility.low_age	0
default	2	y[2029].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2029].benefits.dla.mobility.test_generosity	1.0
default	2	y[2029].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2028].benefits.pension_credit.savings_credit.maximum_single	 2.54514469723800E+01
default	2	y[2029].av_costs.hour_of_care	 2.04435247202094E+01
default	2	y[2029].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2029].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2029].benefits.state_pension.age_men	67
default	2	y[2029].benefits.state_pension.age_women	67
default	2	y[2029].benefits.state_pension.citizens_pension	False
default	2	y[2029].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2029].social_care.insurance.actuarially_fair	False
default	2	y[2029].social_care.insurance.contribution	none
default	2	y[2029].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2029].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2029].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2029].social_care.means_test.non_residential.income.abolish	False
default	2	y[2029].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2029].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2029].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2029].social_care.means_test.residential.assets.abolish	False
default	2	y[2029].social_care.means_test.residential.assets.include_property	True
default	2	y[2029].social_care.means_test.residential.assets.taper	0.0
default	2	y[2029].social_care.means_test.residential.income.abolish	False
default	2	y[2029].social_care.means_test.residential.income.floor	35.0
default	2	y[2029].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2029].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2029].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2029].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2029].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2029].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2029].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2029].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2029].social_care.options.abolish	False
default	2	y[2029].social_care.options.preserve_for_existing_claimants	False
default	2	y[2030].benefits.attendance_allowance.high_age	150
default	2	y[2030].benefits.attendance_allowance.low_age	65
default	2	y[2030].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2030].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2030].benefits.dla.care.high_age	64
default	2	y[2030].benefits.dla.care.low_age	3
default	2	y[2030].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2030].benefits.dla.care.test_generosity	1.0
default	2	y[2030].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2030].benefits.dla.mobility.high_age	64
default	2	y[2030].benefits.dla.mobility.low_age	0
default	2	y[2030].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2030].benefits.dla.mobility.test_generosity	1.0
default	2	y[2030].av_costs.residential_per_week	 7.09838385045408E+02
default	2	y[2030].av_costs.hour_of_care	 2.08523952146136E+01
default	2	y[2030].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2030].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2030].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2030].benefits.state_pension.age_men	67
default	2	y[2030].benefits.state_pension.age_women	67
default	2	y[2030].benefits.state_pension.citizens_pension	False
default	2	y[2030].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2030].social_care.insurance.actuarially_fair	False
default	2	y[2030].social_care.insurance.contribution	none
default	2	y[2030].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2030].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2030].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2030].social_care.means_test.non_residential.income.abolish	False
default	2	y[2030].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2030].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2030].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2030].social_care.means_test.residential.assets.abolish	False
default	2	y[2030].social_care.means_test.residential.assets.include_property	True
default	2	y[2030].social_care.means_test.residential.assets.taper	0.0
default	2	y[2030].social_care.means_test.residential.income.abolish	False
default	2	y[2030].social_care.means_test.residential.income.floor	35.0
default	2	y[2030].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2030].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2030].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2030].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2030].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2030].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2030].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2030].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2030].social_care.options.abolish	False
default	2	y[2030].social_care.options.preserve_for_existing_claimants	False
default	2	y[2030].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 7.14123123788137E+01
default	2	y[2030].social_care.means_test.non_residential.assets.upper_limit	 3.21355405704661E+04
default	2	y[2030].benefits.state_pension.class_a	 1.45895354189916E+02
default	2	y[2030].social_care.means_test.residential.assets.lower_limit	 3.21355405704661E+04
default	2	y[2030].benefits.pension_credit.guaranteed_credit.single	 2.03810739529134E+02
default	2	y[2030].benefits.pension_credit.savings_credit.maximum_single	 2.64796854300641E+01
default	2	y[2030].benefits.pension_credit.guaranteed_credit.severe_disability_single	 8.31239316089391E+01
default	2	y[2030].benefits.pension_credit.savings_credit.maximum_couple	 3.38922834549850E+01
default	2	y[2030].benefits.pension_credit.savings_credit.threshold_single	 1.59677930479027E+02
default	2	y[2030].social_care.means_test.residential.assets.upper_limit	 3.21355405704661E+04
default	2	y[2030].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.66247863217878E+02
default	2	y[2030].benefits.pension_credit.savings_credit.threshold_couple	 2.54727718255228E+02
default	2	y[2030].social_care.means_test.non_residential.assets.lower_limit	 3.21355405704661E+04
default	2	y[2030].social_care.means_test.maxima.maximum_lifetime_payment	 1.42824624757613E+12
default	2	y[2030].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.42824624614803E+09
default	3	y[2027].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2027].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2027].benefits.state_pension.age_men	67
default	3	y[2027].benefits.state_pension.age_women	67
default	3	y[2027].benefits.state_pension.citizens_pension	False
default	3	y[2027].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2027].social_care.insurance.actuarially_fair	False
default	3	y[2027].social_care.insurance.contribution	none
default	3	y[2027].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2027].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2027].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2027].social_care.means_test.non_residential.income.abolish	False
default	3	y[2027].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2027].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2027].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2027].social_care.means_test.residential.assets.abolish	False
default	3	y[2027].social_care.means_test.residential.assets.include_property	True
default	3	y[2027].social_care.means_test.residential.assets.taper	0.0
default	3	y[2027].social_care.means_test.residential.income.abolish	False
default	3	y[2027].social_care.means_test.residential.income.floor	35.0
default	3	y[2027].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2027].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2027].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2027].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2027].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2027].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2027].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2027].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2027].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2027].social_care.options.abolish	False
default	3	y[2027].social_care.options.preserve_for_existing_claimants	False
default	3	y[2028].benefits.attendance_allowance.high_age	150
default	3	y[2028].benefits.attendance_allowance.low_age	65
default	3	y[2028].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2028].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2028].benefits.dla.care.high_age	64
default	3	y[2028].benefits.dla.care.low_age	3
default	3	y[2028].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2028].benefits.dla.care.test_generosity	1.0
default	3	y[2028].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2028].benefits.dla.mobility.high_age	64
default	3	y[2028].benefits.dla.mobility.low_age	0
default	3	y[2028].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2028].benefits.dla.mobility.test_generosity	1.0
default	3	y[2028].benefits.attendance_allowance.low_rate	 7.12487220822908E+01
default	3	y[2028].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2028].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2028].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2028].benefits.state_pension.age_men	67
default	3	y[2028].benefits.state_pension.age_women	67
default	3	y[2028].benefits.state_pension.citizens_pension	False
default	3	y[2028].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2028].social_care.insurance.actuarially_fair	False
default	3	y[2028].social_care.insurance.contribution	none
default	3	y[2028].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2028].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2028].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2028].social_care.means_test.non_residential.income.abolish	False
default	3	y[2028].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2028].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2028].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2028].social_care.means_test.residential.assets.abolish	False
default	3	y[2028].social_care.means_test.residential.assets.include_property	True
default	3	y[2028].social_care.means_test.residential.assets.taper	0.0
default	3	y[2028].social_care.means_test.residential.income.abolish	False
default	3	y[2028].social_care.means_test.residential.income.floor	35.0
default	3	y[2028].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2028].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2028].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2028].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2028].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2028].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2028].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2028].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2028].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2028].social_care.options.abolish	False
default	3	y[2028].social_care.options.preserve_for_existing_claimants	False
default	3	y[2029].benefits.attendance_allowance.high_age	150
default	3	y[2029].benefits.attendance_allowance.low_age	65
default	3	y[2029].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2029].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2029].benefits.dla.care.high_age	64
default	3	y[2029].benefits.dla.care.low_age	3
default	3	y[2029].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2029].benefits.dla.care.test_generosity	1.0
default	3	y[2029].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2029].benefits.dla.mobility.high_age	64
default	3	y[2029].benefits.dla.mobility.low_age	0
default	3	y[2029].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2029].benefits.dla.mobility.test_generosity	1.0
default	3	y[2028].benefits.pension_credit.savings_credit.maximum_single	 2.54763993713726E+01
default	3	y[2029].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2029].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2029].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2029].benefits.state_pension.age_men	67
default	3	y[2029].benefits.state_pension.age_women	67
default	3	y[2029].benefits.state_pension.citizens_pension	False
default	3	y[2029].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2029].social_care.insurance.actuarially_fair	False
default	3	y[2029].social_care.insurance.contribution	none
default	3	y[2029].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2029].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2029].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2029].social_care.means_test.non_residential.income.abolish	False
default	3	y[2029].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2029].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2029].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2029].social_care.means_test.residential.assets.abolish	False
default	3	y[2029].social_care.means_test.residential.assets.include_property	True
default	3	y[2029].social_care.means_test.residential.assets.taper	0.0
default	3	y[2029].social_care.means_test.residential.income.abolish	False
default	3	y[2029].social_care.means_test.residential.income.floor	35.0
default	3	y[2029].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2029].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2029].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2029].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2029].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2029].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2029].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2029].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2029].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2029].social_care.options.abolish	False
default	3	y[2029].social_care.options.preserve_for_existing_claimants	False
default	3	y[2030].benefits.attendance_allowance.high_age	150
default	3	y[2030].benefits.attendance_allowance.low_age	65
default	3	y[2030].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2030].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2030].benefits.dla.care.high_age	64
default	3	y[2030].benefits.dla.care.low_age	3
default	3	y[2030].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2030].benefits.dla.care.test_generosity	1.0
default	3	y[2030].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2030].benefits.dla.mobility.high_age	64
default	3	y[2030].benefits.dla.mobility.low_age	0
default	3	y[2030].av_costs.residential_per_week	 7.10534305030752E+02
default	3	y[2030].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2030].benefits.dla.mobility.test_generosity	1.0
default	3	y[2030].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2030].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2030].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2030].benefits.state_pension.age_men	67
default	3	y[2030].benefits.state_pension.age_women	67
default	3	y[2030].benefits.state_pension.citizens_pension	False
default	3	y[2030].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2030].social_care.insurance.actuarially_fair	False
default	3	y[2030].social_care.insurance.contribution	none
default	3	y[2030].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2030].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2030].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2030].social_care.means_test.non_residential.income.abolish	False
default	3	y[2030].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2030].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2030].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2030].social_care.means_test.residential.assets.abolish	False
default	3	y[2030].social_care.means_test.residential.assets.include_property	True
default	3	y[2030].social_care.means_test.residential.assets.taper	0.0
default	3	y[2030].social_care.means_test.residential.income.abolish	False
default	3	y[2030].social_care.means_test.residential.income.floor	35.0
default	3	y[2030].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2030].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2030].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2030].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2030].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2030].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2030].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2030].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2030].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2030].social_care.options.abolish	False
default	3	y[2030].social_care.options.preserve_for_existing_claimants	False
default	3	y[2012].av_costs.hour_of_care	14.60
default	3	y[2012].av_costs.residential_per_week	497.0
default	3	y[2012].benefits.attendance_allowance.high_age	150
default	3	y[2012].benefits.attendance_allowance.high_rate	77.45
default	3	y[2012].benefits.attendance_allowance.low_age	65
default	3	y[2012].benefits.attendance_allowance.low_rate	51.85
default	3	y[2012].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2012].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2012].benefits.dla.care.high_age	64
default	3	y[2012].benefits.dla.care.high_rate	77.45
default	3	y[2012].benefits.dla.care.low_age	3
default	3	y[2012].benefits.dla.care.low_rate	20.55
default	3	y[2012].benefits.dla.care.middle_rate	51.85
default	3	y[2012].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2012].benefits.dla.care.test_generosity	1.0
default	3	y[2012].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2012].benefits.dla.mobility.high_age	64
default	3	y[2012].benefits.dla.mobility.high_rate	54.05
default	3	y[2030].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 7.14823244497739E+01
default	3	y[2012].benefits.dla.mobility.low_age	0
default	3	y[2012].benefits.dla.mobility.low_rate	20.55
default	3	y[2012].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2012].benefits.dla.mobility.test_generosity	1.0
default	3	y[2012].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	3	y[2012].benefits.pension_credit.guaranteed_credit.couple	217.90
default	3	y[2012].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2012].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	3	y[2012].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	3	y[2012].benefits.pension_credit.guaranteed_credit.single	142.70
default	3	y[2012].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	3	y[2012].benefits.pension_credit.savings_credit.maximum_single	18.54
default	3	y[2012].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2012].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	3	y[2012].benefits.pension_credit.savings_credit.threshold_single	111.80
default	3	y[2012].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2012].benefits.state_pension.age_men	65
default	3	y[2012].benefits.state_pension.age_women	60
default	3	y[2012].benefits.state_pension.citizens_pension	False
default	3	y[2012].benefits.state_pension.class_a	102.15
default	3	y[2012].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2012].social_care.insurance.actuarially_fair	False
default	3	y[2012].social_care.insurance.contribution	none
default	3	y[2012].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	3	y[2012].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	3	y[2012].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	3	y[2012].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2012].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2012].social_care.means_test.non_residential.assets.lower_limit	22500
default	3	y[2012].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2012].social_care.means_test.non_residential.assets.upper_limit	22500
default	3	y[2012].social_care.means_test.non_residential.income.abolish	False
default	3	y[2012].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2012].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2012].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2012].social_care.means_test.residential.assets.abolish	False
default	3	y[2012].social_care.means_test.residential.assets.include_property	True
default	3	y[2012].social_care.means_test.residential.assets.lower_limit	22500
default	3	y[2012].social_care.means_test.residential.assets.taper	0.0
default	3	y[2012].social_care.means_test.residential.assets.upper_limit	22500.0
default	3	y[2012].social_care.means_test.residential.income.abolish	False
default	3	y[2012].social_care.means_test.residential.income.floor	35.0
default	3	y[2012].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2012].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2012].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2012].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2012].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2012].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2012].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2012].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2012].social_care.options.abolish	False
default	3	y[2012].social_care.options.preserve_for_existing_claimants	False
default	3	y[2013].benefits.attendance_allowance.high_age	150
default	3	y[2013].benefits.attendance_allowance.low_age	65
default	3	y[2013].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2013].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2013].benefits.dla.care.high_age	64
default	3	y[2013].benefits.dla.care.low_age	3
default	3	y[2013].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2013].benefits.dla.care.test_generosity	1.0
default	3	y[2013].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2013].av_costs.hour_of_care	 1.49066000000000E+01
default	3	y[2013].benefits.dla.mobility.high_age	64
default	3	y[2013].benefits.dla.mobility.low_age	0
default	3	y[2013].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2013].benefits.dla.mobility.test_generosity	1.0
default	3	y[2013].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2013].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2013].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2013].benefits.state_pension.age_men	65
default	3	y[2013].benefits.state_pension.age_women	60
default	3	y[2013].benefits.state_pension.citizens_pension	False
default	3	y[2013].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2013].social_care.insurance.actuarially_fair	False
default	3	y[2013].social_care.insurance.contribution	none
default	3	y[2013].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2013].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2013].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2013].social_care.means_test.non_residential.income.abolish	False
default	3	y[2013].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2013].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2013].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2013].social_care.means_test.residential.assets.abolish	False
default	3	y[2013].social_care.means_test.residential.assets.include_property	True
default	3	y[2013].social_care.means_test.residential.assets.taper	0.0
default	3	y[2013].social_care.means_test.residential.income.abolish	False
default	3	y[2013].social_care.means_test.residential.income.floor	35.0
default	3	y[2013].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2013].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2013].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2013].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2013].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2013].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2013].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2013].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2013].social_care.options.abolish	False
default	3	y[2013].social_care.options.preserve_for_existing_claimants	False
default	3	y[2014].benefits.attendance_allowance.high_age	150
default	3	y[2014].benefits.attendance_allowance.low_age	65
default	3	y[2014].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2014].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2014].benefits.dla.care.high_age	64
default	3	y[2014].benefits.dla.care.low_age	3
default	3	y[2014].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2013].social_care.means_test.non_residential.assets.lower_limit	 2.29725000000000E+04
default	3	y[2014].benefits.dla.care.test_generosity	1.0
default	3	y[2014].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2014].benefits.dla.mobility.high_age	64
default	3	y[2014].benefits.dla.mobility.low_age	0
default	3	y[2014].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2014].benefits.dla.mobility.test_generosity	1.0
default	3	y[2014].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2014].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2014].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2014].benefits.state_pension.age_men	65
default	3	y[2014].benefits.state_pension.age_women	60
default	3	y[2014].benefits.state_pension.citizens_pension	False
default	3	y[2014].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2014].social_care.insurance.actuarially_fair	False
default	3	y[2014].social_care.insurance.contribution	none
default	3	y[2014].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2014].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2014].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2014].social_care.means_test.non_residential.income.abolish	False
default	3	y[2014].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2014].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2014].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2014].social_care.means_test.residential.assets.abolish	False
default	3	y[2014].social_care.means_test.residential.assets.include_property	True
default	3	y[2014].social_care.means_test.residential.assets.taper	0.0
default	3	y[2014].social_care.means_test.residential.income.abolish	False
default	3	y[2014].social_care.means_test.residential.income.floor	35.0
default	3	y[2014].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2014].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2014].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2014].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2014].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2014].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2014].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2014].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2014].social_care.options.abolish	False
default	3	y[2014].social_care.options.preserve_for_existing_claimants	False
default	3	y[2015].benefits.attendance_allowance.high_age	150
default	3	y[2015].benefits.attendance_allowance.low_age	65
default	3	y[2015].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2015].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2015].benefits.dla.care.high_age	64
default	3	y[2015].benefits.dla.care.low_age	3
default	3	y[2015].av_costs.hour_of_care	 1.55088266400000E+01
default	3	y[2015].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2015].benefits.dla.care.test_generosity	1.0
default	3	y[2015].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2015].benefits.dla.mobility.high_age	64
default	3	y[2015].benefits.dla.mobility.low_age	0
default	3	y[2015].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2015].benefits.dla.mobility.test_generosity	1.0
default	3	y[2015].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2015].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2015].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2015].benefits.state_pension.age_men	65
default	3	y[2015].benefits.state_pension.age_women	60
default	3	y[2015].benefits.state_pension.citizens_pension	False
default	3	y[2015].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2015].social_care.insurance.actuarially_fair	False
default	3	y[2015].social_care.insurance.contribution	none
default	3	y[2015].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2015].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2015].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2015].social_care.means_test.non_residential.income.abolish	False
default	3	y[2015].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2015].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2015].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2015].social_care.means_test.residential.assets.abolish	False
default	3	y[2015].social_care.means_test.residential.assets.include_property	True
default	3	y[2015].social_care.means_test.residential.assets.taper	0.0
default	3	y[2015].social_care.means_test.residential.income.abolish	False
default	3	y[2015].social_care.means_test.residential.income.floor	35.0
default	3	y[2015].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2015].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2015].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2015].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2015].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2015].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2015].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2015].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2015].social_care.options.abolish	False
default	3	y[2015].social_care.options.preserve_for_existing_claimants	False
default	3	y[2016].benefits.attendance_allowance.high_age	150
default	3	y[2016].benefits.attendance_allowance.low_age	65
default	3	y[2016].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2016].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2016].benefits.dla.care.high_age	64
default	3	y[2016].benefits.dla.care.low_age	3
default	3	y[2016].av_costs.residential_per_week	 5.38496203896001E+02
default	3	y[2016].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2016].benefits.dla.care.test_generosity	1.0
default	3	y[2016].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2016].benefits.dla.mobility.high_age	64
default	3	y[2016].benefits.dla.mobility.low_age	0
default	3	y[2016].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2016].benefits.dla.mobility.test_generosity	1.0
default	3	y[2016].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2016].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2016].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2016].benefits.state_pension.age_men	65
default	3	y[2016].benefits.state_pension.age_women	61
default	3	y[2016].benefits.state_pension.citizens_pension	False
default	3	y[2016].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2016].social_care.insurance.actuarially_fair	False
default	3	y[2016].social_care.insurance.contribution	none
default	3	y[2016].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2016].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2016].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2016].social_care.means_test.non_residential.income.abolish	False
default	3	y[2016].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2016].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2016].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2016].social_care.means_test.residential.assets.abolish	False
default	3	y[2016].social_care.means_test.residential.assets.include_property	True
default	3	y[2016].social_care.means_test.residential.assets.taper	0.0
default	3	y[2016].social_care.means_test.residential.income.abolish	False
default	3	y[2016].social_care.means_test.residential.income.floor	35.0
default	3	y[2016].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2016].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2016].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2016].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2016].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2016].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2016].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2016].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2016].social_care.options.abolish	False
default	3	y[2016].social_care.options.preserve_for_existing_claimants	False
default	3	y[2017].benefits.attendance_allowance.high_age	150
default	3	y[2017].benefits.attendance_allowance.low_age	65
default	3	y[2017].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2017].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2017].benefits.dla.care.high_age	64
default	3	y[2016].social_care.means_test.non_residential.assets.upper_limit	 2.43786007800001E+04
default	3	y[2017].benefits.dla.care.low_age	3
default	3	y[2017].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2017].benefits.dla.care.test_generosity	1.0
default	3	y[2017].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2017].benefits.dla.mobility.high_age	64
default	3	y[2017].benefits.dla.mobility.low_age	0
default	3	y[2017].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2017].benefits.dla.mobility.test_generosity	1.0
default	3	y[2017].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2017].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2017].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2017].benefits.state_pension.age_men	65
default	3	y[2017].benefits.state_pension.age_women	63
default	3	y[2017].benefits.state_pension.citizens_pension	False
default	3	y[2017].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2017].social_care.insurance.actuarially_fair	False
default	3	y[2017].social_care.insurance.contribution	none
default	3	y[2017].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2017].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2017].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2017].social_care.means_test.non_residential.income.abolish	False
default	3	y[2017].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2017].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2017].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2017].social_care.means_test.residential.assets.abolish	False
default	3	y[2017].social_care.means_test.residential.assets.include_property	True
default	3	y[2017].social_care.means_test.residential.assets.taper	0.0
default	3	y[2017].social_care.means_test.residential.income.abolish	False
default	3	y[2017].social_care.means_test.residential.income.floor	35.0
default	3	y[2017].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2017].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2017].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2017].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2017].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2017].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2017].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2017].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2017].social_care.options.abolish	False
default	3	y[2017].social_care.options.preserve_for_existing_claimants	False
default	3	y[2018].benefits.attendance_allowance.high_age	150
default	3	y[2018].benefits.attendance_allowance.low_age	65
default	3	y[2018].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2017].social_care.means_test.non_residential.assets.lower_limit	 2.48661727956000E+04
default	3	y[2018].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2018].benefits.dla.care.high_age	64
default	3	y[2018].benefits.dla.care.low_age	3
default	3	y[2018].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2018].benefits.dla.care.test_generosity	1.0
default	3	y[2018].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2018].benefits.dla.mobility.high_age	64
default	3	y[2018].benefits.dla.mobility.low_age	0
default	3	y[2018].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2018].benefits.dla.mobility.test_generosity	1.0
default	3	y[2018].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2018].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2018].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2018].benefits.state_pension.age_men	65
default	3	y[2018].benefits.state_pension.age_women	65
default	3	y[2018].benefits.state_pension.citizens_pension	False
default	3	y[2018].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2018].social_care.insurance.actuarially_fair	False
default	3	y[2018].social_care.insurance.contribution	none
default	3	y[2018].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2018].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2018].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2018].social_care.means_test.non_residential.income.abolish	False
default	3	y[2018].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2018].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2018].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2018].social_care.means_test.residential.assets.abolish	False
default	3	y[2018].social_care.means_test.residential.assets.include_property	True
default	3	y[2018].social_care.means_test.residential.assets.taper	0.0
default	3	y[2018].social_care.means_test.residential.income.abolish	False
default	3	y[2018].social_care.means_test.residential.income.floor	35.0
default	3	y[2018].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2018].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2018].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2018].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2018].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2018].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2018].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2018].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2018].social_care.options.abolish	False
default	3	y[2018].social_care.options.preserve_for_existing_claimants	False
default	3	y[2019].benefits.attendance_allowance.high_age	150
default	3	y[2019].benefits.attendance_allowance.low_age	65
default	3	y[2018].benefits.dla.care.high_rate	 8.73067904302049E+01
default	3	y[2019].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2019].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2019].benefits.dla.care.high_age	64
default	3	y[2019].benefits.dla.care.low_age	3
default	3	y[2019].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2019].benefits.dla.care.test_generosity	1.0
default	3	y[2019].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2019].benefits.dla.mobility.high_age	64
default	3	y[2019].benefits.dla.mobility.low_age	0
default	3	y[2019].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2019].benefits.dla.mobility.test_generosity	1.0
default	3	y[2019].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2019].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2019].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2019].benefits.state_pension.age_men	65
default	3	y[2019].benefits.state_pension.age_women	65
default	3	y[2019].benefits.state_pension.citizens_pension	False
default	3	y[2019].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2019].social_care.insurance.actuarially_fair	False
default	3	y[2019].social_care.insurance.contribution	none
default	3	y[2019].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2019].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2019].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2019].social_care.means_test.non_residential.income.abolish	False
default	3	y[2019].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2019].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2019].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2019].social_care.means_test.residential.assets.abolish	False
default	3	y[2019].social_care.means_test.residential.assets.include_property	True
default	3	y[2019].social_care.means_test.residential.assets.taper	0.0
default	3	y[2019].social_care.means_test.residential.income.abolish	False
default	3	y[2019].social_care.means_test.residential.income.floor	35.0
default	3	y[2019].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2019].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2019].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2019].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2019].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2019].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2019].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2019].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2019].social_care.options.abolish	False
default	3	y[2019].social_care.options.preserve_for_existing_claimants	False
default	3	y[2020].benefits.attendance_allowance.high_age	150
default	3	y[2019].benefits.state_pension.class_a	 1.17453278441502E+02
default	3	y[2020].benefits.attendance_allowance.low_age	65
default	3	y[2020].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2020].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2020].benefits.dla.care.high_age	64
default	3	y[2020].benefits.dla.care.low_age	3
default	3	y[2020].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2020].benefits.dla.care.test_generosity	1.0
default	3	y[2020].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2020].benefits.dla.mobility.high_age	64
default	3	y[2020].benefits.dla.mobility.low_age	0
default	3	y[2020].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2020].benefits.dla.mobility.test_generosity	1.0
default	3	y[2020].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2020].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2020].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2020].benefits.state_pension.age_men	66
default	3	y[2020].benefits.state_pension.age_women	66
default	3	y[2020].benefits.state_pension.citizens_pension	False
default	3	y[2020].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2020].social_care.insurance.actuarially_fair	False
default	3	y[2020].social_care.insurance.contribution	none
default	3	y[2020].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2020].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2020].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2020].social_care.means_test.non_residential.income.abolish	False
default	3	y[2020].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2020].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2020].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2020].social_care.means_test.residential.assets.abolish	False
default	3	y[2020].social_care.means_test.residential.assets.include_property	True
default	3	y[2020].social_care.means_test.residential.assets.taper	0.0
default	3	y[2020].social_care.means_test.residential.income.abolish	False
default	3	y[2020].social_care.means_test.residential.income.floor	35.0
default	3	y[2020].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2020].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2020].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2020].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2020].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2020].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2020].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2020].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2020].social_care.options.abolish	False
default	3	y[2020].social_care.options.preserve_for_existing_claimants	False
default	3	y[2021].benefits.attendance_allowance.high_age	150
default	3	y[2021].benefits.attendance_allowance.low_age	65
default	3	y[2021].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2021].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2021].benefits.dla.care.high_age	64
default	3	y[2021].benefits.dla.care.low_age	3
default	3	y[2021].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2021].benefits.dla.care.test_generosity	1.0
default	3	y[2021].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2021].benefits.dla.mobility.high_age	64
default	3	y[2021].benefits.dla.mobility.low_age	0
default	3	y[2021].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2021].benefits.dla.mobility.test_generosity	1.0
default	3	y[2021].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2021].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2021].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2021].benefits.state_pension.age_men	66
default	3	y[2021].benefits.state_pension.age_women	66
default	3	y[2021].benefits.state_pension.citizens_pension	False
default	3	y[2021].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2021].social_care.insurance.actuarially_fair	False
default	3	y[2021].social_care.insurance.contribution	none
default	3	y[2021].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2021].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2021].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2021].social_care.means_test.non_residential.income.abolish	False
default	3	y[2021].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2021].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2021].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2021].social_care.means_test.residential.assets.abolish	False
default	3	y[2021].social_care.means_test.residential.assets.include_property	True
default	3	y[2021].social_care.means_test.residential.assets.taper	0.0
default	3	y[2021].social_care.means_test.residential.income.abolish	False
default	3	y[2021].social_care.means_test.residential.income.floor	35.0
default	3	y[2021].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2021].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2021].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2021].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2021].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2021].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2021].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2021].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2021].social_care.options.abolish	False
default	3	y[2021].social_care.options.preserve_for_existing_claimants	False
default	3	y[2022].benefits.attendance_allowance.high_age	150
default	3	y[2022].benefits.attendance_allowance.low_age	65
default	3	y[2022].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2022].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2022].benefits.dla.care.high_age	64
default	3	y[2022].benefits.dla.care.low_age	3
default	3	y[2022].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2022].benefits.dla.care.test_generosity	1.0
default	3	y[2022].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2022].benefits.dla.mobility.high_age	64
default	3	y[2022].benefits.dla.mobility.low_age	0
default	3	y[2022].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2022].benefits.dla.mobility.test_generosity	1.0
default	3	y[2022].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2022].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2022].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2022].benefits.state_pension.age_men	66
default	3	y[2022].benefits.state_pension.age_women	66
default	3	y[2022].benefits.state_pension.citizens_pension	False
default	3	y[2022].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2022].social_care.insurance.actuarially_fair	False
default	3	y[2022].social_care.insurance.contribution	none
default	3	y[2022].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2022].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2022].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2022].social_care.means_test.non_residential.income.abolish	False
default	3	y[2022].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2022].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2022].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2022].social_care.means_test.residential.assets.abolish	False
default	3	y[2022].social_care.means_test.residential.assets.include_property	True
default	3	y[2022].social_care.means_test.residential.assets.taper	0.0
default	3	y[2022].social_care.means_test.residential.income.abolish	False
default	3	y[2022].social_care.means_test.residential.income.floor	35.0
default	3	y[2022].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2022].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2022].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2022].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2022].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2022].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2022].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2022].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2022].social_care.options.abolish	False
default	3	y[2022].social_care.options.preserve_for_existing_claimants	False
default	3	y[2022].benefits.state_pension.class_a	 1.24642358708350E+02
default	3	y[2023].benefits.attendance_allowance.high_age	150
default	3	y[2023].benefits.attendance_allowance.low_age	65
default	3	y[2023].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2023].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2023].benefits.dla.care.high_age	64
default	3	y[2023].benefits.dla.care.low_age	3
default	3	y[2023].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2023].benefits.dla.care.test_generosity	1.0
default	3	y[2023].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2023].benefits.dla.mobility.high_age	64
default	3	y[2023].benefits.dla.mobility.low_age	0
default	3	y[2023].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2023].benefits.dla.mobility.test_generosity	1.0
default	3	y[2023].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2023].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2023].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2023].benefits.state_pension.age_men	66
default	3	y[2023].benefits.state_pension.age_women	66
default	3	y[2023].benefits.state_pension.citizens_pension	False
default	3	y[2023].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2023].social_care.insurance.actuarially_fair	False
default	3	y[2023].social_care.insurance.contribution	none
default	3	y[2023].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2023].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2023].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2023].social_care.means_test.non_residential.income.abolish	False
default	3	y[2023].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2023].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2023].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2023].social_care.means_test.residential.assets.abolish	False
default	3	y[2023].social_care.means_test.residential.assets.include_property	True
default	3	y[2023].social_care.means_test.residential.assets.taper	0.0
default	3	y[2023].social_care.means_test.residential.income.abolish	False
default	3	y[2023].social_care.means_test.residential.income.floor	35.0
default	3	y[2023].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2023].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2023].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2023].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2023].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2023].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2023].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2023].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2023].benefits.dla.care.high_rate	 9.63937513029946E+01
default	3	y[2023].social_care.options.abolish	False
default	3	y[2023].social_care.options.preserve_for_existing_claimants	False
default	3	y[2024].benefits.attendance_allowance.high_age	150
default	3	y[2024].benefits.attendance_allowance.low_age	65
default	3	y[2024].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2024].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2024].benefits.dla.care.high_age	64
default	3	y[2024].benefits.dla.care.low_age	3
default	3	y[2024].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2024].benefits.dla.care.test_generosity	1.0
default	3	y[2024].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2024].benefits.dla.mobility.high_age	64
default	3	y[2024].benefits.dla.mobility.low_age	0
default	3	y[2024].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2024].benefits.dla.mobility.test_generosity	1.0
default	3	y[2024].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2024].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2024].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2024].benefits.state_pension.age_men	66
default	3	y[2024].benefits.state_pension.age_women	66
default	3	y[2024].benefits.state_pension.citizens_pension	False
default	3	y[2024].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2024].social_care.insurance.actuarially_fair	False
default	3	y[2024].social_care.insurance.contribution	none
default	3	y[2024].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2024].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2024].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2024].social_care.means_test.non_residential.income.abolish	False
default	3	y[2024].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2024].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2024].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2024].social_care.means_test.residential.assets.abolish	False
default	3	y[2024].social_care.means_test.residential.assets.include_property	True
default	3	y[2024].social_care.means_test.residential.assets.taper	0.0
default	3	y[2024].social_care.means_test.residential.income.abolish	False
default	3	y[2024].social_care.means_test.residential.income.floor	35.0
default	3	y[2024].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2024].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2024].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2024].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2024].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2024].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2024].benefits.state_pension.class_a	 1.29677910000167E+02
default	3	y[2024].av_costs.hour_of_care	 1.85344834655158E+01
default	3	y[2024].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2024].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2024].social_care.options.abolish	False
default	3	y[2024].social_care.options.preserve_for_existing_claimants	False
default	3	y[2025].benefits.attendance_allowance.high_age	150
default	3	y[2025].benefits.attendance_allowance.low_age	65
default	3	y[2025].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2025].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2025].benefits.dla.care.high_age	64
default	3	y[2025].benefits.dla.care.low_age	3
default	3	y[2025].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2025].benefits.dla.care.test_generosity	1.0
default	3	y[2025].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2025].benefits.dla.mobility.high_age	64
default	3	y[2025].benefits.dla.mobility.low_age	0
default	3	y[2025].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2025].benefits.dla.mobility.test_generosity	1.0
default	3	y[2025].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2025].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2025].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2025].benefits.state_pension.age_men	66
default	3	y[2025].benefits.state_pension.age_women	66
default	3	y[2025].benefits.state_pension.citizens_pension	False
default	3	y[2025].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2025].social_care.insurance.actuarially_fair	False
default	3	y[2025].social_care.insurance.contribution	none
default	3	y[2025].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2025].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2025].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2025].social_care.means_test.non_residential.income.abolish	False
default	3	y[2025].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2025].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2025].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2025].social_care.means_test.residential.assets.abolish	False
default	3	y[2025].social_care.means_test.residential.assets.include_property	True
default	3	y[2025].social_care.means_test.residential.assets.taper	0.0
default	3	y[2025].social_care.means_test.residential.income.abolish	False
default	3	y[2025].social_care.means_test.residential.income.floor	35.0
default	3	y[2025].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2025].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2025].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2025].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2025].benefits.dla.mobility.high_rate	 6.99879868450241E+01
default	3	y[2025].benefits.dla.care.middle_rate	 6.71392621260777E+01
default	3	y[2025].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2025].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2025].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2025].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2025].social_care.options.abolish	False
default	3	y[2025].social_care.options.preserve_for_existing_claimants	False
default	3	y[2026].benefits.attendance_allowance.high_age	150
default	3	y[2026].benefits.attendance_allowance.low_age	65
default	3	y[2026].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2026].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2026].benefits.dla.care.high_age	64
default	3	y[2026].benefits.dla.care.low_age	3
default	3	y[2026].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2026].benefits.dla.care.test_generosity	1.0
default	3	y[2026].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2026].benefits.dla.mobility.high_age	64
default	3	y[2026].benefits.dla.mobility.low_age	0
default	3	y[2026].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2026].benefits.dla.mobility.test_generosity	1.0
default	3	y[2026].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2026].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	3	y[2026].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	3	y[2026].benefits.state_pension.age_men	66
default	3	y[2026].benefits.state_pension.age_women	66
default	3	y[2026].benefits.state_pension.citizens_pension	False
default	3	y[2026].benefits.state_pension.preserve_for_existing_claimants	False
default	3	y[2026].social_care.insurance.actuarially_fair	False
default	3	y[2026].social_care.insurance.contribution	none
default	3	y[2026].social_care.means_test.non_residential.assets.abolish	False
default	3	y[2026].social_care.means_test.non_residential.assets.include_property	False
default	3	y[2026].social_care.means_test.non_residential.assets.taper	0.0
default	3	y[2026].social_care.means_test.non_residential.income.abolish	False
default	3	y[2026].social_care.means_test.non_residential.income.floor	35.0
default	3	y[2026].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	3	y[2026].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	3	y[2026].social_care.means_test.residential.assets.abolish	False
default	3	y[2026].social_care.means_test.residential.assets.include_property	True
default	3	y[2026].social_care.means_test.residential.assets.taper	0.0
default	3	y[2026].social_care.means_test.residential.income.abolish	False
default	3	y[2026].social_care.means_test.residential.income.floor	35.0
default	3	y[2026].social_care.means_test.residential.income.minimum_support_level	0.0
default	3	y[2026].social_care.means_test.residential.income.percent_costs_met	0.0
default	3	y[2026].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	3	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	3	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	3	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	3	y[2026].social_care.means_test.residential.assets.upper_limit	 2.97173783181000E+04
default	3	y[2026].benefits.dla.care.high_rate	 1.02293820032749E+02
default	3	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	3	y[2026].social_care.needs_assessment_rules.uap_category_critical	5.5
default	3	y[2026].social_care.needs_assessment_rules.uap_category_low	10.0
default	3	y[2026].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	3	y[2026].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	3	y[2026].social_care.needs_assessment_rules.use_carer_blind_system	False
default	3	y[2026].social_care.options.abolish	False
default	3	y[2026].social_care.options.preserve_for_existing_claimants	False
default	3	y[2027].benefits.attendance_allowance.high_age	150
default	3	y[2027].benefits.attendance_allowance.low_age	65
default	3	y[2027].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	3	y[2027].benefits.attendance_allowance.test_generosity	1.0
default	3	y[2027].benefits.dla.care.high_age	64
default	3	y[2027].benefits.dla.care.low_age	3
default	3	y[2027].benefits.dla.care.preserve_for_existing_claimants	False
default	3	y[2027].benefits.dla.care.test_generosity	1.0
default	3	y[2027].benefits.dla.dont_pay_for_residential_claimants	False
default	3	y[2027].benefits.dla.mobility.high_age	64
default	3	y[2027].benefits.dla.mobility.low_age	0
default	3	y[2027].benefits.dla.mobility.preserve_for_existing_claimants	False
default	3	y[2027].benefits.dla.mobility.test_generosity	1.0
default	3	y[2027].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	3	y[2027].benefits.attendance_allowance.high_rate	 1.04339696433404E+02
default	3	y[2027].av_costs.residential_per_week	 6.69552345092339E+02
default	3	y[2027].benefits.dla.care.low_rate	 2.76847096411420E+01
default	3	y[2027].benefits.pension_credit.guaranteed_credit.couple	 2.93552225343301E+02
default	3	y[2027].benefits.dla.care.middle_rate	 6.98516883159714E+01
default	3	y[2027].benefits.dla.mobility.low_rate	 2.76847096411420E+01
default	3	y[2027].benefits.dla.mobility.high_rate	 7.28155015135632E+01
default	3	y[2027].benefits.dla.care.high_rate	 1.04339696433404E+02
default	3	y[2027].benefits.pension_credit.guaranteed_credit.carer_single	 4.39183228370427E+01
default	3	y[2027].av_costs.hour_of_care	 1.96689421294731E+01
default	3	y[2027].benefits.attendance_allowance.low_rate	 6.98516883159714E+01
default	2	y[2021].benefits.attendance_allowance.low_rate	 6.19655496830668E+01
default	2	y[2020].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.17165937983061E+09
default	2	y[2013].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.10000000000000E+01
default	2	y[2029].benefits.dla.care.high_rate	 1.08448697916453E+02
default	2	y[2022].social_care.means_test.non_residential.assets.lower_limit	 2.74273744498820E+04
default	2	y[2027].benefits.pension_credit.savings_credit.threshold_couple	 2.40035618140109E+02
default	2	y[2018].benefits.pension_credit.savings_credit.maximum_couple	 2.67238342091347E+01
default	2	y[2013].benefits.pension_credit.savings_credit.maximum_single	 1.89108000000000E+01
default	2	y[2018].benefits.state_pension.class_a	 1.15037491127818E+02
default	2	y[2018].social_care.means_test.maxima.maximum_lifetime_payment	 1.12616241926389E+12
default	2	y[2018].social_care.means_test.residential.assets.upper_limit	 2.53386544334400E+04
default	2	y[2023].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.44728769497138E+02
default	2	y[2018].benefits.pension_credit.savings_credit.threshold_couple	 2.00851067475734E+02
default	2	y[2021].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.19509256742722E+09
default	2	y[2022].benefits.pension_credit.savings_credit.threshold_single	 1.36283576155414E+02
default	2	y[2014].benefits.attendance_allowance.low_rate	 5.39447400000000E+01
default	2	y[2013].benefits.pension_credit.guaranteed_credit.severe_disability_single	 5.93640000000000E+01
default	2	y[2018].benefits.dla.mobility.high_rate	 6.08690787612192E+01
default	2	y[2020].benefits.dla.care.high_rate	 9.07450190586255E+01
default	2	y[2028].benefits.attendance_allowance.low_rate	 7.11789388089483E+01
default	2	y[2013].benefits.dla.mobility.low_rate	 2.09610000000000E+01
default	2	y[2026].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.67936640102592E+01
default	2	y[2021].benefits.pension_credit.guaranteed_credit.carer_single	 3.89600177370873E+01
default	2	y[2025].social_care.means_test.residential.assets.lower_limit	 2.91061491852104E+04
default	2	y[2013].benefits.pension_credit.savings_credit.threshold_single	 1.14036000000000E+02
default	2	y[2019].benefits.state_pension.class_a	 1.17338240950374E+02
default	2	y[2030].benefits.dla.care.middle_rate	 7.40545679368298E+01
default	2	y[2025].social_care.means_test.maxima.maximum_lifetime_payment	 1.29360663045367E+12
default	2	y[2022].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.21899441877576E+09
default	2	y[2014].benefits.attendance_allowance.high_rate	 8.05789800000000E+01
default	2	y[2025].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.46803315226898E+01
default	2	y[2021].benefits.pension_credit.savings_credit.maximum_couple	 2.83595466534074E+01
default	2	y[2016].social_care.means_test.non_residential.assets.upper_limit	 2.43547236000000E+04
default	2	y[2017].social_care.means_test.residential.assets.lower_limit	 2.48418180720000E+04
default	2	y[2023].benefits.pension_credit.savings_credit.maximum_single	 2.30521596776369E+01
default	2	y[2021].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.95543874938185E+01
default	2	y[2018].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.31085305602330E+02
default	2	y[2015].benefits.dla.care.high_rate	 8.21905596000000E+01
default	2	y[2021].social_care.means_test.residential.assets.upper_limit	 2.68895827940020E+04
default	2	y[2022].benefits.attendance_allowance.low_rate	 6.32048606767282E+01
default	2	y[2021].social_care.means_test.non_residential.assets.upper_limit	 2.68895827940020E+04
default	2	y[2028].benefits.pension_credit.savings_credit.maximum_couple	 3.25762047818002E+01
default	2	y[2015].benefits.pension_credit.guaranteed_credit.carer_single	 3.45953808000000E+01
default	2	y[2023].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.24337430715128E+09
default	2	y[2021].av_costs.residential_per_week	 5.93961006605289E+02
default	2	y[2013].benefits.pension_credit.savings_credit.maximum_couple	 2.42046000000000E+01
default	2	y[2019].social_care.means_test.maxima.maximum_lifetime_payment	 1.14868566764917E+12
default	2	y[2025].benefits.state_pension.class_a	 1.32141917300855E+02
default	2	y[2025].benefits.pension_credit.savings_credit.threshold_single	 1.44625221284734E+02
default	2	y[2025].social_care.means_test.non_residential.assets.upper_limit	 2.91061491852104E+04
default	2	y[2015].benefits.pension_credit.savings_credit.maximum_single	 1.96747963200000E+01
default	2	y[2028].social_care.means_test.residential.assets.upper_limit	 3.08876783645388E+04
default	2	y[2016].benefits.pension_credit.savings_credit.threshold_single	 1.21015915488000E+02
default	2	y[2015].benefits.dla.mobility.low_rate	 2.18078244000000E+01
default	2	y[2013].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.01999999898000E+09
default	2	y[2029].social_care.means_test.non_residential.assets.upper_limit	 3.15054319318296E+04
default	2	y[2013].social_care.means_test.residential.assets.upper_limit	 2.29500000000000E+04
default	2	y[2026].av_costs.residential_per_week	 6.55780945242248E+02
default	2	y[2015].benefits.dla.mobility.high_rate	 5.73582924000000E+01
default	2	y[2022].benefits.pension_credit.guaranteed_credit.carer_single	 3.97392180918291E+01
default	2	y[2022].benefits.pension_credit.savings_credit.threshold_couple	 2.17407654806065E+02
default	2	y[2025].av_costs.hour_of_care	 1.88866568046254E+01
default	2	y[2013].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.18728000000000E+02
default	2	y[2025].av_costs.residential_per_week	 6.42922495335537E+02
default	2	y[2026].social_care.means_test.maxima.maximum_lifetime_payment	 1.31947876306274E+12
default	2	y[2024].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.26824179329430E+09
default	2	y[2022].benefits.attendance_allowance.high_rate	 9.44111178285940E+01
default	2	y[2020].benefits.dla.mobility.low_rate	 2.40776002795966E+01
default	2	y[2016].benefits.dla.care.middle_rate	 5.61241074960000E+01
default	2	y[2019].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.74342833824640E+01
default	2	y[2029].benefits.attendance_allowance.low_rate	 7.26025175851272E+01
default	2	y[2016].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.29975517120000E+01
default	2	y[2013].benefits.pension_credit.savings_credit.threshold_couple	 1.81917000000000E+02
default	2	y[2020].social_care.means_test.residential.assets.lower_limit	 2.63623360725510E+04
default	2	y[2029].benefits.dla.mobility.high_rate	 7.56830487073506E+01
default	2	y[2027].social_care.means_test.residential.assets.lower_limit	 3.02820376122929E+04
default	2	y[2026].benefits.state_pension.class_a	 1.34784755646872E+02
default	2	y[2014].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.04039999895960E+09
default	2	y[2015].benefits.attendance_allowance.low_rate	 5.50236348000000E+01
default	2	y[2024].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.34120897281273E+01
default	2	y[2030].benefits.attendance_allowance.low_rate	 7.40545679368298E+01
default	2	y[2016].benefits.dla.mobility.low_rate	 2.22439808880000E+01
default	2	y[2026].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.53587328020518E+02
default	2	y[2020].benefits.dla.care.low_rate	 2.40776002795966E+01
default	2	y[2018].benefits.pension_credit.guaranteed_credit.single	 1.60703377228973E+02
default	2	y[2021].benefits.dla.mobility.low_rate	 2.45591522851885E+01
default	2	y[2014].social_care.means_test.non_residential.assets.lower_limit	 2.34090000000000E+04
default	2	y[2028].benefits.pension_credit.savings_credit.threshold_single	 1.53477441829130E+02
default	2	y[2021].benefits.dla.care.middle_rate	 6.19655496830668E+01
default	2	y[2025].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.29360662916019E+09
default	2	y[2016].benefits.pension_credit.guaranteed_credit.single	 1.54463069232000E+02
default	2	y[2021].benefits.dla.care.low_rate	 2.45591522851885E+01
default	2	y[2014].benefits.pension_credit.guaranteed_credit.single	 1.48465080000000E+02
default	2	y[2029].benefits.pension_credit.guaranteed_credit.severe_disability_single	 8.14940505969991E+01
default	2	y[2014].av_costs.hour_of_care	 1.51898400000000E+01
default	2	y[2019].social_care.means_test.residential.assets.lower_limit	 2.58454275221088E+04
default	2	y[2018].social_care.means_test.non_residential.assets.lower_limit	 2.53386544334400E+04
default	2	y[2025].benefits.pension_credit.savings_credit.maximum_single	 2.39834669286134E+01
default	2	y[2015].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.06120799893879E+09
default	2	y[2016].benefits.pension_credit.guaranteed_credit.carer_single	 3.52872884160000E+01
default	2	y[2026].benefits.dla.care.middle_rate	 6.84149738648099E+01
default	2	y[2030].benefits.attendance_allowance.high_rate	 1.10617671874782E+02
default	2	y[2019].benefits.pension_credit.savings_credit.threshold_single	 1.28423057643190E+02
default	2	y[2027].benefits.state_pension.class_a	 1.37480450759810E+02
default	2	y[2023].benefits.pension_credit.savings_credit.maximum_couple	 2.95052723382051E+01
default	2	y[2021].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.39108774987637E+02
default	2	y[2022].benefits.dla.care.low_rate	 2.50503353308923E+01
default	2	y[2023].social_care.means_test.non_residential.assets.lower_limit	 2.79759219388797E+04
default	2	y[2017].benefits.dla.mobility.low_rate	 2.26888605057600E+01
default	2	y[2025].benefits.pension_credit.savings_credit.threshold_couple	 2.30714742541435E+02
default	2	y[2027].social_care.means_test.maxima.maximum_lifetime_payment	 1.34586833832400E+12
default	2	y[2026].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.31947876174339E+09
default	2	y[2017].benefits.attendance_allowance.high_rate	 8.55110582078400E+01
default	2	y[2023].benefits.pension_credit.guaranteed_credit.single	 1.77429513807917E+02
default	2	y[2030].benefits.dla.care.high_rate	 1.10617671874782E+02
default	2	y[2022].benefits.dla.mobility.low_rate	 2.50503353308923E+01
default	2	y[2023].social_care.means_test.residential.assets.upper_limit	 2.79759219388797E+04
default	2	y[2029].benefits.pension_credit.guaranteed_credit.single	 1.99814450518759E+02
default	2	y[2027].social_care.means_test.non_residential.assets.lower_limit	 3.02820376122929E+04
default	2	y[2017].benefits.pension_credit.savings_credit.maximum_single	 2.04696580913280E+01
default	2	y[2023].benefits.pension_credit.guaranteed_credit.carer_single	 4.05340024536657E+01
default	2	y[2021].benefits.pension_credit.guaranteed_credit.single	 1.70539709542404E+02
default	2	y[2023].benefits.attendance_allowance.low_rate	 6.44689578902627E+01
default	2	y[2024].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.38116724435401E+01
default	2	y[2028].benefits.state_pension.class_a	 1.40230059775006E+02
default	2	y[2016].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.08243215891757E+09
default	2	y[2025].benefits.pension_credit.guaranteed_credit.single	 1.84597666165757E+02
default	2	y[2015].benefits.pension_credit.savings_credit.maximum_couple	 2.51824658400000E+01
default	2	y[2023].benefits.dla.care.low_rate	 2.55513420375101E+01
default	2	y[2016].benefits.pension_credit.savings_credit.threshold_couple	 1.93051775736000E+02
default	2	y[2020].benefits.pension_credit.savings_credit.threshold_single	 1.30991518796053E+02
default	2	y[2017].av_costs.residential_per_week	 5.48728159190400E+02
default	2	y[2030].benefits.pension_credit.guaranteed_credit.carer_single	 4.65608276709865E+01
default	2	y[2015].social_care.means_test.residential.assets.upper_limit	 2.38771800000000E+04
default	2	y[2018].benefits.dla.mobility.low_rate	 2.31426377158752E+01
default	2	y[2013].social_care.means_test.non_residential.assets.upper_limit	 2.29500000000000E+04
default	2	y[2019].benefits.dla.mobility.high_rate	 6.20864603364436E+01
default	2	y[2018].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.63081209632000E+01
default	2	y[2022].social_care.means_test.residential.assets.lower_limit	 2.74273744498820E+04
default	2	y[2024].benefits.dla.care.low_rate	 2.60623688782603E+01
default	2	y[2026].benefits.dla.mobility.high_rate	 7.13178271435482E+01
default	2	y[2023].benefits.dla.mobility.low_rate	 2.55513420375101E+01
default	2	y[2022].av_costs.residential_per_week	 6.05840226737394E+02
default	2	y[2023].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.21687154197326E+01
default	2	y[2016].benefits.attendance_allowance.low_rate	 5.61241074960000E+01
default	2	y[2028].benefits.dla.care.high_rate	 1.06322252859268E+02
default	2	y[2017].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.10408080209592E+09
default	2	y[2017].benefits.pension_credit.guaranteed_credit.carer_single	 3.59930341843200E+01
default	2	y[2025].benefits.dla.care.low_rate	 2.65836162558255E+01
default	2	y[2025].benefits.dla.care.high_rate	 1.00189833528647E+02
default	2	y[2027].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.34586833697826E+09
default	2	y[2017].social_care.means_test.non_residential.assets.upper_limit	 2.48418180720000E+04
default	2	y[2016].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.25995103424000E+02
default	2	y[2029].benefits.state_pension.class_a	 1.43034660970506E+02
default	2	y[2014].benefits.pension_credit.guaranteed_credit.couple	 2.26703160000000E+02
default	2	y[2029].social_care.means_test.residential.assets.lower_limit	 3.15054319318296E+04
default	2	y[2029].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.62988101193998E+02
default	2	y[2022].social_care.means_test.non_residential.assets.upper_limit	 2.74273744498820E+04
default	2	y[2018].benefits.pension_credit.guaranteed_credit.couple	 2.45390791157626E+02
default	2	y[2025].benefits.attendance_allowance.high_rate	 1.00189833528647E+02
default	2	y[2014].social_care.means_test.residential.assets.lower_limit	 2.34090000000000E+04
default	2	y[2019].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.68535058571881E+01
default	2	y[2022].benefits.dla.care.high_rate	 9.44111178285940E+01
default	2	y[2028].benefits.pension_credit.savings_credit.threshold_couple	 2.44836330502911E+02
default	2	y[2020].benefits.pension_credit.savings_credit.maximum_single	 2.17225649237820E+01
default	2	y[2016].benefits.pension_credit.guaranteed_credit.couple	 2.35861967664000E+02
default	2	y[2024].benefits.pension_credit.guaranteed_credit.carer_single	 4.13446825027390E+01
default	2	y[2026].benefits.dla.care.low_rate	 2.71152885809420E+01
default	2	y[2019].benefits.dla.mobility.low_rate	 2.36054904701927E+01
default	2	y[2020].benefits.attendance_allowance.high_rate	 9.07450190586255E+01
default	2	y[2023].benefits.pension_credit.savings_credit.threshold_single	 1.39009247678522E+02
default	2	y[2018].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.12616241813784E+09
default	2	y[2028].social_care.means_test.maxima.maximum_lifetime_payment	 1.37278570509048E+12
default	2	y[2028].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.37278570371783E+09
default	2	y[2025].benefits.pension_credit.savings_credit.maximum_couple	 3.06972853406686E+01
default	2	y[2024].benefits.dla.mobility.low_rate	 2.60623688782603E+01
default	2	y[2017].benefits.dla.care.middle_rate	 5.72465896459200E+01
default	2	y[2013].av_costs.hour_of_care	 1.48920000000000E+01
default	2	y[2019].benefits.pension_credit.savings_credit.threshold_couple	 2.04868088825249E+02
default	2	y[2021].benefits.pension_credit.guaranteed_credit.couple	 2.60410670702802E+02
default	2	y[2024].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.47623344887080E+02
default	2	y[2025].social_care.means_test.residential.assets.upper_limit	 2.91061491852104E+04
default	2	y[2014].benefits.pension_credit.savings_credit.threshold_single	 1.16316720000000E+02
default	2	y[2025].benefits.pension_credit.guaranteed_credit.couple	 2.81876884775882E+02
default	2	y[2014].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.05512800000000E+01
default	2	y[2024].benefits.attendance_allowance.low_rate	 6.57583370480680E+01
default	2	y[2028].benefits.dla.care.low_rate	 2.82107462396121E+01
default	2	y[2022].benefits.dla.care.middle_rate	 6.32048606767282E+01
default	2	y[2023].benefits.pension_credit.guaranteed_credit.couple	 2.70931261799195E+02
default	2	y[2020].benefits.pension_credit.savings_credit.threshold_couple	 2.08965450601754E+02
default	2	y[2029].benefits.pension_credit.guaranteed_credit.couple	 3.05112605242029E+02
default	2	y[2017].benefits.pension_credit.savings_credit.maximum_couple	 2.61998374599360E+01
default	2	y[2019].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.14868566650059E+09
default	2	y[2017].benefits.dla.care.high_rate	 8.55110582078400E+01
default	2	y[2029].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.40024141779218E+09
default	2	y[2018].benefits.pension_credit.guaranteed_credit.carer_single	 3.67128948680064E+01
default	2	y[2019].benefits.pension_credit.savings_credit.maximum_single	 2.12966322782177E+01
default	2	y[2023].benefits.dla.mobility.high_rate	 6.72043813687310E+01
default	2	y[2030].benefits.dla.mobility.high_rate	 7.71967096814976E+01
default	2	y[2025].benefits.dla.mobility.low_rate	 2.65836162558255E+01
default	2	y[2017].social_care.means_test.residential.assets.upper_limit	 2.48418180720000E+04
default	2	y[2029].benefits.dla.care.low_rate	 2.87749611644043E+01
default	2	y[2016].benefits.dla.mobility.high_rate	 5.85054582480000E+01
default	2	y[2017].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.52040401600000E+01
default	2	y[2030].benefits.dla.mobility.low_rate	 2.93504603876924E+01
default	2	y[2014].benefits.dla.care.high_rate	 8.05789800000000E+01
default	2	y[2015].social_care.means_test.non_residential.assets.lower_limit	 2.38771800000000E+04
default	2	y[2022].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.09497209997379E+01
default	2	y[2023].av_costs.hour_of_care	 1.81532649025619E+01
default	2	y[2015].benefits.attendance_allowance.high_rate	 8.21905596000000E+01
default	2	y[2013].social_care.means_test.maxima.maximum_lifetime_payment	 1.01999999999990E+12
default	2	y[2030].benefits.pension_credit.guaranteed_credit.couple	 3.11214857346870E+02
default	2	y[2013].av_costs.residential_per_week	 5.06940000000000E+02
default	2	y[2019].social_care.means_test.non_residential.assets.lower_limit	 2.58454275221088E+04
default	2	y[2029].social_care.means_test.maxima.maximum_lifetime_payment	 1.40024141919228E+12
default	2	y[2026].benefits.pension_credit.savings_credit.threshold_single	 1.47517725710429E+02
default	2	y[2024].social_care.means_test.residential.assets.lower_limit	 2.85354403776573E+04
default	2	y[2020].social_care.means_test.non_residential.assets.lower_limit	 2.63623360725510E+04
default	2	y[2019].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.33707011714376E+02
default	2	y[2025].benefits.pension_credit.guaranteed_credit.carer_single	 4.21715761527938E+01
default	2	y[2017].benefits.attendance_allowance.low_rate	 5.72465896459200E+01
default	2	y[2018].av_costs.residential_per_week	 5.59702722374208E+02
default	2	y[2026].benefits.dla.mobility.low_rate	 2.71152885809420E+01
default	2	y[2024].social_care.means_test.non_residential.assets.lower_limit	 2.85354403776573E+04
default	2	y[2020].social_care.means_test.maxima.maximum_lifetime_payment	 1.17165938100215E+12
default	2	y[2022].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.09454752436949E+01
default	2	y[2017].benefits.pension_credit.savings_credit.threshold_single	 1.23436233797760E+02
default	2	y[2020].benefits.pension_credit.savings_credit.maximum_couple	 2.78034771111838E+01
default	2	y[2028].social_care.means_test.non_residential.assets.lower_limit	 3.08876783645388E+04
default	2	y[2016].social_care.means_test.residential.assets.lower_limit	 2.43547236000000E+04
default	2	y[2028].benefits.attendance_allowance.high_rate	 1.06322252859268E+02
default	2	y[2022].benefits.pension_credit.savings_credit.maximum_single	 2.26001565467028E+01
default	2	y[2023].benefits.pension_credit.savings_credit.threshold_couple	 2.21755807902186E+02
default	2	y[2029].benefits.pension_credit.savings_credit.maximum_single	 2.59604759118276E+01
default	2	y[2023].av_costs.residential_per_week	 6.17957031272142E+02
default	2	y[2029].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 7.00120709596212E+01
default	2	y[2014].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.21102560000000E+02
default	2	y[2020].social_care.means_test.residential.assets.upper_limit	 2.63623360725510E+04
default	2	y[2020].benefits.dla.mobility.high_rate	 6.33281895431725E+01
default	2	y[2019].benefits.pension_credit.guaranteed_credit.carer_single	 3.74471527653665E+01
default	2	y[2028].av_costs.residential_per_week	 6.82274495430034E+02
default	2	y[2019].benefits.pension_credit.savings_credit.maximum_couple	 2.72583108933174E+01
default	2	y[2023].benefits.attendance_allowance.high_rate	 9.62993401851658E+01
default	2	y[2014].benefits.pension_credit.savings_credit.threshold_couple	 1.85555340000000E+02
default	2	y[2014].social_care.means_test.maxima.maximum_lifetime_payment	 1.04039999999990E+12
default	2	y[2013].benefits.dla.mobility.high_rate	 5.51310000000000E+01
default	2	y[2014].social_care.means_test.non_residential.assets.upper_limit	 2.34090000000000E+04
default	2	y[2014].benefits.pension_credit.savings_credit.maximum_single	 1.92890160000000E+01
default	2	y[2017].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.42575027462400E+01
default	2	y[2027].social_care.means_test.residential.assets.upper_limit	 3.02820376122929E+04
default	2	y[2025].benefits.attendance_allowance.low_rate	 6.70735037890293E+01
default	2	y[2018].social_care.means_test.non_residential.assets.upper_limit	 2.53386544334400E+04
default	2	y[2029].benefits.pension_credit.savings_credit.threshold_single	 1.56546990665713E+02
default	2	y[2026].benefits.pension_credit.guaranteed_credit.carer_single	 4.30150076758496E+01
default	2	y[2013].benefits.dla.care.middle_rate	 5.28870000000000E+01
default	2	y[2016].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.41216080000000E+01
default	2	y[2018].benefits.dla.care.middle_rate	 5.83915214388384E+01
default	2	y[2028].benefits.dla.mobility.low_rate	 2.82107462396121E+01
default	2	y[2021].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.97546284311156E+01
default	2	y[2019].social_care.means_test.residential.assets.upper_limit	 2.58454275221088E+04
default	2	y[2023].social_care.means_test.non_residential.assets.upper_limit	 2.79759219388797E+04
default	2	y[2013].benefits.dla.care.low_rate	 2.09610000000000E+01
default	2	y[2023].benefits.dla.care.middle_rate	 6.44689578902627E+01
default	2	y[2021].social_care.means_test.maxima.maximum_lifetime_payment	 1.19509256862219E+12
default	2	y[2027].social_care.means_test.non_residential.assets.upper_limit	 3.02820376122929E+04
default	2	y[2022].av_costs.hour_of_care	 1.77973185319235E+01
default	2	y[2022].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.41890950487390E+02
default	2	y[2026].benefits.pension_credit.savings_credit.threshold_couple	 2.35329037392263E+02
default	2	y[2018].av_costs.hour_of_care	 1.64419713212544E+01
default	2	y[2017].benefits.pension_credit.savings_credit.threshold_couple	 1.96912811250720E+02
default	2	y[2021].benefits.pension_credit.savings_credit.threshold_single	 1.33611349171974E+02
default	2	y[2028].benefits.dla.care.middle_rate	 7.11789388089483E+01
default	2	y[2014].benefits.dla.care.low_rate	 2.13802200000000E+01
default	2	y[2029].benefits.dla.mobility.low_rate	 2.87749611644043E+01
default	2	y[2018].benefits.attendance_allowance.high_rate	 8.72212793719968E+01
default	2	y[2022].benefits.pension_credit.savings_credit.maximum_couple	 2.89267375864756E+01
default	2	y[2018].benefits.attendance_allowance.low_rate	 5.83915214388384E+01
default	2	y[2018].social_care.means_test.residential.assets.lower_limit	 2.53386544334400E+04
default	2	y[2025].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.52879058924109E+01
default	2	y[2024].benefits.pension_credit.savings_credit.maximum_single	 2.35132028711896E+01
default	2	y[2028].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.86392852545306E+01
default	2	y[2014].av_costs.residential_per_week	 5.17078800000000E+02
default	2	y[2029].benefits.pension_credit.savings_credit.maximum_couple	 3.32277288774362E+01
default	2	y[2015].benefits.dla.care.low_rate	 2.18078244000000E+01
default	2	y[2024].benefits.dla.care.high_rate	 9.82253269888692E+01
default	2	y[2015].social_care.means_test.maxima.maximum_lifetime_payment	 1.06120799999989E+12
default	2	y[2021].benefits.dla.care.high_rate	 9.25599194397980E+01
default	2	y[2013].benefits.attendance_allowance.high_rate	 7.89990000000000E+01
default	2	y[2014].benefits.pension_credit.savings_credit.maximum_couple	 2.46886920000000E+01
default	2	y[2013].benefits.pension_credit.guaranteed_credit.single	 1.45554000000000E+02
default	2	y[2022].social_care.means_test.residential.assets.upper_limit	 2.74273744498820E+04
default	2	y[2015].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.30604000000000E+01
default	2	y[2016].benefits.pension_credit.savings_credit.maximum_single	 2.00682922464000E+01
default	2	y[2029].social_care.means_test.residential.assets.upper_limit	 3.15054319318296E+04
default	2	y[2028].av_costs.hour_of_care	 2.00426712943229E+01
default	2	y[2019].av_costs.residential_per_week	 5.70896776821692E+02
default	2	y[2016].social_care.means_test.non_residential.assets.lower_limit	 2.43547236000000E+04
default	2	y[2017].benefits.pension_credit.guaranteed_credit.single	 1.57552330616640E+02
default	2	y[2020].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.85829690501133E+01
default	2	y[2020].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.81905759743319E+01
default	2	y[2015].benefits.pension_credit.guaranteed_credit.single	 1.51434381600000E+02
default	2	y[2017].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.28515005492480E+02
default	2	y[2016].benefits.dla.care.low_rate	 2.22439808880000E+01
default	2	y[2022].social_care.means_test.maxima.maximum_lifetime_payment	 1.21899441999464E+12
default	2	y[2019].benefits.pension_credit.guaranteed_credit.single	 1.63917444773552E+02
default	2	y[2017].benefits.dla.care.low_rate	 2.26888605057600E+01
default	2	y[2021].social_care.means_test.non_residential.assets.lower_limit	 2.68895827940020E+04
default	2	y[2013].benefits.state_pension.class_a	 1.04193000000000E+02
default	2	y[2017].benefits.dla.mobility.high_rate	 5.96755674129600E+01
default	2	y[2024].av_costs.residential_per_week	 6.30316171897585E+02
default	2	y[2024].benefits.dla.mobility.high_rate	 6.85484689961056E+01
default	2	y[2029].benefits.pension_credit.savings_credit.threshold_couple	 2.49733057112969E+02
default	2	y[2014].social_care.means_test.residential.assets.upper_limit	 2.34090000000000E+04
default	2	y[2026].benefits.attendance_allowance.low_rate	 6.84149738648099E+01
default	2	y[2026].benefits.attendance_allowance.high_rate	 1.02193630199219E+02
default	2	y[2025].social_care.means_test.non_residential.assets.lower_limit	 2.91061491852104E+04
default	2	y[2019].benefits.dla.care.high_rate	 8.89657049594367E+01
default	2	y[2024].benefits.pension_credit.savings_credit.threshold_single	 1.41789432632093E+02
default	2	y[2021].social_care.means_test.residential.assets.lower_limit	 2.68895827940020E+04
default	2	y[2028].social_care.means_test.residential.assets.lower_limit	 3.08876783645388E+04
default	2	y[2021].benefits.attendance_allowance.high_rate	 9.25599194397980E+01
default	2	y[2024].benefits.pension_credit.guaranteed_credit.single	 1.80978104084075E+02
default	2	y[2029].av_costs.residential_per_week	 6.95919985338635E+02
default	2	y[2018].benefits.dla.care.low_rate	 2.31426377158752E+01
default	2	y[2014].benefits.state_pension.class_a	 1.06276860000000E+02
default	2	y[2029].social_care.means_test.non_residential.assets.lower_limit	 3.15054319318296E+04
default	2	y[2014].benefits.dla.care.middle_rate	 5.39447400000000E+01
default	2	y[2022].benefits.pension_credit.guaranteed_credit.single	 1.73950503733252E+02
default	2	y[2021].av_costs.hour_of_care	 1.74483515018857E+01
default	2	y[2028].benefits.pension_credit.guaranteed_credit.single	 1.95896520116430E+02
default	2	y[2020].benefits.pension_credit.guaranteed_credit.single	 1.67195793669023E+02
default	2	y[2017].av_costs.hour_of_care	 1.61195797267200E+01
default	2	y[2016].benefits.dla.care.high_rate	 8.38343707920000E+01
default	2	y[2026].benefits.pension_credit.guaranteed_credit.single	 1.88289619489072E+02
default	2	y[2013].benefits.dla.care.high_rate	 7.89990000000000E+01
default	2	y[2016].social_care.means_test.maxima.maximum_lifetime_payment	 1.08243215999989E+12
default	2	y[2015].benefits.pension_credit.savings_credit.threshold_single	 1.18643054400000E+02
default	2	y[2013].social_care.means_test.residential.assets.lower_limit	 2.29500000000000E+04
default	2	y[2019].benefits.attendance_allowance.low_rate	 5.95593518676152E+01
default	2	y[2019].benefits.dla.care.middle_rate	 5.95593518676152E+01
default	2	y[2015].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.17623056000000E+01
default	2	y[2021].benefits.pension_credit.savings_credit.threshold_couple	 2.13144759613789E+02
default	2	y[2019].benefits.dla.care.low_rate	 2.36054904701927E+01
default	2	y[2027].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.72934169162065E+01
default	2	y[2020].benefits.attendance_allowance.low_rate	 6.07505389049675E+01
default	2	y[2028].benefits.pension_credit.guaranteed_credit.carer_single	 4.47528139859540E+01
default	2	y[2025].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.50575811784822E+02
default	2	y[2024].benefits.pension_credit.savings_credit.maximum_couple	 3.00953777849692E+01
default	2	y[2015].benefits.state_pension.class_a	 1.08402397200000E+02
default	2	y[2026].benefits.pension_credit.savings_credit.maximum_single	 2.44631362671857E+01
default	2	y[2024].benefits.dla.care.middle_rate	 6.57583370480680E+01
default	2	y[2020].social_care.means_test.non_residential.assets.upper_limit	 2.63623360725510E+04
default	2	y[2015].social_care.means_test.non_residential.assets.upper_limit	 2.38771800000000E+04
default	2	y[2014].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.20200000000000E+01
default	2	y[2024].social_care.means_test.residential.assets.upper_limit	 2.85354403776573E+04
default	2	y[2028].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.98961280362737E+01
default	2	y[2023].social_care.means_test.maxima.maximum_lifetime_payment	 1.24337430839453E+12
default	2	y[2014].benefits.dla.mobility.high_rate	 5.62336200000000E+01
default	2	y[2015].benefits.pension_credit.guaranteed_credit.couple	 2.31237223200000E+02
default	2	y[2021].benefits.dla.mobility.high_rate	 6.45947533340359E+01
default	2	y[2013].benefits.pension_credit.guaranteed_credit.couple	 2.22258000000000E+02
default	2	y[2029].benefits.dla.care.middle_rate	 7.26025175851272E+01
default	2	y[2016].benefits.pension_credit.savings_credit.maximum_couple	 2.56861151568000E+01
default	2	y[2030].benefits.dla.care.low_rate	 2.93504603876924E+01
default	2	y[2019].benefits.pension_credit.guaranteed_credit.couple	 2.50298606980778E+02
default	2	y[2024].social_care.means_test.non_residential.assets.upper_limit	 2.85354403776573E+04
default	2	y[2019].social_care.means_test.non_residential.assets.upper_limit	 2.58454275221088E+04
default	2	y[2027].benefits.pension_credit.savings_credit.threshold_single	 1.50468080224638E+02
default	2	y[2020].benefits.state_pension.class_a	 1.19685005769381E+02
default	2	y[2017].benefits.pension_credit.guaranteed_credit.couple	 2.40579207017280E+02
default	2	y[2018].benefits.pension_credit.savings_credit.maximum_single	 2.08790512531546E+01
default	2	y[2020].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.36381151948664E+02
default	2	y[2028].social_care.means_test.non_residential.assets.upper_limit	 3.08876783645388E+04
default	2	y[2016].social_care.means_test.residential.assets.upper_limit	 2.43547236000000E+04
default	2	y[2016].benefits.attendance_allowance.high_rate	 8.38343707920000E+01
default	2	y[2015].av_costs.residential_per_week	 5.27420376000000E+02
default	2	y[2016].benefits.state_pension.class_a	 1.10570445144000E+02
default	2	y[2013].benefits.attendance_allowance.low_rate	 5.28870000000000E+01
default	2	y[2023].social_care.means_test.residential.assets.lower_limit	 2.79759219388797E+04
default	2	y[2023].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.23643847485688E+01
default	2	y[2018].benefits.pension_credit.savings_credit.threshold_single	 1.25904958473715E+02
default	2	y[2013].benefits.pension_credit.guaranteed_credit.carer_single	 3.32520000000000E+01
default	2	y[2021].benefits.state_pension.class_a	 1.22078705884769E+02
default	2	y[2022].benefits.pension_credit.guaranteed_credit.couple	 2.65618884116858E+02
default	2	y[2020].benefits.pension_credit.guaranteed_credit.couple	 2.55304579120394E+02
default	2	y[2024].benefits.pension_credit.savings_credit.threshold_couple	 2.26190924060230E+02
default	2	y[2028].benefits.dla.mobility.high_rate	 7.41990673601476E+01
default	2	y[2017].social_care.means_test.maxima.maximum_lifetime_payment	 1.10408080319989E+12
default	2	y[2026].benefits.pension_credit.guaranteed_credit.couple	 2.87514422471400E+02
default	2	y[2015].benefits.pension_credit.savings_credit.threshold_couple	 1.89266446800000E+02
default	2	y[2020].av_costs.hour_of_care	 1.71062269626331E+01
default	2	y[2020].av_costs.residential_per_week	 5.82314712358126E+02
default	2	y[2024].benefits.pension_credit.guaranteed_credit.couple	 2.76349887035179E+02
default	2	y[2015].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.23524611200000E+02
default	2	y[2028].benefits.pension_credit.guaranteed_credit.couple	 2.99130005139244E+02
default	2	y[2015].social_care.means_test.residential.assets.lower_limit	 2.38771800000000E+04
default	2	y[2020].benefits.pension_credit.guaranteed_credit.carer_single	 3.81960958206739E+01
default	2	y[2029].benefits.pension_credit.guaranteed_credit.carer_single	 4.56478702656730E+01
default	2	y[2029].benefits.attendance_allowance.high_rate	 1.08448697916453E+02
default	2	y[2026].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.59739381531436E+01
default	2	y[2017].benefits.state_pension.class_a	 1.12781854046880E+02
default	2	y[2024].social_care.means_test.maxima.maximum_lifetime_payment	 1.26824179456242E+12
default	2	y[2016].av_costs.hour_of_care	 1.58035095360000E+01
default	2	y[2024].benefits.attendance_allowance.high_rate	 9.82253269888692E+01
default	2	y[2026].benefits.pension_credit.savings_credit.maximum_couple	 3.13112310474820E+01
default	2	y[2018].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.55426528011648E+01
default	3	y[2021].benefits.pension_credit.savings_credit.maximum_single	 2.21787387871816E+01
default	3	y[2028].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.59948915147129E+02
default	3	y[2021].benefits.attendance_allowance.low_rate	 6.20263002219721E+01
default	3	y[2020].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.17280806549711E+09
default	3	y[2015].benefits.dla.care.middle_rate	 5.50775795400000E+01
default	3	y[2013].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.10500000000000E+01
default	3	y[2029].benefits.dla.care.high_rate	 1.08555020169314E+02
default	3	y[2022].social_care.means_test.non_residential.assets.lower_limit	 2.74542640326762E+04
default	3	y[2027].benefits.pension_credit.savings_credit.threshold_couple	 2.40270947177502E+02
default	3	y[2018].benefits.pension_credit.savings_credit.maximum_couple	 2.67500340465947E+01
default	3	y[2026].social_care.means_test.non_residential.assets.lower_limit	 2.97173783181000E+04
default	3	y[2013].benefits.pension_credit.savings_credit.maximum_single	 1.89293400000000E+01
default	3	y[2018].benefits.state_pension.class_a	 1.15150272981865E+02
default	3	y[2018].social_care.means_test.maxima.maximum_lifetime_payment	 1.12726650006709E+12
default	3	y[2020].benefits.dla.care.middle_rate	 6.08100982568354E+01
default	3	y[2030].av_costs.hour_of_care	 2.08728387393340E+01
default	3	y[2023].benefits.state_pension.class_a	 1.27135205882516E+02
default	3	y[2026].av_costs.hour_of_care	 1.92832765975227E+01
default	3	y[2018].social_care.means_test.residential.assets.upper_limit	 2.53634962515121E+04
default	3	y[2014].benefits.pension_credit.guaranteed_credit.carer_single	 3.39502920000000E+01
default	3	y[2023].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.44870660447625E+02
default	3	y[2018].benefits.pension_credit.savings_credit.threshold_couple	 2.01047980286986E+02
default	3	y[2021].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.19626422680706E+09
default	3	y[2022].benefits.pension_credit.savings_credit.threshold_single	 1.36417187504587E+02
default	3	y[2014].benefits.attendance_allowance.low_rate	 5.39976270000000E+01
default	3	y[2013].benefits.pension_credit.guaranteed_credit.severe_disability_single	 5.94222000000000E+01
default	3	y[2018].benefits.dla.mobility.high_rate	 6.09287543286323E+01
default	3	y[2020].benefits.dla.care.high_rate	 9.08339847635853E+01
default	3	y[2019].benefits.attendance_allowance.high_rate	 8.90529262388088E+01
default	3	y[2013].benefits.dla.mobility.low_rate	 2.09815500000000E+01
default	3	y[2026].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.68689519161519E+01
default	3	y[2021].benefits.pension_credit.guaranteed_credit.carer_single	 3.89982138329082E+01
default	3	y[2025].social_care.means_test.residential.assets.lower_limit	 2.91346846255882E+04
default	3	y[2013].benefits.pension_credit.savings_credit.threshold_single	 1.14147800000000E+02
default	3	y[2030].benefits.dla.care.middle_rate	 7.41271704544155E+01
default	3	y[2025].social_care.means_test.maxima.maximum_lifetime_payment	 1.29487487224823E+12
default	3	y[2022].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.22018951134320E+09
default	3	y[2014].benefits.attendance_allowance.high_rate	 8.06579790000000E+01
default	3	y[2025].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.47437436124182E+01
default	3	y[2014].benefits.dla.mobility.low_rate	 2.14011810000000E+01
default	3	y[2021].benefits.pension_credit.savings_credit.maximum_couple	 2.83873501305188E+01
default	3	y[2017].social_care.means_test.residential.assets.lower_limit	 2.48661727956000E+04
default	3	y[2023].benefits.pension_credit.savings_credit.maximum_single	 2.30747598341836E+01
default	3	y[2021].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.96225780697932E+01
default	3	y[2018].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.31213820607822E+02
default	3	y[2015].benefits.dla.care.high_rate	 8.22711385800000E+01
default	3	y[2021].social_care.means_test.residential.assets.upper_limit	 2.69159451300747E+04
default	3	y[2022].benefits.attendance_allowance.low_rate	 6.32668262264117E+01
default	3	y[2021].social_care.means_test.non_residential.assets.upper_limit	 2.69159451300747E+04
default	3	y[2028].benefits.pension_credit.savings_credit.maximum_couple	 3.26081422374689E+01
default	3	y[2015].benefits.pension_credit.guaranteed_credit.carer_single	 3.46292978400000E+01
default	3	y[2023].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.24459330157006E+09
default	3	y[2021].av_costs.residential_per_week	 5.94543321317650E+02
default	3	y[2013].benefits.pension_credit.savings_credit.maximum_couple	 2.42283300000000E+01
default	3	y[2019].social_care.means_test.maxima.maximum_lifetime_payment	 1.14981183006843E+12
default	3	y[2030].social_care.means_test.non_residential.assets.upper_limit	 3.21670460023982E+04
default	3	y[2025].benefits.state_pension.class_a	 1.32271468200170E+02
default	3	y[2025].benefits.pension_credit.savings_credit.threshold_single	 1.44767010717367E+02
default	3	y[2025].social_care.means_test.non_residential.assets.upper_limit	 2.91346846255882E+04
default	3	y[2022].benefits.dla.mobility.high_rate	 6.59512431540511E+01
default	3	y[2015].benefits.pension_credit.savings_credit.maximum_single	 1.96940853360000E+01
default	3	y[2028].social_care.means_test.residential.assets.upper_limit	 3.09179604021513E+04
default	3	y[2016].benefits.pension_credit.savings_credit.threshold_single	 1.21134558542400E+02
default	3	y[2015].benefits.dla.mobility.low_rate	 2.18292046200000E+01
default	3	y[2013].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.02099999897900E+09
default	3	y[2030].benefits.state_pension.class_a	 1.46038388850888E+02
default	3	y[2029].social_care.means_test.non_residential.assets.upper_limit	 3.15363196101944E+04
default	3	y[2013].social_care.means_test.residential.assets.upper_limit	 2.29725000000000E+04
default	3	y[2026].av_costs.residential_per_week	 6.56423867737586E+02
default	3	y[2015].benefits.dla.mobility.high_rate	 5.74145260200000E+01
default	3	y[2022].benefits.pension_credit.guaranteed_credit.carer_single	 3.97781781095664E+01
default	3	y[2022].benefits.pension_credit.savings_credit.threshold_couple	 2.17620799565680E+02
default	3	y[2025].av_costs.hour_of_care	 1.89051731348261E+01
default	3	y[2013].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.18844400000000E+02
default	3	y[2026].social_care.means_test.maxima.maximum_lifetime_payment	 1.32077236969320E+12
default	3	y[2024].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.26948516760146E+09
default	3	y[2022].benefits.attendance_allowance.high_rate	 9.45036777480344E+01
default	3	y[2020].benefits.dla.mobility.low_rate	 2.41012057700669E+01
default	3	y[2016].benefits.dla.care.middle_rate	 5.61791311308002E+01
default	3	y[2019].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.74905915034273E+01
default	3	y[2029].benefits.attendance_allowance.low_rate	 7.26736965239369E+01
default	3	y[2016].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.30593140176002E+01
default	3	y[2013].benefits.pension_credit.savings_credit.threshold_couple	 1.82095350000000E+02
default	3	y[2020].social_care.means_test.residential.assets.lower_limit	 2.63881815000732E+04
default	3	y[2029].benefits.dla.mobility.high_rate	 7.57572477747114E+01
default	3	y[2027].social_care.means_test.residential.assets.lower_limit	 3.03117258844620E+04
default	3	y[2026].benefits.state_pension.class_a	 1.34916897564174E+02
default	3	y[2014].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.04141999895858E+09
default	3	y[2015].benefits.attendance_allowance.low_rate	 5.50775795400000E+01
default	3	y[2024].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.34742584435472E+01
default	3	y[2030].benefits.attendance_allowance.low_rate	 7.41271704544155E+01
default	3	y[2016].benefits.dla.mobility.low_rate	 2.22657887124001E+01
default	3	y[2026].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.53737903832304E+02
default	3	y[2020].benefits.dla.care.low_rate	 2.41012057700669E+01
default	3	y[2018].benefits.pension_credit.guaranteed_credit.single	 1.60860929559590E+02
default	3	y[2021].benefits.dla.mobility.low_rate	 2.45832298854682E+01
default	3	y[2014].social_care.means_test.non_residential.assets.lower_limit	 2.34319500000000E+04
default	3	y[2028].benefits.pension_credit.savings_credit.threshold_single	 1.53627909909356E+02
default	3	y[2021].benefits.dla.care.middle_rate	 6.20263002219721E+01
default	3	y[2025].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.29487487095349E+09
default	3	y[2016].benefits.pension_credit.guaranteed_credit.single	 1.54614503613600E+02
default	3	y[2021].benefits.dla.care.low_rate	 2.45832298854682E+01
default	3	y[2014].benefits.pension_credit.guaranteed_credit.single	 1.48610634000000E+02
default	3	y[2029].benefits.pension_credit.guaranteed_credit.severe_disability_single	 8.15739467250362E+01
default	3	y[2014].av_costs.hour_of_care	 1.52047320000000E+01
default	3	y[2019].social_care.means_test.residential.assets.lower_limit	 2.58707661765423E+04
default	3	y[2018].social_care.means_test.non_residential.assets.lower_limit	 2.53634962515121E+04
default	3	y[2025].benefits.pension_credit.savings_credit.maximum_single	 2.40069801314847E+01
default	3	y[2015].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.06224839893775E+09
default	3	y[2016].benefits.pension_credit.guaranteed_credit.carer_single	 3.53218837968001E+01
default	3	y[2026].benefits.dla.care.middle_rate	 6.84820473685993E+01
default	3	y[2030].benefits.attendance_allowance.high_rate	 1.10726120572700E+02
default	3	y[2019].benefits.pension_credit.savings_credit.threshold_single	 1.28548962601663E+02
default	3	y[2027].benefits.state_pension.class_a	 1.37615235515458E+02
default	3	y[2023].benefits.pension_credit.savings_credit.maximum_couple	 2.95341990757916E+01
default	3	y[2021].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.39245156139586E+02
default	3	y[2022].benefits.dla.care.low_rate	 2.50748944831776E+01
default	3	y[2023].social_care.means_test.non_residential.assets.lower_limit	 2.80033493133296E+04
default	3	y[2017].benefits.dla.mobility.low_rate	 2.27111044866480E+01
default	3	y[2025].benefits.pension_credit.savings_credit.threshold_couple	 2.30940933465496E+02
default	3	y[2027].social_care.means_test.maxima.maximum_lifetime_payment	 1.34718781708707E+12
default	3	y[2026].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.32077236837256E+09
default	3	y[2017].benefits.attendance_allowance.high_rate	 8.55948925786320E+01
default	3	y[2023].benefits.pension_credit.guaranteed_credit.single	 1.77603464311650E+02
default	3	y[2030].benefits.dla.care.high_rate	 1.10726120572700E+02
default	3	y[2022].benefits.dla.mobility.low_rate	 2.50748944831776E+01
default	3	y[2023].social_care.means_test.residential.assets.upper_limit	 2.80033493133296E+04
default	3	y[2029].benefits.pension_credit.guaranteed_credit.single	 2.00010347038877E+02
default	3	y[2027].social_care.means_test.non_residential.assets.lower_limit	 3.03117258844620E+04
default	3	y[2017].benefits.pension_credit.savings_credit.maximum_single	 2.04897263835744E+01
default	3	y[2023].benefits.pension_credit.guaranteed_credit.carer_single	 4.05737416717576E+01
default	3	y[2021].benefits.pension_credit.guaranteed_credit.single	 1.70706905336074E+02
default	3	y[2023].benefits.attendance_allowance.low_rate	 6.45321627509396E+01
default	3	y[2024].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.38840368282890E+01
default	3	y[2027].benefits.pension_credit.guaranteed_credit.single	 1.92243701498344E+02
default	3	y[2028].benefits.state_pension.class_a	 1.40367540225767E+02
default	3	y[2030].social_care.means_test.residential.assets.lower_limit	 3.21670460023982E+04
default	3	y[2016].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.08349336691651E+09
default	3	y[2025].benefits.pension_credit.guaranteed_credit.single	 1.84778644269841E+02
default	3	y[2015].benefits.pension_credit.savings_credit.maximum_couple	 2.52071545320000E+01
default	3	y[2023].benefits.dla.care.low_rate	 2.55763923728410E+01
default	3	y[2016].benefits.pension_credit.savings_credit.threshold_couple	 1.93241042182801E+02
default	3	y[2020].benefits.pension_credit.savings_credit.threshold_single	 1.31119941853697E+02
default	3	y[2017].av_costs.residential_per_week	 5.49266127973920E+02
default	3	y[2030].benefits.pension_credit.guaranteed_credit.carer_single	 4.66064755412526E+01
default	3	y[2015].social_care.means_test.residential.assets.upper_limit	 2.39005890000000E+04
default	3	y[2018].benefits.dla.mobility.low_rate	 2.31653265763810E+01
default	3	y[2013].social_care.means_test.non_residential.assets.upper_limit	 2.29725000000000E+04
default	3	y[2019].benefits.dla.mobility.high_rate	 6.21473294152049E+01
default	3	y[2018].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.63633250033602E+01
default	3	y[2030].benefits.pension_credit.guaranteed_credit.single	 2.04010553979655E+02
default	3	y[2022].social_care.means_test.residential.assets.lower_limit	 2.74542640326762E+04
default	3	y[2024].benefits.dla.care.low_rate	 2.60879202202979E+01
default	3	y[2026].benefits.dla.mobility.high_rate	 7.13877465819246E+01
default	3	y[2023].benefits.dla.mobility.low_rate	 2.55763923728410E+01
default	3	y[2022].av_costs.residential_per_week	 6.06434187744004E+02
default	3	y[2023].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.22296651407325E+01
default	3	y[2016].benefits.attendance_allowance.low_rate	 5.61791311308002E+01
default	3	y[2028].benefits.dla.care.high_rate	 1.06426490362072E+02
default	3	y[2017].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.10516323425484E+09
default	3	y[2017].benefits.pension_credit.guaranteed_credit.carer_single	 3.60283214727360E+01
default	3	y[2025].benefits.dla.care.low_rate	 2.66096786247039E+01
default	3	y[2025].benefits.dla.care.high_rate	 1.00288058855636E+02
default	3	y[2027].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.34718781574001E+09
default	3	y[2017].social_care.means_test.non_residential.assets.upper_limit	 2.48661727956000E+04
default	3	y[2016].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.26118628035200E+02
default	3	y[2029].benefits.state_pension.class_a	 1.43174891030283E+02
default	3	y[2014].benefits.pension_credit.guaranteed_credit.couple	 2.26925418000000E+02
default	3	y[2029].social_care.means_test.residential.assets.lower_limit	 3.15363196101944E+04
default	3	y[2029].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.63147893450072E+02
default	3	y[2022].social_care.means_test.non_residential.assets.upper_limit	 2.74542640326762E+04
default	3	y[2018].benefits.pension_credit.guaranteed_credit.couple	 2.45631370364644E+02
default	3	y[2025].benefits.attendance_allowance.high_rate	 1.00288058855636E+02
default	3	y[2014].social_care.means_test.residential.assets.lower_limit	 2.34319500000000E+04
default	3	y[2019].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.69190485099893E+01
default	3	y[2022].benefits.dla.care.high_rate	 9.45036777480344E+01
default	3	y[2028].benefits.pension_credit.savings_credit.threshold_couple	 2.45076366121052E+02
default	3	y[2020].benefits.pension_credit.savings_credit.maximum_single	 2.17438615560603E+01
default	3	y[2016].benefits.pension_credit.guaranteed_credit.couple	 2.36093204887201E+02
default	3	y[2024].benefits.pension_credit.guaranteed_credit.carer_single	 4.13852165051928E+01
default	3	y[2026].benefits.dla.care.low_rate	 2.71418721971980E+01
default	3	y[2019].benefits.dla.mobility.low_rate	 2.36286331079086E+01
default	3	y[2020].benefits.attendance_allowance.high_rate	 9.08339847635853E+01
default	3	y[2023].benefits.pension_credit.savings_credit.threshold_single	 1.39145531254678E+02
default	3	y[2026].social_care.means_test.non_residential.assets.upper_limit	 2.97173783181000E+04
default	3	y[2018].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.12726649893994E+09
default	3	y[2028].social_care.means_test.maxima.maximum_lifetime_payment	 1.37413157342881E+12
default	3	y[2028].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.37413157205481E+09
default	3	y[2025].benefits.pension_credit.savings_credit.maximum_couple	 3.07273807184537E+01
default	3	y[2024].benefits.dla.mobility.low_rate	 2.60879202202979E+01
default	3	y[2017].benefits.dla.care.middle_rate	 5.73027137534160E+01
default	3	y[2027].benefits.pension_credit.savings_credit.maximum_single	 2.49768621287967E+01
default	3	y[2019].benefits.pension_credit.savings_credit.threshold_couple	 2.05068939892725E+02
default	3	y[2021].benefits.pension_credit.guaranteed_credit.couple	 2.60665975281923E+02
default	3	y[2024].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.47768073656578E+02
default	3	y[2025].social_care.means_test.residential.assets.upper_limit	 2.91346846255882E+04
default	3	y[2014].benefits.pension_credit.savings_credit.threshold_single	 1.16430756000000E+02
default	3	y[2025].benefits.pension_credit.guaranteed_credit.couple	 2.82153234662918E+02
default	3	y[2014].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.06106440000000E+01
default	3	y[2024].benefits.attendance_allowance.low_rate	 6.58228060059585E+01
default	3	y[2028].benefits.dla.care.low_rate	 2.82384038339648E+01
default	3	y[2022].benefits.dla.care.middle_rate	 6.32668262264117E+01
default	3	y[2023].benefits.pension_credit.guaranteed_credit.couple	 2.71196880683312E+02
default	3	y[2020].benefits.pension_credit.savings_credit.threshold_couple	 2.09170318690580E+02
default	3	y[2029].benefits.pension_credit.guaranteed_credit.couple	 3.05411735247171E+02
default	3	y[2017].benefits.pension_credit.savings_credit.maximum_couple	 2.62255235750928E+01
default	3	y[2019].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.14981182891873E+09
default	3	y[2017].benefits.dla.care.high_rate	 8.55948925786320E+01
default	3	y[2029].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.40161420349591E+09
default	3	y[2018].benefits.pension_credit.guaranteed_credit.carer_single	 3.67488879021908E+01
default	3	y[2027].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.84063309544751E+01
default	3	y[2019].benefits.pension_credit.savings_credit.maximum_single	 2.13175113294708E+01
default	3	y[2023].benefits.dla.mobility.high_rate	 6.72702680171318E+01
default	3	y[2030].benefits.dla.mobility.high_rate	 7.72723927302056E+01
default	3	y[2025].benefits.dla.mobility.low_rate	 2.66096786247039E+01
default	3	y[2017].social_care.means_test.residential.assets.upper_limit	 2.48661727956000E+04
default	3	y[2029].benefits.dla.care.low_rate	 2.88031719106442E+01
default	3	y[2016].benefits.dla.mobility.high_rate	 5.85628165404002E+01
default	3	y[2017].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.52581617680000E+01
default	3	y[2030].benefits.dla.mobility.low_rate	 2.93792353488571E+01
default	3	y[2014].benefits.dla.care.high_rate	 8.06579790000000E+01
default	3	y[2015].social_care.means_test.non_residential.assets.lower_limit	 2.39005890000000E+04
default	3	y[2022].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.10094756281694E+01
default	3	y[2023].av_costs.hour_of_care	 1.81710622210939E+01
default	3	y[2015].benefits.attendance_allowance.high_rate	 8.22711385800000E+01
default	3	y[2013].social_care.means_test.maxima.maximum_lifetime_payment	 1.02099999999990E+12
default	3	y[2030].benefits.pension_credit.guaranteed_credit.couple	 3.11519969952115E+02
default	3	y[2013].av_costs.residential_per_week	 5.07437000000000E+02
default	3	y[2019].social_care.means_test.non_residential.assets.lower_limit	 2.58707661765423E+04
default	3	y[2029].social_care.means_test.maxima.maximum_lifetime_payment	 1.40161420489739E+12
default	3	y[2026].benefits.pension_credit.savings_credit.threshold_single	 1.47662350931715E+02
default	3	y[2024].social_care.means_test.residential.assets.lower_limit	 2.85634162995963E+04
default	3	y[2020].social_care.means_test.non_residential.assets.lower_limit	 2.63881815000732E+04
default	3	y[2030].benefits.pension_credit.savings_credit.maximum_single	 2.65056459059761E+01
default	3	y[2019].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.33838097019979E+02
default	3	y[2025].benefits.pension_credit.guaranteed_credit.carer_single	 4.22129208352967E+01
default	3	y[2017].benefits.attendance_allowance.low_rate	 5.73027137534160E+01
default	3	y[2019].av_costs.hour_of_care	 1.67872527190008E+01
default	3	y[2018].av_costs.residential_per_week	 5.60251450533400E+02
default	3	y[2026].benefits.dla.mobility.low_rate	 2.71418721971980E+01
default	3	y[2024].social_care.means_test.non_residential.assets.lower_limit	 2.85634162995963E+04
default	3	y[2020].social_care.means_test.maxima.maximum_lifetime_payment	 1.17280806666980E+12
default	3	y[2022].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.10150296311892E+01
default	3	y[2017].benefits.pension_credit.savings_credit.threshold_single	 1.23557249713248E+02
default	3	y[2020].benefits.pension_credit.savings_credit.maximum_couple	 2.78307354220772E+01
default	3	y[2028].social_care.means_test.non_residential.assets.lower_limit	 3.09179604021513E+04
default	3	y[2027].benefits.pension_credit.savings_credit.maximum_couple	 3.19687668994793E+01
default	3	y[2016].social_care.means_test.residential.assets.lower_limit	 2.43786007800001E+04
default	3	y[2028].benefits.attendance_allowance.high_rate	 1.06426490362072E+02
default	3	y[2022].benefits.pension_credit.savings_credit.maximum_single	 2.26223135629252E+01
default	3	y[2023].benefits.pension_credit.savings_credit.threshold_couple	 2.21973215556993E+02
default	3	y[2029].benefits.pension_credit.savings_credit.maximum_single	 2.59859273588002E+01
default	3	y[2023].av_costs.residential_per_week	 6.18562871498881E+02
default	3	y[2029].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 7.00807102448764E+01
default	3	y[2014].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.21221288000000E+02
default	3	y[2020].social_care.means_test.residential.assets.upper_limit	 2.63881815000732E+04
default	3	y[2020].benefits.dla.mobility.high_rate	 6.33902760035092E+01
default	3	y[2019].benefits.pension_credit.guaranteed_credit.carer_single	 3.74838656602346E+01
default	3	y[2028].av_costs.residential_per_week	 6.82943391994186E+02
default	3	y[2019].benefits.pension_credit.savings_credit.maximum_couple	 2.72850347275266E+01
default	3	y[2023].benefits.attendance_allowance.high_rate	 9.63937513029946E+01
default	3	y[2014].benefits.pension_credit.savings_credit.threshold_couple	 1.85737257000000E+02
default	3	y[2029].av_costs.hour_of_care	 2.04635673915039E+01
default	3	y[2014].social_care.means_test.maxima.maximum_lifetime_payment	 1.04141999999990E+12
default	3	y[2013].benefits.dla.mobility.high_rate	 5.51850500000000E+01
default	3	y[2014].social_care.means_test.non_residential.assets.upper_limit	 2.34319500000000E+04
default	3	y[2014].benefits.pension_credit.savings_credit.maximum_single	 1.93079268000000E+01
default	3	y[2017].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.43205002979520E+01
default	3	y[2027].social_care.means_test.residential.assets.upper_limit	 3.03117258844620E+04
default	3	y[2030].benefits.pension_credit.guaranteed_credit.severe_disability_single	 8.32054256595368E+01
default	3	y[2025].benefits.attendance_allowance.low_rate	 6.71392621260777E+01
default	3	y[2018].social_care.means_test.non_residential.assets.upper_limit	 2.53634962515121E+04
default	3	y[2027].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.56812661908950E+02
default	3	y[2029].benefits.pension_credit.savings_credit.threshold_single	 1.56700468107544E+02
default	3	y[2026].benefits.pension_credit.guaranteed_credit.carer_single	 4.30571792520026E+01
default	3	y[2013].benefits.dla.care.middle_rate	 5.29388500000000E+01
default	3	y[2016].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.41746684000002E+01
default	3	y[2018].benefits.dla.care.middle_rate	 5.84487680284845E+01
default	3	y[2028].benefits.dla.mobility.low_rate	 2.82384038339648E+01
default	3	y[2021].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.98132114001660E+01
default	3	y[2019].social_care.means_test.residential.assets.upper_limit	 2.58707661765423E+04
default	3	y[2023].social_care.means_test.non_residential.assets.upper_limit	 2.80033493133296E+04
default	3	y[2013].benefits.dla.care.low_rate	 2.09815500000000E+01
default	3	y[2030].benefits.pension_credit.savings_credit.maximum_couple	 3.39255111838627E+01
default	3	y[2026].social_care.means_test.residential.assets.lower_limit	 2.97173783181000E+04
default	3	y[2023].benefits.dla.care.middle_rate	 6.45321627509396E+01
default	3	y[2021].social_care.means_test.maxima.maximum_lifetime_payment	 1.19626422800320E+12
default	3	y[2027].social_care.means_test.non_residential.assets.upper_limit	 3.03117258844620E+04
default	3	y[2022].av_costs.hour_of_care	 1.78147668834255E+01
default	3	y[2022].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.42030059262378E+02
default	3	y[2026].benefits.pension_credit.savings_credit.threshold_couple	 2.35559752134806E+02
default	3	y[2018].av_costs.hour_of_care	 1.64580909009812E+01
default	3	y[2030].benefits.pension_credit.savings_credit.threshold_single	 1.59834477469694E+02
default	3	y[2017].benefits.pension_credit.savings_credit.threshold_couple	 1.97105863026456E+02
default	3	y[2021].benefits.pension_credit.savings_credit.threshold_single	 1.33742340690771E+02
default	3	y[2028].benefits.dla.care.middle_rate	 7.12487220822908E+01
default	3	y[2014].benefits.dla.care.low_rate	 2.14011810000000E+01
default	3	y[2029].benefits.dla.mobility.low_rate	 2.88031719106442E+01
default	3	y[2018].benefits.attendance_allowance.high_rate	 8.73067904302049E+01
default	3	y[2022].benefits.pension_credit.savings_credit.maximum_couple	 2.89550971331292E+01
default	3	y[2018].benefits.attendance_allowance.low_rate	 5.84487680284845E+01
default	3	y[2018].social_care.means_test.residential.assets.lower_limit	 2.53634962515121E+04
default	3	y[2025].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.53617175648548E+01
default	3	y[2030].social_care.means_test.residential.assets.upper_limit	 3.21670460023982E+04
default	3	y[2024].benefits.pension_credit.savings_credit.maximum_single	 2.35362550308673E+01
default	3	y[2028].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.87065786714472E+01
default	3	y[2014].av_costs.residential_per_week	 5.17585740000000E+02
default	3	y[2029].benefits.pension_credit.savings_credit.maximum_couple	 3.32603050822184E+01
default	3	y[2015].benefits.dla.care.low_rate	 2.18292046200000E+01
default	3	y[2024].benefits.dla.care.high_rate	 9.83216263290547E+01
default	3	y[2015].social_care.means_test.maxima.maximum_lifetime_payment	 1.06224839999989E+12
default	3	y[2021].benefits.dla.care.high_rate	 9.26506644588571E+01
default	3	y[2013].benefits.attendance_allowance.high_rate	 7.90764500000000E+01
default	3	y[2014].benefits.pension_credit.savings_credit.maximum_couple	 2.47128966000000E+01
default	3	y[2013].benefits.pension_credit.guaranteed_credit.single	 1.45696700000000E+02
default	3	y[2022].social_care.means_test.residential.assets.upper_limit	 2.74542640326762E+04
default	3	y[2015].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.31124200000000E+01
default	3	y[2016].benefits.pension_credit.savings_credit.maximum_single	 2.00879670427201E+01
default	3	y[2029].social_care.means_test.residential.assets.upper_limit	 3.15363196101944E+04
default	3	y[2028].av_costs.hour_of_care	 2.00623209720626E+01
default	3	y[2019].av_costs.residential_per_week	 5.71456479544067E+02
default	3	y[2016].social_care.means_test.non_residential.assets.lower_limit	 2.43786007800001E+04
default	3	y[2017].benefits.pension_credit.guaranteed_credit.single	 1.57706793685872E+02
default	3	y[2020].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.86404033334960E+01
default	3	y[2020].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.82574294801894E+01
default	3	y[2015].benefits.pension_credit.guaranteed_credit.single	 1.51582846680000E+02
default	3	y[2017].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.28641000595904E+02
default	3	y[2016].benefits.dla.care.low_rate	 2.22657887124001E+01
default	3	y[2022].social_care.means_test.maxima.maximum_lifetime_payment	 1.22018951256327E+12
default	3	y[2030].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.66410851319074E+02
default	3	y[2019].benefits.pension_credit.guaranteed_credit.single	 1.64078148150781E+02
default	3	y[2017].benefits.dla.care.low_rate	 2.27111044866480E+01
default	3	y[2021].social_care.means_test.non_residential.assets.lower_limit	 2.69159451300747E+04
default	3	y[2013].benefits.state_pension.class_a	 1.04295150000000E+02
default	3	y[2017].benefits.dla.mobility.high_rate	 5.97340728712080E+01
default	3	y[2024].av_costs.residential_per_week	 6.30934128928860E+02
default	3	y[2024].benefits.dla.mobility.high_rate	 6.86156733774746E+01
default	3	y[2029].benefits.pension_credit.savings_credit.threshold_couple	 2.49977893443474E+02
default	3	y[2014].social_care.means_test.residential.assets.upper_limit	 2.34319500000000E+04
default	3	y[2026].benefits.attendance_allowance.low_rate	 6.84820473685993E+01
default	3	y[2026].benefits.attendance_allowance.high_rate	 1.02293820032749E+02
default	3	y[2025].social_care.means_test.non_residential.assets.lower_limit	 2.91346846255882E+04
default	3	y[2019].benefits.dla.care.high_rate	 8.90529262388088E+01
default	3	y[2024].benefits.pension_credit.savings_credit.threshold_single	 1.41928441879772E+02
default	3	y[2021].social_care.means_test.residential.assets.lower_limit	 2.69159451300747E+04
default	3	y[2028].social_care.means_test.residential.assets.lower_limit	 3.09179604021513E+04
default	3	y[2021].benefits.attendance_allowance.high_rate	 9.26506644588571E+01
default	3	y[2024].benefits.pension_credit.guaranteed_credit.single	 1.81155533597884E+02
default	3	y[2030].benefits.pension_credit.savings_credit.threshold_couple	 2.54977451312343E+02
default	3	y[2029].av_costs.residential_per_week	 6.96602259834072E+02
default	3	y[2018].benefits.dla.care.low_rate	 2.31653265763810E+01
default	3	y[2014].benefits.state_pension.class_a	 1.06381053000000E+02
default	3	y[2029].social_care.means_test.non_residential.assets.lower_limit	 3.15363196101944E+04
default	3	y[2014].benefits.dla.care.middle_rate	 5.39976270000000E+01
default	3	y[2022].benefits.pension_credit.guaranteed_credit.single	 1.74121043442795E+02
default	3	y[2021].av_costs.hour_of_care	 1.74654577288485E+01
default	3	y[2030].social_care.means_test.non_residential.assets.lower_limit	 3.21670460023982E+04
default	3	y[2028].benefits.pension_credit.guaranteed_credit.single	 1.96088575528310E+02
default	3	y[2020].benefits.pension_credit.guaranteed_credit.single	 1.67359711113798E+02
default	3	y[2017].av_costs.hour_of_care	 1.61353832362560E+01
default	3	y[2016].benefits.dla.care.high_rate	 8.39165613516002E+01
default	3	y[2026].benefits.pension_credit.guaranteed_credit.single	 1.88474217155239E+02
default	3	y[2013].benefits.dla.care.high_rate	 7.90764500000000E+01
default	3	y[2016].social_care.means_test.maxima.maximum_lifetime_payment	 1.08349336799989E+12
default	3	y[2015].benefits.pension_credit.savings_credit.threshold_single	 1.18759371120000E+02
default	3	y[2013].social_care.means_test.residential.assets.lower_limit	 2.29725000000000E+04
default	3	y[2019].benefits.attendance_allowance.low_rate	 5.96177433890541E+01
default	3	y[2019].benefits.dla.care.middle_rate	 5.96177433890541E+01
default	3	y[2015].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.18228568800000E+01
default	3	y[2021].benefits.pension_credit.savings_credit.threshold_couple	 2.13353725064392E+02
default	3	y[2019].benefits.dla.care.low_rate	 2.36286331079086E+01
default	3	y[2027].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.73593908543600E+01
default	3	y[2020].benefits.attendance_allowance.low_rate	 6.08100982568354E+01
default	3	y[2028].benefits.pension_credit.guaranteed_credit.carer_single	 4.47966892937836E+01
default	3	y[2025].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.50723435129710E+02
default	3	y[2024].benefits.pension_credit.savings_credit.maximum_couple	 3.01248830573075E+01
default	3	y[2015].benefits.state_pension.class_a	 1.08508674060000E+02
default	3	y[2026].benefits.pension_credit.savings_credit.maximum_single	 2.44871197341144E+01
default	3	y[2024].benefits.dla.care.middle_rate	 6.58228060059585E+01
default	3	y[2020].social_care.means_test.non_residential.assets.upper_limit	 2.63881815000732E+04
default	3	y[2015].social_care.means_test.non_residential.assets.upper_limit	 2.39005890000000E+04
default	3	y[2014].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 5.20710000000000E+01
default	3	y[2024].social_care.means_test.residential.assets.upper_limit	 2.85634162995963E+04
default	3	y[2028].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.99744575735646E+01
default	3	y[2023].social_care.means_test.maxima.maximum_lifetime_payment	 1.24459330281452E+12
default	3	y[2014].benefits.dla.mobility.high_rate	 5.62887510000000E+01
default	3	y[2015].benefits.pension_credit.guaranteed_credit.couple	 2.31463926360000E+02
default	3	y[2021].benefits.dla.mobility.high_rate	 6.46580815235794E+01
default	3	y[2013].benefits.pension_credit.guaranteed_credit.couple	 2.22475900000000E+02
default	3	y[2029].benefits.dla.care.middle_rate	 7.26736965239369E+01
default	3	y[2016].benefits.pension_credit.savings_credit.maximum_couple	 2.57112976226401E+01
default	3	y[2030].benefits.dla.care.low_rate	 2.93792353488571E+01
default	3	y[2019].benefits.pension_credit.guaranteed_credit.couple	 2.50543997771936E+02
default	3	y[2024].social_care.means_test.non_residential.assets.upper_limit	 2.85634162995963E+04
default	3	y[2019].social_care.means_test.non_residential.assets.upper_limit	 2.58707661765423E+04
default	3	y[2027].benefits.pension_credit.savings_credit.threshold_single	 1.50615597950349E+02
default	3	y[2020].benefits.state_pension.class_a	 1.19802344010332E+02
default	3	y[2017].benefits.pension_credit.guaranteed_credit.couple	 2.40815068984944E+02
default	3	y[2018].benefits.pension_credit.savings_credit.maximum_single	 2.08995209112459E+01
default	3	y[2020].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.36514858960379E+02
default	3	y[2028].social_care.means_test.non_residential.assets.upper_limit	 3.09179604021513E+04
default	3	y[2016].social_care.means_test.residential.assets.upper_limit	 2.43786007800001E+04
default	3	y[2016].benefits.attendance_allowance.high_rate	 8.39165613516002E+01
default	3	y[2030].social_care.means_test.maxima.maximum_lifetime_payment	 1.42964648899533E+12
default	3	y[2015].av_costs.residential_per_week	 5.27937454800000E+02
default	3	y[2016].benefits.state_pension.class_a	 1.10678847541200E+02
default	3	y[2013].benefits.attendance_allowance.low_rate	 5.29388500000000E+01
default	3	y[2023].social_care.means_test.residential.assets.lower_limit	 2.80033493133296E+04
default	3	y[2023].benefits.pension_credit.guaranteed_credit.severe_disability_single	 7.24353302238126E+01
default	3	y[2018].benefits.pension_credit.savings_credit.threshold_single	 1.26028394707513E+02
default	3	y[2013].benefits.pension_credit.guaranteed_credit.carer_single	 3.32846000000000E+01
default	3	y[2021].benefits.state_pension.class_a	 1.22198390890539E+02
default	3	y[2022].benefits.pension_credit.guaranteed_credit.couple	 2.65879294787562E+02
default	3	y[2020].benefits.pension_credit.guaranteed_credit.couple	 2.55554877727376E+02
default	3	y[2024].benefits.pension_credit.savings_credit.threshold_couple	 2.26412679868133E+02
default	3	y[2028].benefits.dla.mobility.high_rate	 7.42718115438345E+01
default	3	y[2017].social_care.means_test.maxima.maximum_lifetime_payment	 1.10516323535989E+12
default	3	y[2026].benefits.pension_credit.guaranteed_credit.couple	 2.87796299356177E+02
default	3	y[2015].benefits.pension_credit.savings_credit.threshold_couple	 1.89452002140000E+02
default	3	y[2020].av_costs.hour_of_care	 1.71229977733808E+01
default	3	y[2020].av_costs.residential_per_week	 5.82885609134951E+02
default	3	y[2024].benefits.pension_credit.guaranteed_credit.couple	 2.76620818296979E+02
default	3	y[2015].benefits.pension_credit.guaranteed_credit.severe_disability_couple	 1.23645713760000E+02
default	3	y[2028].benefits.pension_credit.guaranteed_credit.couple	 2.99423269850167E+02
default	3	y[2015].social_care.means_test.residential.assets.lower_limit	 2.39005890000000E+04
default	3	y[2020].benefits.pension_credit.guaranteed_credit.carer_single	 3.82335429734394E+01
default	3	y[2029].benefits.pension_credit.guaranteed_credit.carer_single	 4.56926230796594E+01
default	3	y[2029].benefits.attendance_allowance.high_rate	 1.08555020169314E+02
default	3	y[2025].av_costs.residential_per_week	 6.43552811507437E+02
default	3	y[2026].social_care.means_test.maxima.maximum_weekly_charge_non_residential	 6.60386184846666E+01
default	3	y[2017].benefits.state_pension.class_a	 1.12892424492024E+02
default	3	y[2024].social_care.means_test.maxima.maximum_lifetime_payment	 1.26948516887082E+12
default	3	y[2016].av_costs.hour_of_care	 1.58190031728000E+01
default	3	y[2024].benefits.attendance_allowance.high_rate	 9.83216263290547E+01
default	3	y[2030].social_care.means_test.maxima.maximum_weekly_charge_residential	 1.42964648756583E+09
default	3	y[2026].benefits.pension_credit.savings_credit.maximum_couple	 3.13419283328228E+01
default	3	y[2018].benefits.pension_credit.guaranteed_credit.severe_disability_single	 6.56069103039112E+01
default	2	y[2012].av_costs.hour_of_care	14.60
default	2	y[2012].av_costs.residential_per_week	497.0
default	2	y[2012].benefits.attendance_allowance.high_age	150
default	2	y[2012].benefits.attendance_allowance.high_rate	77.45
default	2	y[2012].benefits.attendance_allowance.low_age	65
default	2	y[2012].benefits.attendance_allowance.low_rate	51.85
default	2	y[2012].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2012].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2012].benefits.dla.care.high_age	64
default	2	y[2012].benefits.dla.care.high_rate	77.45
default	2	y[2012].benefits.dla.care.low_age	3
default	2	y[2012].benefits.dla.care.low_rate	20.55
default	2	y[2012].benefits.dla.care.middle_rate	51.85
default	2	y[2012].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2012].benefits.dla.care.test_generosity	1.0
default	2	y[2012].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2012].benefits.dla.mobility.high_age	64
default	2	y[2012].benefits.dla.mobility.high_rate	54.05
default	2	y[2012].benefits.dla.mobility.low_age	0
default	2	y[2012].benefits.dla.mobility.low_rate	20.55
default	2	y[2012].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2012].benefits.dla.mobility.test_generosity	1.0
default	2	y[2012].benefits.pension_credit.guaranteed_credit.carer_single	32.60
default	2	y[2012].benefits.pension_credit.guaranteed_credit.couple	217.90
default	2	y[2012].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2012].benefits.pension_credit.guaranteed_credit.severe_disability_couple	116.40
default	2	y[2012].benefits.pension_credit.guaranteed_credit.severe_disability_single	58.20
default	2	y[2012].benefits.pension_credit.guaranteed_credit.single	142.70
default	2	y[2012].benefits.pension_credit.savings_credit.maximum_couple	23.73
default	2	y[2012].benefits.pension_credit.savings_credit.maximum_single	18.54
default	2	y[2012].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2012].benefits.pension_credit.savings_credit.threshold_couple	178.35
default	2	y[2012].benefits.pension_credit.savings_credit.threshold_single	111.80
default	2	y[2012].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2012].benefits.state_pension.age_men	65
default	2	y[2012].benefits.state_pension.age_women	60
default	2	y[2012].benefits.state_pension.citizens_pension	False
default	2	y[2012].benefits.state_pension.class_a	102.15
default	2	y[2012].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2012].social_care.insurance.actuarially_fair	False
default	2	y[2012].social_care.insurance.contribution	none
default	2	y[2012].social_care.means_test.maxima.maximum_lifetime_payment	999999999999.9
default	2	y[2012].social_care.means_test.maxima.maximum_weekly_charge_non_residential	50.0
default	2	y[2012].social_care.means_test.maxima.maximum_weekly_charge_residential	999999999.0
default	2	y[2012].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2012].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2012].social_care.means_test.non_residential.assets.lower_limit	22500
default	2	y[2012].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2012].social_care.means_test.non_residential.assets.upper_limit	22500
default	2	y[2012].social_care.means_test.non_residential.income.abolish	False
default	2	y[2012].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2012].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2012].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2012].social_care.means_test.residential.assets.abolish	False
default	2	y[2012].social_care.means_test.residential.assets.include_property	True
default	2	y[2012].social_care.means_test.residential.assets.lower_limit	22500
default	2	y[2012].social_care.means_test.residential.assets.taper	0.0
default	2	y[2012].social_care.means_test.residential.assets.upper_limit	22500.0
default	2	y[2012].social_care.means_test.residential.income.abolish	False
default	2	y[2012].social_care.means_test.residential.income.floor	35.0
default	2	y[2012].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2012].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2012].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2012].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2012].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2012].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2012].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2012].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2012].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2012].social_care.options.abolish	False
default	2	y[2012].social_care.options.preserve_for_existing_claimants	False
default	2	y[2013].benefits.attendance_allowance.high_age	150
default	2	y[2013].benefits.attendance_allowance.low_age	65
default	2	y[2013].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2013].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2013].benefits.dla.care.high_age	64
default	2	y[2013].benefits.dla.care.low_age	3
default	2	y[2013].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2013].benefits.dla.care.test_generosity	1.0
default	2	y[2013].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2013].benefits.dla.mobility.high_age	64
default	2	y[2013].benefits.dla.mobility.low_age	0
default	2	y[2013].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2013].benefits.dla.mobility.test_generosity	1.0
default	2	y[2013].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2013].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2013].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2013].benefits.state_pension.age_men	65
default	2	y[2013].benefits.state_pension.age_women	60
default	2	y[2013].benefits.state_pension.citizens_pension	False
default	2	y[2013].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2013].social_care.insurance.actuarially_fair	False
default	2	y[2013].social_care.insurance.contribution	none
default	2	y[2013].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2013].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2013].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2013].social_care.means_test.non_residential.income.abolish	False
default	2	y[2013].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2013].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2013].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2013].social_care.means_test.residential.assets.abolish	False
default	2	y[2013].social_care.means_test.residential.assets.include_property	True
default	2	y[2013].social_care.means_test.residential.assets.taper	0.0
default	2	y[2013].social_care.means_test.residential.income.abolish	False
default	2	y[2013].social_care.means_test.residential.income.floor	35.0
default	2	y[2013].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2013].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2013].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2013].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2013].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2013].social_care.means_test.non_residential.assets.lower_limit	 2.29500000000000E+04
default	2	y[2013].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2013].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2013].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2013].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2013].social_care.options.abolish	False
default	2	y[2013].social_care.options.preserve_for_existing_claimants	False
default	2	y[2014].benefits.attendance_allowance.high_age	150
default	2	y[2014].benefits.attendance_allowance.low_age	65
default	2	y[2014].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2014].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2014].benefits.dla.care.high_age	64
default	2	y[2014].benefits.dla.care.low_age	3
default	2	y[2014].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2014].benefits.dla.care.test_generosity	1.0
default	2	y[2014].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2014].benefits.dla.mobility.high_age	64
default	2	y[2014].benefits.dla.mobility.low_age	0
default	2	y[2014].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2014].benefits.dla.mobility.test_generosity	1.0
default	2	y[2014].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2014].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2014].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2014].benefits.state_pension.age_men	65
default	2	y[2014].benefits.state_pension.age_women	60
default	2	y[2014].benefits.state_pension.citizens_pension	False
default	2	y[2014].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2014].social_care.insurance.actuarially_fair	False
default	2	y[2014].social_care.insurance.contribution	none
default	2	y[2014].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2014].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2014].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2014].social_care.means_test.non_residential.income.abolish	False
default	2	y[2014].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2014].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2014].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2014].social_care.means_test.residential.assets.abolish	False
default	2	y[2014].social_care.means_test.residential.assets.include_property	True
default	2	y[2014].social_care.means_test.residential.assets.taper	0.0
default	2	y[2014].social_care.means_test.residential.income.abolish	False
default	2	y[2014].social_care.means_test.residential.income.floor	35.0
default	2	y[2014].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2014].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2014].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2014].benefits.pension_credit.guaranteed_credit.carer_single	 3.39170400000000E+01
default	2	y[2014].benefits.dla.mobility.low_rate	 2.13802200000000E+01
default	2	y[2014].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2014].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2014].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2014].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2014].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2014].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2014].social_care.options.abolish	False
default	2	y[2014].social_care.options.preserve_for_existing_claimants	False
default	2	y[2015].benefits.attendance_allowance.high_age	150
default	2	y[2015].benefits.attendance_allowance.low_age	65
default	2	y[2015].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2015].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2015].benefits.dla.care.high_age	64
default	2	y[2015].benefits.dla.care.low_age	3
default	2	y[2015].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2015].benefits.dla.care.test_generosity	1.0
default	2	y[2015].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2015].benefits.dla.mobility.high_age	64
default	2	y[2015].benefits.dla.mobility.low_age	0
default	2	y[2015].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2015].benefits.dla.mobility.test_generosity	1.0
default	2	y[2015].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2015].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2015].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2015].benefits.state_pension.age_men	65
default	2	y[2015].benefits.state_pension.age_women	60
default	2	y[2015].benefits.state_pension.citizens_pension	False
default	2	y[2015].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2015].social_care.insurance.actuarially_fair	False
default	2	y[2015].social_care.insurance.contribution	none
default	2	y[2015].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2015].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2015].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2015].social_care.means_test.non_residential.income.abolish	False
default	2	y[2015].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2015].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2015].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2015].social_care.means_test.residential.assets.abolish	False
default	2	y[2015].social_care.means_test.residential.assets.include_property	True
default	2	y[2015].social_care.means_test.residential.assets.taper	0.0
default	2	y[2015].social_care.means_test.residential.income.abolish	False
default	2	y[2015].social_care.means_test.residential.income.floor	35.0
default	2	y[2015].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2015].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2015].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2015].benefits.dla.care.middle_rate	 5.50236348000000E+01
default	2	y[2015].av_costs.hour_of_care	 1.54936368000000E+01
default	2	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2015].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2015].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2015].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2015].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2015].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2015].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2015].social_care.options.abolish	False
default	2	y[2015].social_care.options.preserve_for_existing_claimants	False
default	2	y[2016].benefits.attendance_allowance.high_age	150
default	2	y[2016].benefits.attendance_allowance.low_age	65
default	2	y[2016].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2016].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2016].benefits.dla.care.high_age	64
default	2	y[2016].benefits.dla.care.low_age	3
default	2	y[2016].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2016].benefits.dla.care.test_generosity	1.0
default	2	y[2016].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2016].benefits.dla.mobility.high_age	64
default	2	y[2016].benefits.dla.mobility.low_age	0
default	2	y[2016].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2016].benefits.dla.mobility.test_generosity	1.0
default	2	y[2016].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2016].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2016].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2016].benefits.state_pension.age_men	65
default	2	y[2016].benefits.state_pension.age_women	61
default	2	y[2016].benefits.state_pension.citizens_pension	False
default	2	y[2016].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2016].social_care.insurance.actuarially_fair	False
default	2	y[2016].social_care.insurance.contribution	none
default	2	y[2016].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2016].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2016].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2016].social_care.means_test.non_residential.income.abolish	False
default	2	y[2016].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2016].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2016].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2016].social_care.means_test.residential.assets.abolish	False
default	2	y[2016].social_care.means_test.residential.assets.include_property	True
default	2	y[2016].social_care.means_test.residential.assets.taper	0.0
default	2	y[2016].social_care.means_test.residential.income.abolish	False
default	2	y[2016].social_care.means_test.residential.income.floor	35.0
default	2	y[2016].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2016].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2016].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2016].av_costs.residential_per_week	 5.37968783520000E+02
default	2	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2016].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2016].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2016].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2016].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2016].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2016].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2016].social_care.options.abolish	False
default	2	y[2016].social_care.options.preserve_for_existing_claimants	False
default	2	y[2017].benefits.attendance_allowance.high_age	150
default	2	y[2017].benefits.attendance_allowance.low_age	65
default	2	y[2017].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2017].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2017].benefits.dla.care.high_age	64
default	2	y[2017].benefits.dla.care.low_age	3
default	2	y[2017].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2017].benefits.dla.care.test_generosity	1.0
default	2	y[2017].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2017].benefits.dla.mobility.high_age	64
default	2	y[2017].benefits.dla.mobility.low_age	0
default	2	y[2017].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2017].benefits.dla.mobility.test_generosity	1.0
default	2	y[2017].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2017].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2017].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2017].benefits.state_pension.age_men	65
default	2	y[2017].benefits.state_pension.age_women	63
default	2	y[2017].benefits.state_pension.citizens_pension	False
default	2	y[2017].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2017].social_care.insurance.actuarially_fair	False
default	2	y[2017].social_care.insurance.contribution	none
default	2	y[2017].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2017].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2017].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2017].social_care.means_test.non_residential.income.abolish	False
default	2	y[2017].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2017].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2017].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2017].social_care.means_test.residential.assets.abolish	False
default	2	y[2017].social_care.means_test.residential.assets.include_property	True
default	2	y[2017].social_care.means_test.residential.assets.taper	0.0
default	2	y[2017].social_care.means_test.residential.income.abolish	False
default	2	y[2017].social_care.means_test.residential.income.floor	35.0
default	2	y[2017].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2017].social_care.means_test.non_residential.assets.lower_limit	 2.48418180720000E+04
default	2	y[2017].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2017].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2017].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2017].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2017].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2017].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2017].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2017].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2017].social_care.options.abolish	False
default	2	y[2017].social_care.options.preserve_for_existing_claimants	False
default	2	y[2018].benefits.attendance_allowance.high_age	150
default	2	y[2018].benefits.attendance_allowance.low_age	65
default	2	y[2018].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2018].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2018].benefits.dla.care.high_age	64
default	2	y[2018].benefits.dla.care.low_age	3
default	2	y[2018].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2018].benefits.dla.care.test_generosity	1.0
default	2	y[2018].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2018].benefits.dla.mobility.high_age	64
default	2	y[2018].benefits.dla.mobility.low_age	0
default	2	y[2018].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2018].benefits.dla.mobility.test_generosity	1.0
default	2	y[2018].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2018].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2018].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2018].benefits.state_pension.age_men	65
default	2	y[2018].benefits.state_pension.age_women	65
default	2	y[2018].benefits.state_pension.citizens_pension	False
default	2	y[2018].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2018].social_care.insurance.actuarially_fair	False
default	2	y[2018].social_care.insurance.contribution	none
default	2	y[2018].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2018].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2018].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2018].social_care.means_test.non_residential.income.abolish	False
default	2	y[2018].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2018].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2018].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2018].social_care.means_test.residential.assets.abolish	False
default	2	y[2018].social_care.means_test.residential.assets.include_property	True
default	2	y[2018].social_care.means_test.residential.assets.taper	0.0
default	2	y[2018].social_care.means_test.residential.income.abolish	False
default	2	y[2018].social_care.means_test.residential.income.floor	35.0
default	2	y[2018].benefits.dla.care.high_rate	 8.72212793719968E+01
default	2	y[2018].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2018].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2018].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2018].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2018].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2018].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2018].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2018].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2018].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2018].social_care.options.abolish	False
default	2	y[2018].social_care.options.preserve_for_existing_claimants	False
default	2	y[2019].benefits.attendance_allowance.high_age	150
default	2	y[2019].benefits.attendance_allowance.low_age	65
default	2	y[2019].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2019].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2019].benefits.dla.care.high_age	64
default	2	y[2019].benefits.dla.care.low_age	3
default	2	y[2019].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2019].benefits.dla.care.test_generosity	1.0
default	2	y[2019].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2019].benefits.dla.mobility.high_age	64
default	2	y[2019].benefits.dla.mobility.low_age	0
default	2	y[2019].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2019].benefits.dla.mobility.test_generosity	1.0
default	2	y[2019].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2019].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2019].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2019].benefits.state_pension.age_men	65
default	2	y[2019].benefits.state_pension.age_women	65
default	2	y[2019].benefits.state_pension.citizens_pension	False
default	2	y[2019].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2019].social_care.insurance.actuarially_fair	False
default	2	y[2019].social_care.insurance.contribution	none
default	2	y[2019].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2019].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2019].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2019].social_care.means_test.non_residential.income.abolish	False
default	2	y[2019].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2019].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2019].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2019].social_care.means_test.residential.assets.abolish	False
default	2	y[2019].social_care.means_test.residential.assets.include_property	True
default	2	y[2019].social_care.means_test.residential.assets.taper	0.0
default	2	y[2019].benefits.attendance_allowance.high_rate	 8.89657049594367E+01
default	2	y[2019].av_costs.hour_of_care	 1.67708107476795E+01
default	2	y[2019].social_care.means_test.residential.income.abolish	False
default	2	y[2019].social_care.means_test.residential.income.floor	35.0
default	2	y[2019].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2019].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2019].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2019].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2019].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2019].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2019].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2019].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2019].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2019].social_care.options.abolish	False
default	2	y[2019].social_care.options.preserve_for_existing_claimants	False
default	2	y[2020].benefits.attendance_allowance.high_age	150
default	2	y[2020].benefits.attendance_allowance.low_age	65
default	2	y[2020].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2020].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2020].benefits.dla.care.high_age	64
default	2	y[2020].benefits.dla.care.low_age	3
default	2	y[2020].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2020].benefits.dla.care.test_generosity	1.0
default	2	y[2020].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2020].benefits.dla.mobility.high_age	64
default	2	y[2020].benefits.dla.mobility.low_age	0
default	2	y[2020].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2020].benefits.dla.mobility.test_generosity	1.0
default	2	y[2020].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2020].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2020].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2020].benefits.state_pension.age_men	66
default	2	y[2020].benefits.state_pension.age_women	66
default	2	y[2020].benefits.state_pension.citizens_pension	False
default	2	y[2020].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2020].social_care.insurance.actuarially_fair	False
default	2	y[2020].social_care.insurance.contribution	none
default	2	y[2020].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2020].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2020].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2020].social_care.means_test.non_residential.income.abolish	False
default	2	y[2020].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2020].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2020].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2020].social_care.means_test.residential.assets.abolish	False
default	2	y[2020].social_care.means_test.residential.assets.include_property	True
default	2	y[2020].social_care.means_test.residential.assets.taper	0.0
default	2	y[2020].benefits.dla.care.middle_rate	 6.07505389049675E+01
default	2	y[2020].social_care.means_test.residential.income.abolish	False
default	2	y[2020].social_care.means_test.residential.income.floor	35.0
default	2	y[2020].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2020].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2020].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2020].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2020].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2020].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2020].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2020].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2020].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2020].social_care.options.abolish	False
default	2	y[2020].social_care.options.preserve_for_existing_claimants	False
default	2	y[2021].benefits.attendance_allowance.high_age	150
default	2	y[2021].benefits.attendance_allowance.low_age	65
default	2	y[2021].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2021].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2021].benefits.dla.care.high_age	64
default	2	y[2021].benefits.dla.care.low_age	3
default	2	y[2021].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2021].benefits.dla.care.test_generosity	1.0
default	2	y[2021].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2021].benefits.dla.mobility.high_age	64
default	2	y[2021].benefits.dla.mobility.low_age	0
default	2	y[2021].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2021].benefits.dla.mobility.test_generosity	1.0
default	2	y[2021].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2021].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2021].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2021].benefits.state_pension.age_men	66
default	2	y[2021].benefits.state_pension.age_women	66
default	2	y[2021].benefits.state_pension.citizens_pension	False
default	2	y[2021].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2021].social_care.insurance.actuarially_fair	False
default	2	y[2021].social_care.insurance.contribution	none
default	2	y[2021].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2021].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2021].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2021].social_care.means_test.non_residential.income.abolish	False
default	2	y[2021].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2021].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2021].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2021].social_care.means_test.residential.assets.abolish	False
default	2	y[2021].social_care.means_test.residential.assets.include_property	True
default	2	y[2021].benefits.pension_credit.savings_credit.maximum_single	 2.21570162222576E+01
default	2	y[2021].social_care.means_test.residential.assets.taper	0.0
default	2	y[2021].social_care.means_test.residential.income.abolish	False
default	2	y[2021].social_care.means_test.residential.income.floor	35.0
default	2	y[2021].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2021].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2021].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2021].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2021].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2021].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2021].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2021].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2021].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2021].social_care.options.abolish	False
default	2	y[2021].social_care.options.preserve_for_existing_claimants	False
default	2	y[2022].benefits.attendance_allowance.high_age	150
default	2	y[2022].benefits.attendance_allowance.low_age	65
default	2	y[2022].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2022].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2022].benefits.dla.care.high_age	64
default	2	y[2022].benefits.dla.care.low_age	3
default	2	y[2022].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2022].benefits.dla.care.test_generosity	1.0
default	2	y[2022].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2022].benefits.dla.mobility.high_age	64
default	2	y[2022].benefits.dla.mobility.low_age	0
default	2	y[2022].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2022].benefits.dla.mobility.test_generosity	1.0
default	2	y[2022].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2022].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2022].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2022].benefits.state_pension.age_men	66
default	2	y[2022].benefits.state_pension.age_women	66
default	2	y[2022].benefits.state_pension.citizens_pension	False
default	2	y[2022].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2022].social_care.insurance.actuarially_fair	False
default	2	y[2022].social_care.insurance.contribution	none
default	2	y[2022].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2022].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2022].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2022].social_care.means_test.non_residential.income.abolish	False
default	2	y[2022].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2022].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2022].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2022].benefits.state_pension.class_a	 1.24520280002464E+02
default	2	y[2022].benefits.dla.mobility.high_rate	 6.58866484007166E+01
default	2	y[2022].social_care.means_test.residential.assets.abolish	False
default	2	y[2022].social_care.means_test.residential.assets.include_property	True
default	2	y[2022].social_care.means_test.residential.assets.taper	0.0
default	2	y[2022].social_care.means_test.residential.income.abolish	False
default	2	y[2022].social_care.means_test.residential.income.floor	35.0
default	2	y[2022].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2022].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2022].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2022].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2022].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2022].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2022].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2022].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2022].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2022].social_care.options.abolish	False
default	2	y[2022].social_care.options.preserve_for_existing_claimants	False
default	2	y[2023].benefits.attendance_allowance.high_age	150
default	2	y[2023].benefits.attendance_allowance.low_age	65
default	2	y[2023].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2023].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2023].benefits.dla.care.high_age	64
default	2	y[2023].benefits.dla.care.low_age	3
default	2	y[2023].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2023].benefits.dla.care.test_generosity	1.0
default	2	y[2023].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2023].benefits.dla.mobility.high_age	64
default	2	y[2023].benefits.dla.mobility.low_age	0
default	2	y[2023].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2023].benefits.dla.mobility.test_generosity	1.0
default	2	y[2023].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2023].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2023].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2023].benefits.state_pension.age_men	66
default	2	y[2023].benefits.state_pension.age_women	66
default	2	y[2023].benefits.state_pension.citizens_pension	False
default	2	y[2023].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2023].social_care.insurance.actuarially_fair	False
default	2	y[2023].social_care.insurance.contribution	none
default	2	y[2023].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2023].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2023].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2023].social_care.means_test.non_residential.income.abolish	False
default	2	y[2023].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2023].benefits.dla.care.high_rate	 9.62993401851658E+01
default	2	y[2023].benefits.state_pension.class_a	 1.27010685602514E+02
default	2	y[2023].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2023].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2023].social_care.means_test.residential.assets.abolish	False
default	2	y[2023].social_care.means_test.residential.assets.include_property	True
default	2	y[2023].social_care.means_test.residential.assets.taper	0.0
default	2	y[2023].social_care.means_test.residential.income.abolish	False
default	2	y[2023].social_care.means_test.residential.income.floor	35.0
default	2	y[2023].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2023].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2023].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2023].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2023].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2023].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2023].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2023].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2023].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2023].social_care.options.abolish	False
default	2	y[2023].social_care.options.preserve_for_existing_claimants	False
default	2	y[2024].benefits.attendance_allowance.high_age	150
default	2	y[2024].benefits.attendance_allowance.low_age	65
default	2	y[2024].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2024].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2024].benefits.dla.care.high_age	64
default	2	y[2024].benefits.dla.care.low_age	3
default	2	y[2024].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2024].benefits.dla.care.test_generosity	1.0
default	2	y[2024].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2024].benefits.dla.mobility.high_age	64
default	2	y[2024].benefits.dla.mobility.low_age	0
default	2	y[2024].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2024].benefits.dla.mobility.test_generosity	1.0
default	2	y[2024].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2024].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2024].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2024].benefits.state_pension.age_men	66
default	2	y[2024].benefits.state_pension.age_women	66
default	2	y[2024].benefits.state_pension.citizens_pension	False
default	2	y[2024].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2024].social_care.insurance.actuarially_fair	False
default	2	y[2024].social_care.insurance.contribution	none
default	2	y[2024].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2024].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2024].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2024].benefits.state_pension.class_a	 1.29550899314564E+02
default	2	y[2024].av_costs.hour_of_care	 1.85163302006132E+01
default	2	y[2024].social_care.means_test.non_residential.income.abolish	False
default	2	y[2024].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2024].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2024].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2024].social_care.means_test.residential.assets.abolish	False
default	2	y[2024].social_care.means_test.residential.assets.include_property	True
default	2	y[2024].social_care.means_test.residential.assets.taper	0.0
default	2	y[2024].social_care.means_test.residential.income.abolish	False
default	2	y[2024].social_care.means_test.residential.income.floor	35.0
default	2	y[2024].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2024].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2024].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2024].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2024].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2024].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2024].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2024].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2024].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2024].social_care.options.abolish	False
default	2	y[2024].social_care.options.preserve_for_existing_claimants	False
default	2	y[2025].benefits.attendance_allowance.high_age	150
default	2	y[2025].benefits.attendance_allowance.low_age	65
default	2	y[2025].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2025].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2025].benefits.dla.care.high_age	64
default	2	y[2025].benefits.dla.care.low_age	3
default	2	y[2025].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2025].benefits.dla.care.test_generosity	1.0
default	2	y[2025].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2025].benefits.dla.mobility.high_age	64
default	2	y[2025].benefits.dla.mobility.low_age	0
default	2	y[2025].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2025].benefits.dla.mobility.test_generosity	1.0
default	2	y[2025].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2025].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2025].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2025].benefits.state_pension.age_men	66
default	2	y[2025].benefits.state_pension.age_women	66
default	2	y[2025].benefits.state_pension.citizens_pension	False
default	2	y[2025].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2025].social_care.insurance.actuarially_fair	False
default	2	y[2025].social_care.insurance.contribution	none
default	2	y[2025].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2025].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2025].benefits.dla.mobility.high_rate	 6.99194383760277E+01
default	2	y[2025].benefits.dla.care.middle_rate	 6.70735037890293E+01
default	2	y[2025].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2025].social_care.means_test.non_residential.income.abolish	False
default	2	y[2025].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2025].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2025].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2025].social_care.means_test.residential.assets.abolish	False
default	2	y[2025].social_care.means_test.residential.assets.include_property	True
default	2	y[2025].social_care.means_test.residential.assets.taper	0.0
default	2	y[2025].social_care.means_test.residential.income.abolish	False
default	2	y[2025].social_care.means_test.residential.income.floor	35.0
default	2	y[2025].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2025].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2025].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2027].av_costs.residential_per_week	 6.68896564147093E+02
default	2	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2025].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2025].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2025].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2025].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2025].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2025].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2025].social_care.options.abolish	False
default	2	y[2025].social_care.options.preserve_for_existing_claimants	False
default	2	y[2026].benefits.attendance_allowance.high_age	150
default	2	y[2026].benefits.attendance_allowance.low_age	65
default	2	y[2026].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2026].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2026].benefits.dla.care.high_age	64
default	2	y[2026].benefits.dla.care.low_age	3
default	2	y[2026].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2026].benefits.dla.care.test_generosity	1.0
default	2	y[2026].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2026].benefits.dla.mobility.high_age	64
default	2	y[2026].benefits.dla.mobility.low_age	0
default	2	y[2026].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2026].benefits.dla.mobility.test_generosity	1.0
default	2	y[2026].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2026].benefits.pension_credit.savings_credit.preserve_for_existing_claimants	False
default	2	y[2026].benefits.pension_credit.savings_credit.withdrawal_rate	60.0
default	2	y[2026].benefits.state_pension.age_men	66
default	2	y[2026].benefits.state_pension.age_women	66
default	2	y[2026].benefits.state_pension.citizens_pension	False
default	2	y[2026].benefits.state_pension.preserve_for_existing_claimants	False
default	2	y[2026].social_care.insurance.actuarially_fair	False
default	2	y[2026].social_care.insurance.contribution	none
default	2	y[2026].social_care.means_test.non_residential.assets.abolish	False
default	2	y[2026].benefits.dla.care.high_rate	 1.02193630199219E+02
default	2	y[2026].av_costs.hour_of_care	 1.92643899407179E+01
default	2	y[2026].social_care.means_test.non_residential.assets.include_property	False
default	2	y[2026].social_care.means_test.non_residential.assets.taper	0.0
default	2	y[2026].social_care.means_test.non_residential.income.abolish	False
default	2	y[2026].social_care.means_test.non_residential.income.floor	35.0
default	2	y[2026].social_care.means_test.non_residential.income.minimum_support_level	0.0
default	2	y[2026].social_care.means_test.non_residential.income.percent_costs_met	0.0
default	2	y[2026].social_care.means_test.residential.assets.abolish	False
default	2	y[2026].social_care.means_test.residential.assets.include_property	True
default	2	y[2026].social_care.means_test.residential.assets.taper	0.0
default	2	y[2026].social_care.means_test.residential.income.abolish	False
default	2	y[2026].social_care.means_test.residential.income.floor	35.0
default	2	y[2026].social_care.means_test.residential.income.minimum_support_level	0.0
default	2	y[2026].social_care.means_test.residential.income.percent_costs_met	0.0
default	2	y[2026].social_care.needs_assessment_rules.carer_blind_degree	0.0
default	2	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_critical	100.00
default	2	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_low	100.0
default	2	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_moderate	100.0
default	2	y[2026].social_care.needs_assessment_rules.share_of_category_passing_test_substantial	100.0
default	2	y[2026].social_care.needs_assessment_rules.uap_category_critical	5.5
default	2	y[2026].social_care.needs_assessment_rules.uap_category_low	10.0
default	2	y[2026].social_care.needs_assessment_rules.uap_category_moderate	2.3
default	2	y[2026].social_care.needs_assessment_rules.uap_category_substantial	2.8
default	2	y[2026].social_care.needs_assessment_rules.use_carer_blind_system	False
default	2	y[2026].social_care.options.abolish	False
default	2	y[2026].social_care.options.preserve_for_existing_claimants	False
default	2	y[2027].benefits.attendance_allowance.high_age	150
default	2	y[2027].benefits.attendance_allowance.low_age	65
default	2	y[2027].benefits.attendance_allowance.preserve_for_existing_claimants	False
default	2	y[2027].benefits.attendance_allowance.test_generosity	1.0
default	2	y[2027].benefits.dla.care.high_age	64
default	2	y[2027].benefits.dla.care.low_age	3
default	2	y[2027].benefits.dla.care.preserve_for_existing_claimants	False
default	2	y[2027].benefits.dla.care.test_generosity	1.0
default	2	y[2027].benefits.dla.dont_pay_for_residential_claimants	False
default	2	y[2027].benefits.dla.mobility.high_age	64
default	2	y[2027].benefits.dla.mobility.low_age	0
default	2	y[2027].benefits.dla.mobility.preserve_for_existing_claimants	False
default	2	y[2027].benefits.dla.mobility.test_generosity	1.0
default	2	y[2027].benefits.pension_credit.guaranteed_credit.preserve_for_existing_claimants	False
default	2	y[2026].social_care.means_test.residential.assets.upper_limit	 2.96882721689146E+04
default	2	y[2026].social_care.means_test.non_residential.assets.lower_limit	 2.96882721689146E+04
default	2	y[2027].benefits.attendance_allowance.high_rate	 1.04237502803204E+02
default	2	y[2026].social_care.means_test.non_residential.assets.upper_limit	 2.96882721689146E+04
default	2	y[2027].benefits.dla.care.low_rate	 2.76575943525609E+01
default	2	y[2027].benefits.pension_credit.guaranteed_credit.couple	 2.93264710920828E+02
default	2	y[2027].benefits.dla.care.middle_rate	 6.97832733421061E+01
default	2	y[2027].benefits.dla.mobility.low_rate	 2.76575943525609E+01
default	2	y[2027].benefits.dla.mobility.high_rate	 7.27441836864192E+01
default	2	y[2026].social_care.means_test.residential.assets.lower_limit	 2.96882721689146E+04
default	2	y[2027].benefits.dla.care.high_rate	 1.04237502803204E+02
default	2	y[2027].benefits.pension_credit.guaranteed_credit.carer_single	 4.38753078293666E+01
default	2	y[2027].av_costs.hour_of_care	 1.96496777395323E+01
default	2	y[2027].benefits.attendance_allowance.low_rate	 6.97832733421061E+01
\.


--
-- Data for Name: maxima_and_totals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY maxima_and_totals (lifetime_la_contributions, lifetime_client_contributions, lifetime_gross_payments, lifetime_capital_contributions, highest_la_contribution) FROM stdin;
\.


--
-- Data for Name: personal_income; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY personal_income (username, run_id, pid, sysno, iteration, wave, income_type, hid, buno, adno, value) FROM stdin;
\.


--
-- Data for Name: personal_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY personal_results (username, run_id, sysno, iteration, pid, wave, hid, buno, adno, passes_non_residential_capital_test, passes_non_residential_income_test, passes_residential_capital_test, passes_residential_income_test, passes_residential_means_test, passes_non_residential_means_test, la_contributions, client_contributions, gross_care_costs, total_payments_to_date, disposable_income, net_income, marginal_rate, capital_contribution, minimum_income_guarantee, hours_of_care_la, hours_of_care_private, uap, remaining_capital_stock) FROM stdin;
\.


--
-- Data for Name: probit_threshold; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY probit_threshold (username, run_id, element, threshold) FROM stdin;
default	3	0	0.450000000000000011
default	3	1	0.5
default	3	2	0.5
default	3	3	0.5
default	3	4	0.5
default	3	5	0.5
default	3	6	0.5
default	3	7	0.5
default	3	8	0.5
default	3	9	0.5
default	3	10	0.349999999999999978
default	3	11	0.299999999999999989
default	3	12	0.299999999999999989
default	3	13	0.299999999999999989
default	1	5	0.5
default	1	6	0.5
default	1	7	0.5
default	1	8	0.5
default	1	9	0.5
default	1	10	0.349999999999999978
default	1	11	0.299999999999999989
default	1	12	0.299999999999999989
default	1	13	0.299999999999999989
default	2	0	0.450000000000000011
default	2	1	0.5
default	2	2	0.5
default	2	3	0.5
default	2	4	0.5
default	2	5	0.5
default	2	6	0.5
default	2	7	0.5
default	2	8	0.5
default	2	9	0.5
default	2	10	0.349999999999999978
default	2	11	0.299999999999999989
default	2	12	0.299999999999999989
default	1	0	0.450000000000000011
default	1	1	0.5
default	1	2	0.5
default	1	3	0.5
default	1	4	0.5
default	2	13	0.299999999999999989
\.


--
-- Data for Name: run; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY run (run_id, username, comparison_username, comparison_run_id, title, use_random_threshold, num_iterations, interest_rate_pct, real_terms, is_null_settings, working_root, users_directory, output_directory, dir_separator, session_id, default_run_dir_id, start_year, end_year, weighting_function, weighting_lower_bound, weighting_upper_bound, status, dataset_name, type_of_run) FROM stdin;
3	default	default	3	Uprated by CPI from 2013	1	1	0.0299999999999999989	0	0	/home/graham_s/VirtualWorlds/projects/wales_social_care/model/working/users/			/		0	2012	2030	1	0	0	1	default	0
1	default	default	1	Default Run; no uprated parameters	1	1	0.0299999999999999989	0	0	/home/graham_s/VirtualWorlds/projects/wales_social_care/model/working/users/			/		0	2012	2030	1	0	0	0	default	0
2	default	default	2	Uprated by 2% from 2013	1	1	0.0299999999999999989	0	0	/home/graham_s/VirtualWorlds/projects/wales_social_care/model/working/users/			/		0	2012	2030	1	0	0	0	default	0
\.


--
-- Data for Name: state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY state (username, run_id, household, other_counter, year, phase, health, error_code, read_error, session_id, other_counter2, other_counter3, other_counter4) FROM stdin;
\.


--
-- Data for Name: uap_threshold; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY uap_threshold (run_id, username, sysno, iteration, wave, uap_level, threshold) FROM stdin;
\.


--
-- Data for Name: uprate_assumption; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY uprate_assumption (username, run_id, percent_change, use_obr, target, element) FROM stdin;
default	2	2	0	0	1
default	3	0	1	0	3
default	3	0	1	1	3
default	3	0	1	2	3
default	3	0	1	3	3
default	3	0	1	4	3
default	3	0	1	5	3
default	3	0	1	6	3
default	3	0	1	7	3
default	1	0	0	0	1
default	1	0	0	1	1
default	1	0	0	2	1
default	1	0	0	3	1
default	1	0	0	4	1
default	1	0	0	5	1
default	1	0	0	6	1
default	1	0	0	7	1
default	2	2	0	1	1
default	2	2	0	2	1
default	2	2	0	3	1
default	2	2	0	4	1
default	2	2	0	5	1
default	2	2	0	6	1
default	2	2	0	7	1
\.


--
-- Data for Name: user_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_type (username, password, title, description, email, work_dir, utype, lang, preferences, last_used) FROM stdin;
default	some pass		Default User	z		0	0	 	2012-03-07 22:08:54.593996
test_user1	some password		Test User 1	graham.stark@virtual-worlds.biz		0	0	 	2013-01-25 16:13:59
\.


--
-- Name: dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dataset
    ADD CONSTRAINT dataset_pkey PRIMARY KEY (name);


--
-- Name: disaggregated_data_table_cell_description_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY disaggregated_data_table_cell_description
    ADD CONSTRAINT disaggregated_data_table_cell_description_pkey PRIMARY KEY (model_table_name, cell_pos);


--
-- Name: disaggregated_data_table_cell_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY disaggregated_data_table_cell
    ADD CONSTRAINT disaggregated_data_table_cell_pkey PRIMARY KEY (run_id, username, model_table_name, row_num, col_num, wave, iteration, system_number);


--
-- Name: disaggregated_data_table_description_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY disaggregated_data_table_description
    ADD CONSTRAINT disaggregated_data_table_description_pkey PRIMARY KEY (model_table_name);


--
-- Name: disaggregated_data_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY disaggregated_data_table
    ADD CONSTRAINT disaggregated_data_table_pkey PRIMARY KEY (run_id, username, model_table_name, iteration);


--
-- Name: key_value_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY key_value_parameter
    ADD CONSTRAINT key_value_parameter_pkey PRIMARY KEY (username, run_id, key);


--
-- Name: personal_income_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY personal_income
    ADD CONSTRAINT personal_income_pkey PRIMARY KEY (username, run_id, pid, sysno, iteration, wave, income_type);


--
-- Name: personal_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY personal_results
    ADD CONSTRAINT personal_results_pkey PRIMARY KEY (username, run_id, sysno, iteration, pid, wave);


--
-- Name: probit_threshold_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY probit_threshold
    ADD CONSTRAINT probit_threshold_pkey PRIMARY KEY (username, run_id, element);


--
-- Name: run_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY run
    ADD CONSTRAINT run_pkey PRIMARY KEY (run_id, username);


--
-- Name: state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY state
    ADD CONSTRAINT state_pkey PRIMARY KEY (username, run_id);


--
-- Name: uap_threshold_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY uap_threshold
    ADD CONSTRAINT uap_threshold_pkey PRIMARY KEY (run_id, username, sysno, iteration, wave, uap_level);


--
-- Name: uprate_assumption_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY uprate_assumption
    ADD CONSTRAINT uprate_assumption_pkey PRIMARY KEY (username, run_id, target);


--
-- Name: user_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_type
    ADD CONSTRAINT user_type_pkey PRIMARY KEY (username);


--
-- Name: replace_key_value; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE replace_key_value AS ON INSERT TO key_value_parameter WHERE (EXISTS (SELECT 1 FROM key_value_parameter WHERE ((((key_value_parameter.username)::text = (new.username)::text) AND (key_value_parameter.run_id = new.run_id)) AND ((key_value_parameter.key)::text = (new.key)::text)))) DO INSTEAD UPDATE key_value_parameter SET val = new.val WHERE ((((key_value_parameter.username)::text = (new.username)::text) AND (key_value_parameter.run_id = new.run_id)) AND ((key_value_parameter.key)::text = (new.key)::text));


--
-- Name: dataset_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dataset
    ADD CONSTRAINT dataset_fk_0 FOREIGN KEY (creator) REFERENCES user_type(username) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: disaggregated_data_table_cell_description_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY disaggregated_data_table_cell_description
    ADD CONSTRAINT disaggregated_data_table_cell_description_fk_0 FOREIGN KEY (model_table_name) REFERENCES disaggregated_data_table_description(model_table_name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: disaggregated_data_table_cell_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY disaggregated_data_table_cell
    ADD CONSTRAINT disaggregated_data_table_cell_fk_0 FOREIGN KEY (run_id, username, iteration, model_table_name) REFERENCES disaggregated_data_table(run_id, username, iteration, model_table_name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: disaggregated_data_table_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY disaggregated_data_table
    ADD CONSTRAINT disaggregated_data_table_fk_0 FOREIGN KEY (model_table_name) REFERENCES disaggregated_data_table_description(model_table_name) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: disaggregated_data_table_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY disaggregated_data_table
    ADD CONSTRAINT disaggregated_data_table_fk_1 FOREIGN KEY (run_id, username) REFERENCES run(run_id, username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: key_value_parameter_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY key_value_parameter
    ADD CONSTRAINT key_value_parameter_fk_0 FOREIGN KEY (username, run_id) REFERENCES run(username, run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: personal_income_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY personal_income
    ADD CONSTRAINT personal_income_fk_0 FOREIGN KEY (username, run_id) REFERENCES run(username, run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: personal_results_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY personal_results
    ADD CONSTRAINT personal_results_fk_0 FOREIGN KEY (username, run_id) REFERENCES run(username, run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: probit_threshold_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY probit_threshold
    ADD CONSTRAINT probit_threshold_fk_0 FOREIGN KEY (username, run_id) REFERENCES run(username, run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: run_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY run
    ADD CONSTRAINT run_fk_0 FOREIGN KEY (username) REFERENCES user_type(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: state_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY state
    ADD CONSTRAINT state_fk_0 FOREIGN KEY (username, run_id) REFERENCES run(username, run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: uap_threshold_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY uap_threshold
    ADD CONSTRAINT uap_threshold_fk_0 FOREIGN KEY (username, run_id) REFERENCES run(username, run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: uprate_assumption_fk_0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY uprate_assumption
    ADD CONSTRAINT uprate_assumption_fk_0 FOREIGN KEY (username, run_id) REFERENCES run(username, run_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

